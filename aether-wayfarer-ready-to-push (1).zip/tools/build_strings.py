#!/usr/bin/env python3
"""Single source for player-facing strings. Edit STRINGS, then run:
    python3 tools/build_strings.py
It merges tools/tuning_strings.json (from gen_tuning.py) and writes
localization/en.json and localization/zh-CN.json."""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# key: (English, 简体中文)
STRINGS = {
    # language / generic
    "language.label": ("Language", "语言"),
    "language.english": ("English", "English"),
    "language.chinese": ("中文", "中文"),
    "menu.back": ("Back", "返回"),
    "menu.title": ("Title Screen", "返回标题"),
    "menu.continue": ("Continue · {level}", "继续旅程 · {level}"),
    "menu.new_journey": ("New Journey", "新的旅程"),
    "menu.chapters": ("Chapters", "章节"),
    "menu.controls": ("How to Play", "操作说明"),
    "menu.close": ("Close", "关闭"),
    "menu.confirm": ("Confirm", "确认"),
    "menu.cancel": ("Cancel", "取消"),
    # title
    "title.tagline": ("Carry the last flame through the swallowing murk.", "提灯穿越吞噬一切的黑雾，点亮沿途的灯塔。"),
    "title.best_journey": ("Best journey  {time}", "最佳旅程  {time}"),
    "title.embers": ("Embers found  {n} / 9", "已寻得火种  {n} / 9"),
    # chapters
    "chapter.locked": ("— Sealed by murk —", "— 被黑雾封锁 —"),
    "chapter.best": ("Best  {time}", "最佳  {time}"),
    "chapter.embers": ("Embers  {n} / 3", "火种  {n} / 3"),
    "chapter.cleared": ("Murk dispelled", "黑雾已散"),
    # levels
    "level.forest.name": ("I · Hushwood", "一 · 寂语林"),
    "level.forest.subtitle": ("The fog came down through the branches.", "黑雾顺着枝叶垂落下来。"),
    "level.cave.name": ("II · Glimmerdeep", "二 · 微光洞窟"),
    "level.cave.subtitle": ("Below the roots, stones remember the light.", "树根之下，石头还记得光。"),
    "level.tower.name": ("III · The Bell Spire", "三 · 钟楼"),
    "level.tower.subtitle": ("Climb to the bell that no longer rings.", "向上攀登，去往那口不再鸣响的钟。"),
    "level.boss.name": ("IV · Murkmaw", "四 · 雾噬"),
    "level.boss.subtitle": ("The fog has a heart. It is hungry.", "黑雾也有心脏，而它很饿。"),
    "boss.name": ("Murkmaw", "雾噬"),
    # hints (placeholders: {move} {jump} {dash} {lantern} {down} {retry})
    "hint.move": ("Move with {move}  ·  Jump with {jump}", "{move} 移动  ·  {jump} 跳跃"),
    "hint.variable_jump": ("Hold {jump} to jump higher, tap for a hop", "按住 {jump} 跳得更高，轻点则小跳"),
    "hint.spirit": ("Spirit stones only take shape inside your lantern light", "灵石只有被灯笼照到才会显形，才能落脚"),
    "hint.stomp": ("Land on a murkling to pop it", "从上方踩下即可击溃雾团"),
    "hint.flare": ("Hold {lantern} to flare the lantern: it burns away murk creatures and reveals far stones", "按住 {lantern} 让灯笼爆亮：驱散雾怪、照出远处的灵石"),
    "hint.walljump": ("Slide down a wall, then press {jump} to kick off it", "贴墙下滑时按 {jump} 蹬墙跳"),
    "hint.dash": ("Press {dash} to dash in any direction, once per jump", "按 {dash} 向任意方向冲刺，每次腾空一次"),
    "hint.beacon": ("Light the beacon to cleanse the woods", "点亮灯塔，驱散这片森林的黑雾"),
    "hint.flare_scout": ("Dark ahead? Flare {lantern} to scout the stones", "前方太暗？按 {lantern} 爆亮探路"),
    "hint.shaft": ("Chain wall jumps up the shaft", "在竖井里连续蹬墙跳向上"),
    "hint.dash_low": ("Press {dash} to dash across the gap below the thorns. Thornshades can't be stomped: burn them with {lantern}", "在荆棘下方按 {dash} 冲刺越过缺口。荆影无法踩踏，要按住 {lantern} 用灯光灼烧"),
    "hint.tower": ("The spire climbs upward. Checkpoints glow on the landings", "钟楼一路向上，平台上的路灯就是检查点"),
    "hint.boss_0": ("Light the marked brazier to stun Murkmaw, then stomp or flare it", "点燃标记的火盆让雾噬眩晕，再踩它或用灯光灼烧"),
    "hint.boss_1": ("It grows angrier. Jump the murk waves", "它愈发狂怒——跳过地面的雾浪"),
    "hint.boss_2": ("Last flame! Watch its shadow before the slam", "最后一击！注意砸地前的阴影"),
    "glyph.touch_move": ("◀ ▶", "◀ ▶"),
    "glyph.touch_jump": ("the jump button", "跳跃键"),
    "glyph.touch_dash": ("the dash button", "冲刺键"),
    "glyph.touch_lantern": ("the lantern button", "灯笼键"),
    "glyph.touch_down": ("◀ ▶", "◀ ▶"),
    # toasts
    "toast.checkpoint": ("Waylamp lit", "路灯已点亮"),
    "toast.ember": ("Ember  {n} / 3", "火种  {n} / 3"),
    "toast.beacon": ("The beacon burns!", "灯塔燃起来了！"),
    "toast.boss_down": ("The murk lifts", "黑雾散去了"),
    # pause
    "pause.title": ("Paused", "暂停"),
    "pause.resume": ("Resume", "继续"),
    "pause.checkpoint": ("Back to Waylamp", "回到路灯"),
    "pause.restart": ("Restart Chapter", "重新开始本章"),
    # results
    "results.title": ("Beacon Lit", "灯塔已点亮"),
    "results.time": ("Time", "用时"),
    "results.best": ("Best", "最佳"),
    "results.embers": ("Embers", "火种"),
    "results.deaths": ("Falls", "倒下"),
    "results.new_best": ("NEW BEST", "新纪录"),
    "results.next": ("Next Chapter", "下一章"),
    "results.next_boss": ("Face the Murkmaw", "迎战雾噬"),
    "results.retry": ("Play Again", "再玩一次"),
    "results.boss_time": ("Battle", "战斗用时"),
    "results.journey_time": ("Journey", "旅程总时"),
    "results.all_embers": ("All embers", "火种总计"),
    "final.title": ("Dawn Returns", "黎明归来"),
    "final.story": ("The bell rings again. One by one the beacons answer, and the murk thins into morning mist.", "钟声再次响起。灯塔一座接一座地回应，黑雾渐渐化作清晨的薄雾。"),
    # settings
    "settings.title": ("Settings", "设置"),
    "settings.volume_master": ("Master volume", "总音量"),
    "settings.volume_music": ("Music", "音乐"),
    "settings.volume_sfx": ("Sound effects", "音效"),
    "settings.effects": ("Effects quality", "特效画质"),
    "settings.quality_low": ("Low", "低"),
    "settings.quality_high": ("High", "高"),
    "settings.shake": ("Shake & flashes", "震屏与闪光"),
    "settings.hints": ("Tutorial hints", "操作引导"),
    "settings.language": ("Language", "语言"),
    "settings.on": ("On", "开"),
    "settings.off": ("Off", "关"),
    "settings.licenses": ("Licenses", "开源许可"),
    # controls
    "controls.keyboard": ("Keyboard", "键盘"),
    "controls.gamepad": ("Gamepad", "手柄"),
    "controls.move": ("Move", "移动"),
    "controls.jump": ("Jump / Wall jump", "跳跃 / 蹬墙跳"),
    "controls.dash": ("Dash", "冲刺"),
    "controls.lantern": ("Lantern flare (hold)", "灯笼爆亮（按住）"),
    "controls.drop": ("Drop through planks", "穿过木板下落"),
    "controls.retry": ("Quick retry", "快速重来"),
    "controls.pause": ("Pause", "暂停"),
    "controls.tip": ("Jumps forgive late presses at ledges and early presses before landing. On phones, turn sideways and use the on-screen buttons.", "跳跃对边缘晚按和落地前早按都很宽容。手机请横屏，使用屏幕按钮操作。"),
}


def main():
    en, zh = {}, {}
    old_en = json.load(open(os.path.join(ROOT, "localization", "en.json")))
    old_zh = json.load(open(os.path.join(ROOT, "localization", "zh-CN.json")))
    # Keep generic tuning-panel UI strings from the template (not old settings).
    for k in old_en:
        if k.startswith("tuning.") and not k.startswith(("tuning.setting.", "tuning.description.")):
            en[k] = old_en[k]
            zh[k] = old_zh.get(k, old_en[k])
    tuning = json.load(open(os.path.join(ROOT, "tools", "tuning_strings.json")))
    en.update(tuning["en"])
    zh.update(tuning["zh-CN"])
    for k, (e, z) in STRINGS.items():
        en[k] = e
        zh[k] = z
    for name, data in (("en", en), ("zh-CN", zh)):
        with open(os.path.join(ROOT, "localization", name + ".json"), "w") as fh:
            json.dump(dict(sorted(data.items())), fh, indent=1, ensure_ascii=False)
    print(len(en), "strings")


if __name__ == "__main__":
    main()
