#!/usr/bin/env python3
"""Turn raw generated art (/home/ubuntu/art_raw) into runtime textures under assets/art.

All in-game art is authored at 2x texel density: sprites are drawn at scale 0.5
and tiling shaders divide world coordinates by (texture_size * 0.5).
Run: python3 tools/process_art.py  (re-runnable, deterministic)
"""
import json
import os
import sys

import numpy as np
from PIL import Image, ImageFilter

RAW = os.environ.get("ART_RAW", "/home/ubuntu/art_raw")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "assets", "art")
META = {}


def load(name):
    return Image.open(os.path.join(RAW, name + ".png")).convert("RGBA")


def save(img, rel):
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, optimize=True)
    return path


def clean_alpha(img, cutoff=12):
    arr = np.array(img)
    a = arr[:, :, 3]
    a[a < cutoff] = 0
    arr[:, :, 3] = a
    return Image.fromarray(arr)


def segments(mask_1d, min_gap, min_len):
    segs, start, gap = [], None, 0
    for i, v in enumerate(mask_1d):
        if v:
            if start is None:
                start = i
            gap = 0
            end = i
        elif start is not None:
            gap += 1
            if gap >= min_gap:
                segs.append([start, end])
                start = None
    if start is not None:
        segs.append([start, end])
    return [s for s in segs if s[1] - s[0] >= min_len]


def split_axis(img, count, axis=0, min_gap=6):
    """Split a sprite row (axis=0: columns) into `count` pieces by empty gaps."""
    a = np.array(img)[:, :, 3] > 24
    profile = a.any(axis=axis)
    segs = segments(profile, min_gap, 8)
    while len(segs) > count:
        gaps = [segs[i + 1][0] - segs[i][1] for i in range(len(segs) - 1)]
        i = int(np.argmin(gaps))
        segs[i] = [segs[i][0], segs[i + 1][1]]
        del segs[i + 1]
    occupancy = a.sum(axis=axis)
    while len(segs) < count and segs:
        # Touching sprites: split the widest piece at its emptiest middle column.
        i = int(np.argmax([s[1] - s[0] for s in segs]))
        s0, s1 = segs[i]
        lo, hi = s0 + int((s1 - s0) * 0.3), s0 + int((s1 - s0) * 0.7)
        cut = lo + int(np.argmin(occupancy[lo:hi]))
        segs[i:i + 1] = [[s0, cut], [cut + 1, s1]]
    if len(segs) != count:
        raise SystemExit(f"expected {count} pieces, found {len(segs)}")
    pieces = []
    for s0, s1 in segs:
        box = (s0, 0, s1 + 1, img.height) if axis == 0 else (0, s0, img.width, s1 + 1)
        piece = img.crop(box)
        bb = piece.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
        pieces.append(piece.crop(bb))
    return pieces


def torso_center(piece):
    a = np.array(piece)[:, :, 3] > 60
    h = a.shape[0]
    band = a[int(h * 0.25): int(h * 0.7)]
    cols = np.nonzero(band.any(axis=0))[0]
    ys, xs = np.nonzero(band)
    return float(xs.mean()) if len(xs) else piece.width / 2


def pack_strip(frames, scale, cell, anchor_bottom=4, center_fn=torso_center, align="bottom"):
    cw, ch = cell
    strip = Image.new("RGBA", (cw * len(frames), ch), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        cx = center_fn(f) * scale
        g = f.resize((max(1, round(f.width * scale)), max(1, round(f.height * scale))), Image.LANCZOS)
        x = round(i * cw + cw / 2 - cx)
        y = ch - anchor_bottom - g.height if align == "bottom" else round((ch - g.height) / 2)
        strip.alpha_composite(g, (max(i * cw, x), max(0, y)))
    return strip


def fit(img, max_w=None, max_h=None):
    s = 1.0
    if max_w:
        s = min(s, max_w / img.width)
    if max_h:
        s = min(s, max_h / img.height)
    return img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)


def seamless_x(img, frac=0.18):
    """Crossfade the right end into the left end so the strip tiles horizontally."""
    arr = np.array(img).astype(np.float32)
    w = arr.shape[1]
    o = int(w * frac)
    head = arr[:, :o]
    tail = arr[:, w - o:]
    ramp = np.linspace(0.0, 1.0, o)[None, :, None]
    blended = tail * (1 - ramp) + head * ramp
    out = arr[:, : w - o].copy()
    out[:, :o] = blended
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def seamless_y(img, frac=0.18):
    return seamless_x(img.transpose(Image.TRANSPOSE), frac).transpose(Image.TRANSPOSE)


def seamless_xy(img):
    """Offset-blend a square texture so it wraps on both axes."""
    arr = np.array(img.convert("RGB")).astype(np.float32)
    h, w = arr.shape[:2]
    shifted = np.roll(np.roll(arr, h // 2, axis=0), w // 2, axis=1)
    yy, xx = np.mgrid[0:h, 0:w]
    dx = np.abs(xx / (w - 1) - 0.5) * 2
    dy = np.abs(yy / (h - 1) - 0.5) * 2
    weight = np.clip(1.0 - np.maximum(dx, dy), 0, 1) ** 0.7
    weight = weight[:, :, None]
    out = arr * weight + shifted * (1 - weight)
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))


def hero():
    idle = split_axis(clean_alpha(load("hero_idle")), 4)
    run = split_axis(clean_alpha(load("hero_run")), 6)
    poses = split_axis(clean_alpha(load("hero_poses")), 6)
    idle_h = np.median([f.height for f in idle])
    run_h = np.median([f.height for f in run])
    target = 104.0  # 2x texels -> ~52 world px tall
    s_idle = target / idle_h
    s_run = target * 0.97 / run_h
    cell = (150, 128)
    save(pack_strip(idle, s_idle, cell), "hero/idle.png")
    save(pack_strip(run, s_run, cell), "hero/run.png")
    names = ["jump", "fall", "wall", "dash", "land", "hurt"]
    for name, frame in zip(names, poses):
        save(pack_strip([frame], s_run, cell, anchor_bottom=4), f"hero/{name}.png")
    META["hero"] = {"cell": cell, "idle": 4, "run": 6, "feet": cell[1] - 4}
    lantern = clean_alpha(load("lantern"))
    lantern = lantern.crop(lantern.getchannel("A").getbbox())
    save(fit(lantern, max_h=46), "hero/lantern.png")


def enemies():
    specs = {"murkling": (4, 70), "wisp": (4, 84), "thornshade": (4, 64)}
    for name, (count, target_h) in specs.items():
        frames = split_axis(clean_alpha(load(name)), count)
        h = np.median([f.height for f in frames])
        w = max(f.width for f in frames)
        s = target_h / h
        cell = (int(w * s) + 16, int(max(f.height for f in frames) * s) + 12)
        align = "center" if name == "wisp" else "bottom"
        save(pack_strip(frames, s, cell, anchor_bottom=3, align=align, center_fn=lambda f: f.width / 2), f"enemies/{name}.png")
        META[name] = {"cell": cell, "frames": count}
    for name in ["boss_idle", "boss_stunned"]:
        img = clean_alpha(load(name))
        img = img.crop(img.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox())
        save(fit(img, max_h=360), f"boss/{name.split('_')[1]}.png")


def props():
    lamp = split_axis(clean_alpha(load("waylamp")), 2)
    for name, f in zip(["unlit", "lit"], lamp):
        save(fit(f, max_h=150), f"props/waylamp_{name}.png")
    brazier = split_axis(clean_alpha(load("brazier")), 2)
    # Keep the shared pedestal scale: fit both by the unlit width.
    s = 150 / brazier[0].width
    for name, f in zip(["unlit", "lit"], brazier):
        save(f.resize((round(f.width * s), round(f.height * s)), Image.LANCZOS), f"props/brazier_{name}.png")
    for name in ["beacon_unlit", "beacon_lit"]:
        if not os.path.exists(os.path.join(RAW, name + ".png")):
            continue
        img = clean_alpha(load(name))
        img = img.crop(img.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox())
        save(fit(img, max_h=400), f"props/{name}.png")
    ember = clean_alpha(load("ember"))
    ember = ember.crop(ember.getchannel("A").getbbox())
    save(fit(ember, max_h=64), "props/ember.png")
    thorns = clean_alpha(load("thorns"))
    thorns = thorns.crop(thorns.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox())
    thorns = fit(thorns, max_h=56)
    save(seamless_x(thorns, 0.12), "props/thorns.png")
    plats = split_axis(clean_alpha(load("platforms")), 3, axis=1)
    for name, f in zip(["plank", "spirit", "brass"], plats):
        save(fit(f, max_h=44 if name != "plank" else 30), f"props/platform_{name}.png")
    edges = split_axis(clean_alpha(load("edges")), 3, axis=1)
    for name, f in zip(["forest", "cave", "tower"], edges):
        g = fit(f, max_h=56 if name != "tower" else 40)
        save(seamless_x(g, 0.1), f"terrain/edge_{name}.png")


def terrain():
    for name in ["forest", "cave", "tower"]:
        img = Image.open(os.path.join(RAW, f"tex_{name}.png")).convert("RGB")
        img = img.resize((512, 512), Image.LANCZOS)
        if name != "tower":
            img = seamless_xy(img)
        save(img, f"terrain/fill_{name}.png")


def backgrounds():
    for name in ["forest", "cave"]:
        far = Image.open(os.path.join(RAW, f"bg_{name}_far.png")).convert("RGB")
        far = seamless_x(fit(far, max_h=900), 0.2)
        far.save(os.path.join(OUT, "bg", f"{name}_far.jpg"), quality=86) if os.path.isdir(os.path.join(OUT, "bg")) else None
        os.makedirs(os.path.join(OUT, "bg"), exist_ok=True)
        far.save(os.path.join(OUT, "bg", f"{name}_far.jpg"), quality=86)
        mid = clean_alpha(load(f"bg_{name}_mid"))
        save(seamless_x(fit(mid, max_h=900), 0.2), f"bg/{name}_mid.png")
    tower = Image.open(os.path.join(RAW, "bg_tower_far.png")).convert("RGB")
    seamless_y(fit(tower, max_w=900), 0.2).save(os.path.join(OUT, "bg", "tower_far.jpg"), quality=86)
    if os.path.exists(os.path.join(RAW, "bg_tower_mid.png")):
        mid = clean_alpha(load("bg_tower_mid"))
        save(seamless_y(fit(mid, max_w=1000), 0.2), "bg/tower_mid.png")
    bell = Image.open(os.path.join(RAW, "bg_belltop.png")).convert("RGB")
    fit(bell, max_w=1600).save(os.path.join(OUT, "bg", "belltop.jpg"), quality=86)
    title = Image.open(os.path.join(RAW, "title_art.png")).convert("RGB")
    fit(title, max_w=1920).save(os.path.join(OUT, "bg", "title.jpg"), quality=88)


def ui():
    panel = load("ui_panel")
    save(panel.resize((384, 384), Image.LANCZOS), "ui/panel.png")
    buttons = split_axis(clean_alpha(load("ui_buttons"), 4), 2, axis=1, min_gap=3)
    for name, f in zip(["normal", "hover"], buttons):
        save(f.resize((420, round(420 * f.height / f.width)), Image.LANCZOS), f"ui/button_{name}.png")
    icons = split_axis(clean_alpha(load("ui_icons")), 6)
    for name, f in zip(["watch", "candle", "flame", "beacon", "gear", "lantern"], icons):
        save(fit(f, max_w=96, max_h=96), f"ui/icon_{name}.png")


if __name__ == "__main__":
    steps = sys.argv[1:] or ["hero", "enemies", "props", "terrain", "backgrounds", "ui"]
    for step in steps:
        globals()[step]()
        print("done", step)
    if "hero" in steps or "enemies" in steps:
        with open(os.path.join(OUT, "sprite_meta.json"), "w") as fh:
            json.dump(META, fh, indent=1)
