#!/usr/bin/env python3
"""Authoring helper for data/levels/*.json.

The runtime only reads the JSON files. This script keeps the ASCII layouts in
readable horizontal segments (rows are right-padded with '.'), validates them
and writes the JSON. Edit a segment, run `python3 tools/build_levels.py`.

Legend (one tile = 32 px):
  #  solid ground          =  one-way plank          %  spirit stone (only solid in light)
  ^  floor thorns          v  ceiling thorns         l  glow crystal (small static light)
  P  spawn                 C  waylamp checkpoint     B  beacon (level goal)
  *  ember (3 per level)   w  murkling (stompable)   f  gloom wisp (flies)
  t  thornshade (flare only)                          Z  brazier (boss arena)
  X  boss anchor           1-9 tutorial hint trigger (index into "hints")
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "levels")
H = 22
FULL = "#"


def seg(width, rows, height=H):
    """rows: dict row_index -> string (padded with '.'), plus 'ground' rows."""
    out = []
    for r in range(height):
        line = rows.get(r, "")
        if line == FULL:
            line = "#" * width
        assert len(line) <= width, (r, len(line), width, line)
        out.append(line.ljust(width, "."))
    return out


def ground(width, top=17, pattern=None, height=H):
    rows = {}
    for r in range(top, height):
        rows[r] = pattern if pattern else "#" * width
    return rows


def join(*segments):
    rows = ["" for _ in range(len(segments[0]))]
    for s in segments:
        assert len(s) == len(rows)
        for i, line in enumerate(s):
            rows[i] += line
    return rows


def pit_rows(width, spans, top=17, height=H):
    """Ground from `top` with pits at spans [(start,end_exclusive)]. Pits have thorns at height-2."""
    rows = {}
    for r in range(top, height):
        line = list("#" * width)
        for a, b in spans:
            for c in range(a, b):
                if r == height - 1:
                    line[c] = "#"
                elif r == height - 2:
                    line[c] = "^"
                else:
                    line[c] = "."
        rows[r] = "".join(line)
    return rows


def merge(*dicts):
    out = {}
    for d in dicts:
        for k, v in d.items():
            if k in out and v:
                base = list(out[k].ljust(max(len(out[k]), len(v)), "."))
                for i, ch in enumerate(v):
                    if ch != ".":
                        base[i] = ch
                out[k] = "".join(base)
            else:
                out[k] = v
    return out


# --------------------------------------------------------------------------
# Level 1 — Whisperwood (teaches every verb, gentle)
# Reach rules: jump ~3 tiles up; ~4-tile gap by jump alone; 7 with a dash.
# --------------------------------------------------------------------------
def forest():
    s1 = seg(26, merge(ground(26), {
        14: "..................l",
        15: "..................##",
        16: "....P..1......l..###",
    }))
    s2 = seg(24, merge(pit_rows(24, [(4, 7), (13, 17)]), {
        12: "...............l",
        16: ".2",
    }))
    s3 = seg(30, merge(pit_rows(30, [(4, 24)]), {
        7: "..............*",
        8: ".............%%%",
        11: ".........%%%",
        14: "............%%%",
        15: "......%%%.........%%%",
        16: "..3",
    }))
    s4 = seg(28, merge(ground(28), {
        13: "......l",
        14: "..................####",
        15: "..................####",
        16: ".C..4.......w.....####.....w",
    }))
    s5 = seg(30, merge(ground(30), {
        11: "..............f",
        14: ".........................l",
        16: "..5.......t.............t",
    }))
    s6_rows = {r: ".....##...####################" for r in range(4, 15)}
    s6_rows.update({3: ".....*", 4: ".....##", 5: ".....##", 6: ".....##.........f",
                    15: "..........####################", 16: ".6........####################"})
    s6 = seg(30, merge(ground(30), s6_rows))
    s7_rows = {r: "########" for r in range(7, 17)}
    s7_rows.update({6: "...C.7", 8: "########.......######", 9: "########.......######",
                    12: "......................====",
                    14: "########.............f",
                    17: "########^^^^^^^^^^^^^^^^^^########"})
    s7 = seg(34, merge(s7_rows, {r: "#" * 34 for r in range(18, H)}))
    s8 = seg(36, merge(ground(36), {
        7: "..........*",
        8: ".........%%%",
        11: ".............%%%",
        12: "..........................l",
        14: ".........%%%",
        16: "...8...............w.........B",
    }))
    rows = join(s1, s2, s3, s4, s5, s6, s7, s8)
    return {
        "id": "forest", "order": 1, "theme": "forest", "music": "explore",
        "name_key": "level.forest.name", "subtitle_key": "level.forest.subtitle",
        "darkness": 0.8, "camera_zoom": 1.1, "par_time": 150,
        "hints": ["hint.move", "hint.variable_jump", "hint.spirit", "hint.stomp",
                  "hint.flare", "hint.walljump", "hint.dash", "hint.beacon"],
        "map": rows,
    }


# --------------------------------------------------------------------------
# Level 2 — Echo Caverns (darker, flare scouting, chimney climb, dash under thorns)
# --------------------------------------------------------------------------
def cave():
    ceil = {0: FULL, 1: FULL}
    c1 = seg(26, merge(ceil, ground(26), {
        2: "##########vvvv############",
        3: "###.....................##",
        4: "##.......................#",
        12: "...........l",
        16: "....P............l",
    }))
    c2 = seg(32, merge(ceil, pit_rows(32, [(3, 28)]), {
        2: "#######vvvvvvv###########vvvvvvv",
        7: "................*",
        8: "...............%%%",
        11: ".........%%%.........f",
        14: "..........%%%...%%%",
        15: ".....%%%..............%%%",
    }))
    c3 = seg(30, merge(ceil, ground(30), {
        **{r: FULL for r in range(2, 10)},
        10: "######vvvvv......vvvvvv.######",
        16: ".C.......w.......w......l",
    }))
    c4 = seg(34, merge(ceil, pit_rows(34, [(2, 31)]), {
        2: FULL,
        3: "######vvvv####vvvvvvvv####vvvv####",
        4: "######....####........####....####",
        9: "..................f",
        14: "...........%%....%%",
        15: ".....%%................%%....%%",
        16: ".1",
    }))
    c5_rows = {2: FULL, 3: "######*.........................", 4: "######....................f....."}
    for r in range(5, 15):
        c5_rows[r] = "#########...####################"
    c5_rows[15] = "............####################"
    c5_rows[16] = "..2.........####################"
    c5 = seg(32, merge(ceil, c5_rows, {r: FULL for r in range(17, H)}))
    c6_rows = {2: FULL, 3: "................########", 4: "................########......f"}
    for r in range(5, 11):
        c6_rows[r] = "##########......########"
    c6_rows[11] = "##########......vvvvvvvv"
    for r in range(12, 17):
        c6_rows[r] = "##########"
    c6_rows[15] = "##########..3"
    c6_rows[16] = "##########.C...................t"
    c6_rows[13] = "##########.......................l"
    c6 = seg(34, merge(ceil, pit_rows(34, [(16, 22)]), c6_rows))
    c7 = seg(34, merge(ceil, ground(34), {
        2: FULL,
        5: "........................*",
        6: ".......................%%%",
        9: "...................%%%",
        10: "..............................####",
        11: "..............f...............####",
        12: "...............%%%............####",
        13: "..............................####",
        14: "..........%%%............###..####",
        15: ".....l........................####",
        16: "......t.............w.......B.####",
    }))
    rows = join(c1, c2, c3, c4, c5, c6, c7)
    return {
        "id": "cave", "order": 2, "theme": "cave", "music": "explore",
        "name_key": "level.cave.name", "subtitle_key": "level.cave.subtitle",
        "darkness": 0.9, "camera_zoom": 1.1, "par_time": 180,
        "hints": ["hint.flare_scout", "hint.shaft", "hint.dash_low"],
        "map": rows,
    }


# --------------------------------------------------------------------------
# Level 3 — Rustbell Tower (vertical climb; floor holes are one-way planks)
# --------------------------------------------------------------------------
def tower():
    W = 30
    top = [
        "##############################",
        "##..........................##",
        "##..........................##",
        "##..........................##",
        "##...........B..............##",
        "##......########.......l....##",
        "##..........................##",
    ]
    f6 = [
        "##..........................##",
        "##...====...................##",
        "##..........................##",
        "##..........====.....f......##",
        "##..........................##",
        "##..........................##",
        "##................====......##",
        "##..........................##",
        "##....w...............C.....##",
        "######################====####",
    ]
    f5 = [
        "##..........................##",
        "##..*.......................##",
        "##.====...............====..##",
        "##..........................##",
        "##.................f........##",
        "##........##.....##...########",
        "##........##.....##...########",
        "##....^^^^##^^^^^##^^^########",
        "##====########################",
    ]
    f4 = [
        "##..........................##",
        "##.%%%%.....................##",
        "##..........................##",
        "##........%%%...............##",
        "##..........................##",
        "##..............%%%.....f...##",
        "##..........................##",
        "##....................%%%%..##",
        "##..........................##",
        "##.l.....................C..##",
        "######################====####",
    ]
    f3 = [
        "##..........................##",
        "##..........l...............##",
        "####################...#######",
        "####################...#######",
        "####################...#######",
        "####################...#######",
        "####################...#######",
        "####################...#######",
        "####################...#######",
        "##.......................t.*##",
        "##..........................##",
        "####====######################",
    ]
    f2 = [
        "##..........................##",
        "##..........................##",
        "##..=====...................##",
        "##.......................*..##",
        "##..........====.........===##",
        "##..........................##",
        "##..........................##",
        "##................====......##",
        "##.......w..................##",
        "##.l.....................C..##",
        "######################====####",
    ]
    f1 = [
        "##..........................##",
        "##..........................##",
        "##..................====....##",
        "##..........................##",
        "##.............====.........##",
        "##..........................##",
        "##.......====...............##",
        "##..........................##",
        "##...P.1..........l.........##",
        "##############################",
        "##############################",
    ]
    rows = top + f6 + f5 + f4 + f3 + f2 + f1
    for r in rows:
        assert len(r) == W, (len(r), r)
    return {
        "id": "tower", "order": 3, "theme": "tower", "music": "explore",
        "name_key": "level.tower.name", "subtitle_key": "level.tower.subtitle",
        "darkness": 0.88, "camera_zoom": 1.05, "par_time": 200, "vertical": True,
        "hints": ["hint.tower"],
        "map": rows,
    }


# --------------------------------------------------------------------------
# Boss — Belltop, Murkmaw. Braziers are indexed in reading order:
# 0 = top centre, 1 = left ledge, 2 = right ledge.
# --------------------------------------------------------------------------
def boss():
    rows = [
        "########################################",
        "##....................................##",
        "##....................................##",
        "##.................Z..................##",
        "##...............=====................##",
        "##....................................##",
        "##Z...................................##",
        "####..............%%%%..............Z.##",
        "##..................................####",
        "##....................X...............##",
        "##====.......%%%%.......%%%%......%%%.##",
        "##....................................##",
        "##....................................##",
        "##......====.....======.........%%%%..##",
        "##....................................##",
        "##....................................##",
        "##=====.....................%%%%......##",
        "##....................................##",
        "##.......P.....................l......##",
        "########################################",
        "########################################",
        "########################################",
    ]
    for r in rows:
        assert len(r) == 40, (len(r), r)
    return {
        "id": "boss", "order": 4, "theme": "belltop", "music": "boss",
        "name_key": "level.boss.name", "subtitle_key": "level.boss.subtitle",
        "darkness": 0.7, "camera_zoom": 1.0, "par_time": 150, "arena": True,
        "hints": [],
        "boss": {
            "hp": 3,
            "hover_row": 5,
            "phases": [
                {"brazier": 1, "attacks": ["rain", "wave", "rain"], "rain_count": 4, "speed": 1.0},
                {"brazier": 2, "attacks": ["wave", "rain", "summon", "rain"], "rain_count": 5, "speed": 1.15},
                {"brazier": 0, "attacks": ["slam", "rain", "wave", "summon", "slam"], "rain_count": 6, "speed": 1.3},
            ],
        },
        "map": rows,
    }


def validate(level):
    rows = level["map"]
    width = max(len(r) for r in rows)
    level["map"] = [r.ljust(width, ".") for r in rows]
    text = "".join(level["map"])
    assert text.count("P") == 1, (level["id"], "spawn")
    if level["id"] != "boss":
        assert text.count("B") == 1, (level["id"], "beacon")
        assert text.count("*") == 3, (level["id"], "embers", text.count("*"))
    else:
        assert text.count("Z") == 3 and text.count("X") == 1
    hints = sum(text.count(str(i)) for i in range(1, 10))
    assert hints == len(level["hints"]), (level["id"], hints, len(level["hints"]))
    return width, len(rows)


def main():
    os.makedirs(OUT, exist_ok=True)
    order = []
    for build in (forest, cave, tower, boss):
        level = build()
        w, h = validate(level)
        order.append(level["id"])
        with open(os.path.join(OUT, level["id"] + ".json"), "w") as fh:
            rows = level.pop("map")
            text = json.dumps(level, indent=1, ensure_ascii=False)
            # Keep the map readable: one row per line.
            text = text[:-2] + ',\n "map": [\n' + ",\n".join('  "%s"' % r for r in rows) + "\n ]\n}\n"
            fh.write(text)
        print(f"{level['id']}: {w}x{h}")
    with open(os.path.join(OUT, "campaign.json"), "w") as fh:
        json.dump({"order": order}, fh, indent=1)


if __name__ == "__main__":
    main()
