#!/usr/bin/env python3
"""Generate config/tuning.json (single source of gameplay parameters) and the
matching tuning.* localization keys. Edit the TABLE below, then run:
    python3 tools/gen_tuning.py
Rows: key, category, type, default, min, max, step, decimals, apply, integrity, en label, zh label, en desc, zh desc, unit
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G, C = "GAMEPLAY", "COSMETIC"
TABLE = [
    # --- player movement (px, px/s, px/s^2, seconds) ---
    ("run_speed", "PLAYER", "integer", 250, 120, 450, 5, 0, "LIVE", G, "Run speed", "奔跑速度", "Top horizontal speed.", "水平最高速度。", "px/s"),
    ("ground_accel", "PLAYER", "integer", 2600, 500, 6000, 50, 0, "LIVE", G, "Ground acceleration", "地面加速度", "How fast running reaches top speed.", "起跑达到最高速的快慢。", ""),
    ("ground_decel", "PLAYER", "integer", 3200, 500, 7000, 50, 0, "LIVE", G, "Ground braking", "地面制动", "How fast the traveler stops.", "松开方向后停下的快慢。", ""),
    ("air_accel", "PLAYER", "integer", 1900, 400, 5000, 50, 0, "LIVE", G, "Air control", "空中操控", "Horizontal acceleration while airborne.", "空中水平加速度。", ""),
    ("gravity", "PLAYER", "integer", 1700, 800, 3500, 25, 0, "LIVE", G, "Gravity", "重力", "Rising gravity.", "上升阶段重力。", ""),
    ("fall_gravity_mult", "PLAYER", "float", 1.25, 1.0, 2.5, 0.05, 2, "LIVE", G, "Fall gravity ×", "下落重力倍率", "Extra gravity while falling for snappy arcs.", "下落时额外重力，让弧线更利落。", ""),
    ("max_fall_speed", "PLAYER", "integer", 640, 300, 1200, 10, 0, "LIVE", G, "Max fall speed", "最大下落速度", "Terminal velocity.", "下落速度上限。", "px/s"),
    ("fast_fall_speed", "PLAYER", "integer", 820, 300, 1400, 10, 0, "LIVE", G, "Fast-fall speed", "快速下落速度", "Terminal velocity while holding down.", "按住下时的下落上限。", "px/s"),
    ("jump_speed", "PLAYER", "integer", 600, 380, 900, 5, 0, "LIVE", G, "Jump speed", "起跳速度", "Initial jump velocity (sets max height).", "起跳初速度，决定最大跳高。", "px/s"),
    ("jump_cut", "PLAYER", "float", 0.45, 0.1, 1.0, 0.05, 2, "LIVE", G, "Short-hop cut", "短跳截断", "Upward speed kept when jump is released early.", "提前松开跳跃时保留的上升速度比例。", ""),
    ("apex_gravity_mult", "PLAYER", "float", 0.55, 0.2, 1.0, 0.05, 2, "LIVE", G, "Apex hang", "顶点滞空", "Gravity multiplier near the top of a held jump.", "按住跳跃时顶点附近的重力倍率。", ""),
    ("apex_threshold", "PLAYER", "integer", 70, 0, 200, 5, 0, "LIVE", G, "Apex window", "顶点区间", "Vertical speed range treated as the apex.", "视为跳跃顶点的竖直速度区间。", "px/s"),
    ("coyote_time", "PLAYER", "float", 0.10, 0.0, 0.3, 0.01, 2, "LIVE", G, "Coyote time", "土狼时间", "Grace time to jump after leaving a ledge.", "离开平台后仍可起跳的宽限时间。", "s"),
    ("jump_buffer", "PLAYER", "float", 0.12, 0.0, 0.3, 0.01, 2, "LIVE", G, "Jump buffer", "跳跃缓冲", "Early jump presses are remembered this long.", "提前按下跳跃会被记住的时长。", "s"),
    ("wall_slide_speed", "PLAYER", "integer", 120, 30, 400, 5, 0, "LIVE", G, "Wall slide speed", "贴墙滑落速度", "Max fall speed while sliding on a wall.", "贴墙滑落时的最大速度。", "px/s"),
    ("wall_jump_x", "PLAYER", "integer", 290, 100, 600, 5, 0, "LIVE", G, "Wall jump push", "蹬墙水平力", "Horizontal launch away from the wall.", "蹬墙跳离墙的水平速度。", "px/s"),
    ("wall_jump_y", "PLAYER", "integer", 570, 300, 900, 5, 0, "LIVE", G, "Wall jump lift", "蹬墙上升力", "Vertical launch of a wall jump.", "蹬墙跳的竖直速度。", "px/s"),
    ("wall_jump_lock", "PLAYER", "float", 0.13, 0.0, 0.4, 0.01, 2, "LIVE", G, "Wall jump steer lock", "蹬墙转向锁定", "Time steering toward the wall is damped after a wall jump.", "蹬墙后朝墙方向操控被抑制的时间。", "s"),
    ("wall_coyote", "PLAYER", "float", 0.09, 0.0, 0.25, 0.01, 2, "LIVE", G, "Wall coyote time", "蹬墙宽限", "Grace time to wall jump after leaving a wall.", "离墙后仍可蹬墙跳的宽限时间。", "s"),
    ("dash_speed", "PLAYER", "integer", 580, 250, 1000, 10, 0, "LIVE", G, "Dash speed", "冲刺速度", "Speed during the air dash.", "冲刺期间速度。", "px/s"),
    ("dash_time", "PLAYER", "float", 0.15, 0.05, 0.4, 0.01, 2, "LIVE", G, "Dash duration", "冲刺时长", "Length of one dash.", "单次冲刺持续时间。", "s"),
    ("dash_carry", "PLAYER", "float", 0.55, 0.0, 1.0, 0.05, 2, "LIVE", G, "Dash momentum carry", "冲刺惯性保留", "Share of dash speed kept after the dash.", "冲刺结束后保留的速度比例。", ""),
    ("stomp_bounce", "PLAYER", "integer", 430, 200, 800, 10, 0, "LIVE", G, "Stomp bounce", "踩踏弹跳", "Bounce after stomping an enemy.", "踩敌后的弹起速度。", "px/s"),
    ("stomp_bounce_held", "PLAYER", "integer", 590, 200, 900, 10, 0, "LIVE", G, "Stomp bounce (held)", "踩踏弹跳（按住）", "Bounce when jump is held during a stomp.", "踩敌时按住跳跃的弹起速度。", "px/s"),
    ("respawn_delay", "GAMEPLAY", "float", 0.55, 0.1, 2.0, 0.05, 2, "LIVE", G, "Respawn delay", "重生延迟", "Time from failure to rekindling at the checkpoint.", "失败到在检查点重生的时间。", "s"),
    # --- lantern ---
    ("lantern_radius", "GAMEPLAY", "integer", 160, 60, 400, 5, 0, "LIVE", G, "Lantern radius", "灯笼照亮半径", "Base light radius around the traveler.", "角色周围基础照亮半径。", "px"),
    ("flare_radius", "GAMEPLAY", "integer", 280, 100, 520, 5, 0, "LIVE", G, "Flare radius", "灯光爆发半径", "Light radius while holding the lantern flare.", "按住灯光爆发时的半径。", "px"),
    ("flare_drain", "GAMEPLAY", "float", 0.55, 0.05, 3.0, 0.05, 2, "LIVE", G, "Flare drain", "爆发消耗", "Lantern oil used per second of flare.", "每秒爆发消耗的灯油。", "/s"),
    ("flare_regen", "GAMEPLAY", "float", 0.40, 0.05, 3.0, 0.05, 2, "LIVE", G, "Oil regen", "灯油恢复", "Lantern oil regained per second.", "每秒恢复的灯油。", "/s"),
    ("flare_regen_delay", "GAMEPLAY", "float", 0.45, 0.0, 2.0, 0.05, 2, "LIVE", G, "Oil regen delay", "恢复延迟", "Pause before oil starts refilling.", "停止爆发后开始恢复前的停顿。", "s"),
    ("reveal_threshold", "GAMEPLAY", "float", 0.30, 0.05, 0.9, 0.05, 2, "LIVE", G, "Reveal threshold", "显形阈值", "Light level needed for spirit platforms to become solid.", "灵石平台变为实体所需的光照强度。", ""),
    ("spirit_linger", "GAMEPLAY", "float", 0.7, 0.0, 3.0, 0.05, 2, "LIVE", G, "Spirit linger", "灵石余留", "Seconds a revealed platform stays solid after light leaves.", "光离开后灵石平台保持实体的时间。", "s"),
    # --- enemies ---
    ("murkling_speed", "ENEMIES", "integer", 48, 10, 200, 2, 0, "NEXT_SPAWN", G, "Murkling patrol", "雾团巡逻速度", "Patrol speed of murklings.", "雾团的巡逻速度。", "px/s"),
    ("murkling_chase", "ENEMIES", "integer", 88, 10, 250, 2, 0, "NEXT_SPAWN", G, "Murkling chase", "雾团追击速度", "Speed after spotting the traveler.", "发现角色后的速度。", "px/s"),
    ("wisp_speed", "ENEMIES", "integer", 62, 10, 250, 2, 0, "NEXT_SPAWN", G, "Wisp drift", "幽影飘移速度", "Chase speed of gloom wisps.", "幽影的追踪速度。", "px/s"),
    ("thornshade_speed", "ENEMIES", "integer", 36, 10, 200, 2, 0, "NEXT_SPAWN", G, "Thornshade crawl", "棘影爬行速度", "Crawl speed of thornshades.", "棘影的爬行速度。", "px/s"),
    ("enemy_aggro_range", "ENEMIES", "integer", 180, 40, 500, 5, 0, "NEXT_SPAWN", G, "Aggro range", "警觉距离", "Distance at which enemies notice the traveler.", "敌人察觉角色的距离。", "px"),
    ("murkling_tolerance", "ENEMIES", "float", 0.35, 0.05, 3.0, 0.05, 2, "LIVE", G, "Murkling light tolerance", "雾团耐光", "Seconds of flare needed to dispel a murkling.", "驱散雾团所需的爆发照射秒数。", "s"),
    ("wisp_tolerance", "ENEMIES", "float", 0.25, 0.05, 3.0, 0.05, 2, "LIVE", G, "Wisp light tolerance", "幽影耐光", "Seconds of flare needed to dispel a wisp.", "驱散幽影所需的爆发照射秒数。", "s"),
    ("thornshade_tolerance", "ENEMIES", "float", 0.6, 0.05, 3.0, 0.05, 2, "LIVE", G, "Thornshade light tolerance", "棘影耐光", "Seconds of flare needed to dispel a thornshade.", "驱散棘影所需的爆发照射秒数。", "s"),
    # --- boss ---
    ("boss_stun_time", "ENEMIES", "float", 4.5, 1.0, 10.0, 0.1, 1, "NEXT_STAGE", G, "Boss stun time", "Boss 眩晕时长", "How long Murkmaw stays stunned by a brazier.", "火盆点燃后雾噬的眩晕时长。", "s"),
    ("boss_attack_gap", "ENEMIES", "float", 1.6, 0.4, 5.0, 0.1, 1, "NEXT_STAGE", G, "Boss attack gap", "Boss 攻击间隔", "Rest between Murkmaw attacks.", "雾噬两次攻击之间的休息。", "s"),
    ("boss_telegraph", "ENEMIES", "float", 0.85, 0.3, 2.0, 0.05, 2, "NEXT_STAGE", G, "Boss telegraph", "Boss 预警时长", "Warning time before each attack lands.", "每次攻击落下前的预警时间。", "s"),
    # --- presentation ---
    ("camera_zoom_scale", "UI", "float", 1.0, 0.6, 1.6, 0.05, 2, "LIVE", C, "Camera zoom ×", "镜头缩放倍率", "Multiplies each level's camera zoom.", "乘以每关的镜头缩放。", ""),
    ("camera_smoothing", "UI", "float", 7.0, 1.0, 20.0, 0.5, 1, "LIVE", C, "Camera follow", "镜头跟随", "Camera follow sharpness.", "镜头跟随的紧密程度。", ""),
    ("shake_strength", "UI", "float", 1.0, 0.0, 2.0, 0.05, 2, "LIVE", C, "Shake strength", "震屏强度", "Screen shake multiplier.", "屏幕震动倍率。", ""),
    ("hitstop_scale", "UI", "float", 1.0, 0.0, 2.0, 0.05, 2, "LIVE", C, "Hit-stop", "打击停顿", "Freeze-frame length multiplier on impacts.", "命中时定帧时长倍率。", ""),
    ("darkness_scale", "ENVIRONMENT", "float", 1.0, 0.0, 1.3, 0.05, 2, "LIVE", C, "Murk darkness", "黑雾浓度", "Multiplies each level's darkness.", "乘以每关的黑暗程度。", ""),
    ("audio_master", "AUDIO", "float", 1.0, 0.0, 1.0, 0.05, 2, "LIVE", C, "Master level", "总音量电平", "Owner mix trim for all audio.", "开发者总混音修正。", ""),
    ("audio_music", "AUDIO", "float", 1.0, 0.0, 1.0, 0.05, 2, "LIVE", C, "Music level", "音乐电平", "Owner mix trim for music.", "开发者音乐混音修正。", ""),
    ("audio_sfx", "AUDIO", "float", 1.0, 0.0, 1.0, 0.05, 2, "LIVE", C, "SFX level", "音效电平", "Owner mix trim for sound effects.", "开发者音效混音修正。", ""),
    ("audio_ui", "AUDIO", "float", 1.0, 0.0, 1.0, 0.05, 2, "LIVE", C, "UI level", "界面音电平", "Owner mix trim for interface sounds.", "开发者界面音混音修正。", ""),
    # --- player settings (saved per player) ---
    ("display_mode", "UI", "enum", 0, 0, 1, 1, 0, "LIVE", C, "Display mode", "显示模式", "Fixed 16:9 frame or adaptive fill.", "固定 16:9 或自适应铺满。", ""),
    ("reduced_motion", "UI", "boolean", 0, 0, 1, 1, 0, "LIVE", C, "Reduce screen shake", "减弱震屏", "Disables screen shake and flashes.", "关闭屏幕震动与闪光。", ""),
    ("effects_quality", "ENVIRONMENT", "enum", 1, 0, 1, 1, 0, "LIVE", C, "Effects quality", "特效质量", "Low trims fog, particles and parallax detail.", "低画质会精简雾气、粒子与视差细节。", ""),
]
UNITS = {"px/s": ("px/s", "像素/秒"), "px": ("px", "像素"), "s": ("s", "秒"), "/s": ("/s", "/秒")}
CHOICES = {"display_mode": ["tuning.display.fixed", "tuning.display.adaptive"], "effects_quality": ["tuning.quality.low", "tuning.quality.high"]}


def main():
    settings, en, zh = [], {}, {}
    for key, cat, typ, d, lo, hi, step, dec, apply, integ, len_, lzh, den, dzh, unit in TABLE:
        s = {"key": key, "default": d, "min": lo, "max": hi, "step": step, "decimals": dec,
             "id": f"{cat.lower()}.{key}", "category": cat, "type": typ, "apply_mode": apply,
             "integrity": integ, "label_key": f"tuning.setting.{key}", "description_key": f"tuning.description.{key}",
             "unit_key": f"tuning.unit.{UNITS[unit][0].replace('/', 'per_')}" if unit else "", "tags": [cat.lower(), key]}
        if key in CHOICES:
            s["choices"] = CHOICES[key]
        settings.append(s)
        en[s["label_key"]], zh[s["label_key"]] = len_, lzh
        en[s["description_key"]], zh[s["description_key"]] = den, dzh
        if unit:
            en[s["unit_key"]], zh[s["unit_key"]] = UNITS[unit]
    for cat, e, z in [("UI", "Presentation", "表现"), ("GAMEPLAY", "Lantern & flow", "灯笼与流程"), ("AUDIO", "Audio", "音频"),
                      ("PLAYER", "Movement", "移动手感"), ("ENEMIES", "Enemies & boss", "敌人与 Boss"), ("ENVIRONMENT", "Environment", "环境")]:
        en[f"tuning.category.{cat}"], zh[f"tuning.category.{cat}"] = e, z
    for k, e, z in [("tuning.display.fixed", "Fixed 16:9", "固定 16:9"), ("tuning.display.adaptive", "Adaptive", "自适应"),
                    ("tuning.quality.low", "Low", "低"), ("tuning.quality.high", "High", "高")]:
        en[k], zh[k] = e, z
    with open(os.path.join(ROOT, "config", "tuning.json"), "w") as fh:
        json.dump({"version": 4, "settings": settings}, fh, indent=1, ensure_ascii=False)
    with open(os.path.join(ROOT, "tools", "tuning_strings.json"), "w") as fh:
        json.dump({"en": en, "zh-CN": zh}, fh, indent=1, ensure_ascii=False)
    print(len(settings), "settings")


if __name__ == "__main__":
    main()
