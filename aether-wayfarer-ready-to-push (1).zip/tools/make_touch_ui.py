#!/usr/bin/env python3
"""Generate touch-button textures (assets/art/ui/touch_*.png) in the game's
ink + warm-gold style. Re-run after changing sizes or colours."""
import os
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "assets", "art", "ui")
S = 192
GOLD = (255, 200, 110)
CREAM = (251, 233, 200)


def base(pressed):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse((10, 10, S - 10, S - 10), fill=(255, 170, 70, 120 if pressed else 40))
    glow = glow.filter(ImageFilter.GaussianBlur(8))
    im.alpha_composite(glow)
    d = ImageDraw.Draw(im)
    fill = (70, 42, 30, 205) if pressed else (18, 12, 26, 150)
    d.ellipse((18, 18, S - 18, S - 18), fill=fill)
    d.ellipse((18, 18, S - 18, S - 18), outline=GOLD + (230,), width=6)
    d.ellipse((30, 30, S - 30, S - 30), outline=CREAM + (70,), width=2)
    return im, d


def arrow(d, direction):
    c = S / 2
    w = 34
    if direction == "left":
        pts = [(c + w * 0.7, c - w), (c - w * 0.9, c), (c + w * 0.7, c + w)]
    else:
        pts = [(c - w * 0.7, c - w), (c + w * 0.9, c), (c - w * 0.7, c + w)]
    d.polygon(pts, fill=CREAM + (255,))


def jump(d):
    c = S / 2
    d.polygon([(c - 36, c + 18), (c, c - 26), (c + 36, c + 18), (c + 20, c + 18), (c, c - 4), (c - 20, c + 18)], fill=CREAM + (255,))
    d.rectangle((c - 30, c + 30, c + 30, c + 38), fill=CREAM + (200,))


def dash(d):
    c = S / 2
    for off in (-22, 12):
        x = c + off
        d.polygon([(x - 14, c - 30), (x + 18, c), (x - 14, c + 30), (x - 2, c), ], fill=CREAM + (255,))
    d.line((c - 58, c - 12, c - 40, c - 12), fill=CREAM + (150,), width=5)
    d.line((c - 62, c + 12, c - 42, c + 12), fill=CREAM + (150,), width=5)


def lantern(d):
    c = S / 2
    d.ellipse((c - 26, c - 22, c + 26, c + 30), fill=(230, 70, 50, 255))
    d.ellipse((c - 14, c - 10, c + 14, c + 18), fill=(255, 210, 120, 255))
    d.rectangle((c - 16, c - 32, c + 16, c - 22), fill=GOLD + (255,))
    d.rectangle((c - 12, c + 28, c + 12, c + 36), fill=GOLD + (255,))
    d.arc((c - 12, c - 50, c + 12, c - 26), 180, 360, fill=CREAM + (255,), width=4)
    for a in range(0, 360, 45):
        import math
        r0, r1 = 42, 52
        x0, y0 = c + math.cos(math.radians(a)) * r0, c + 4 + math.sin(math.radians(a)) * r0
        x1, y1 = c + math.cos(math.radians(a)) * r1, c + 4 + math.sin(math.radians(a)) * r1
        d.line((x0, y0, x1, y1), fill=GOLD + (200,), width=4)


def main():
    for name, fn in (("left", lambda d: arrow(d, "left")), ("right", lambda d: arrow(d, "right")),
                     ("jump", jump), ("dash", dash), ("lantern", lantern)):
        for pressed in (False, True):
            im, d = base(pressed)
            fn(d)
            im.save(os.path.join(OUT, "touch_%s%s.png" % (name, "_on" if pressed else "")))
    print("touch textures written")


if __name__ == "__main__":
    main()
