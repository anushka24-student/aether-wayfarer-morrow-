# Aether Wayfarer — Account Backend Plan

## User outcomes

Players can log in to an account from the game, save a profile, resume campaign progress across devices, and keep game records tied to that account. The existing offline/local save remains the immediate fallback when the player is anonymous or the service is unavailable; cloud data is authoritative only after an authenticated session is confirmed.

## Architecture

- Keep the project as a Godot game with the existing `true` → `site` build and add the managed hybrid backend through Webdev configuration.
- Install the supported Manus authentication bridge (`ManusAuth`) in the authored Godot web shell and autoload. Use the canonical OAuth/session flow; do not add a custom JWT, `/api/auth/*` protocol, or client-owned identity field.
- Add a protected server router with procedures for `profile.get`, `profile.update`, `save.get`, `save.upsert`, and `records.list`/`records.append`. Every procedure derives ownership from `ctx.user`; the client never supplies an authoritative user ID.
- Store one profile row per canonical user, one versioned progress document per user/game, and append-only bounded game records keyed to the canonical user. Validate payload shape, size, version, and record fields on the server; reject anonymous writes.
- Add a Godot `CloudProfile`/sync autoload that observes `ManusAuth.auth_state_changed`, exposes login/logout/session state to the title menu, pulls cloud progress after confirmed login, merges local and cloud data deterministically, and pushes changes only through protected procedures. Offline saves continue to use `user://`.
- Preserve gameplay contracts: `SaveStore` remains the local API used by levels and HUD; cloud sync wraps it rather than changing level mechanics. A cloud save never blocks platforming or overwrites newer local data without a merge decision.
- Add an account/profile panel to the existing title/settings UI using the current bilingual localization system. Include signed-in display name/email-safe label, sync status, Log In, Log Out, and retry/error states. Never expose tokens or raw callback URLs.

## Project structure

- `server/` — installed Webdev auth server, database migration, router procedures, and server package lock.
- `scripts/manus_auth.gd` — installed browser bridge autoload for login/session state.
- `scripts/cloud_profile.gd` — game-specific profile/progress/records sync state machine.
- `scripts/save_store.gd` — existing local save API, extended with versioned export/import/merge helpers.
- `scripts/flow/title_menu.gd`, `scripts/ui/ui_kit.gd`, `scripts/ui/hud.gd` — account panel and sync feedback using existing visual language.
- `localization/en.json`, `localization/zh-CN.json` — all new account and sync copy.
- `web/loading.html`, `export_presets.cfg` — supported ManusAuth startup gate in the authored shell.

## Design

Use the existing ethereal fantasy-tech language rather than introducing a second visual system. The account panel is a compact “wayfarer sigil” overlay: indigo glass, cyan focus outlines, violet status accents, and a small lantern/sync glyph. Interaction is direct and reversible: Login is a clear primary action, cloud sync status is always visible, and offline mode is described plainly. English and Simplified Chinese remain first-class.

## Delivery boundary

Implement the login bridge, protected backend procedures, profile/progress/game-record persistence, local fallback and merge behavior, bilingual account UI, migrations, configuration, preview build, and source-level validation. Do not add multiplayer, social features, payments, or a new identity provider beyond the supported Manus login capability.
