# ✦ Aether Wayfarer 🌙

> *An ethereal fantasy-tech platformer where your lantern reveals the path ahead.* ✨

<p align="center">
  <a href="https://aetherway-cuc4pfp4.manus.game"><strong>🌌 PLAY AETHER WAYFARER</strong></a>
</p>

<p align="center"><em>Explore the unknown · Light the way · Find your path</em></p>

---

## 🌠 About the Game

**Aether Wayfarer** is a 2D fantasy platformer set in a murk-swallowed world. Guide the wayfarer through atmospheric environments, use a lantern to reveal the route, and navigate precision-platforming challenges.

🎮 **Play online:** [aetherway-cuc4pfp4.manus.game](https://aetherway-cuc4pfp4.manus.game)

## ✨ Gameplay

- 🏃 Precision platforming with running and jumping
- 🧗 Movement challenges including wall-jumps and dashes
- 🏮 A lantern-centered world and visibility mechanic
- 🌲 Atmospheric fantasy environments, hazards, and enemies
- 🎵 Original project audio and visual effects included in the source tree

*Features are described from the supplied project files; test the current build before treating this list as a release checklist.*

## 🕹️ Controls

Check the in-game title screen and settings for the current control mapping. Update this section if the bindings change.

## 🛠️ Built With

- 🎮 **Godot Engine** — game engine and project format
- 🧩 **GDScript** — gameplay and UI scripts
- 🌐 **Web export** — browser-playable build
- ✨ **Manus** — AI-assisted development workflow

## 📁 Project Structure

```text
.
├── assets/         # Art, audio, fonts, and sharing assets
├── autoload/       # Global services and localization
├── config/         # Gameplay tuning
├── data/           # Levels, stages, enemies, and themes
├── localization/   # Language resources
├── scenes/         # Godot scenes
├── scripts/        # Gameplay, UI, actors, and world logic
├── server/         # Optional account/profile backend source
├── shaders/        # Visual shaders
├── test/           # Game and regression tests
├── web/            # Browser loader resources
└── project.godot   # Main Godot project configuration
```

## 🚀 Run Locally

1. Install the Godot version compatible with this project and its Web export templates.
2. Clone this repository:

   ```bash
   git clone https://github.com/YOUR-USERNAME/aether-wayfarer.git
   cd aether-wayfarer
   ```
3. Import `project.godot` in Godot and run the main scene.

The optional account/profile backend has separate runtime requirements and protected environment configuration. The game can be explored as a source project without publishing any credentials.

## 🌐 Live Demo

[✨ Open Aether Wayfarer in your browser](https://aetherway-cuc4pfp4.manus.game)

## 🧑‍💻 Creator

**Anushka Maurya**

Built with curiosity, creativity, and a love for bringing ideas to life. 🌙

## 🔐 Security & Credits

- Never commit `.env` files, OAuth secrets, database URLs, signing secrets, or API tokens.
- Check the included asset/font provenance and license notices before redistributing the project or its assets.
- No license is declared by this README. Add one only after confirming you have the right to license the code and assets.

---

<p align="center"><em>🌌 Every journey begins beyond the familiar. 🌌</em></p>
