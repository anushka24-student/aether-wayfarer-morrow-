extends SceneTree
## CPU cost per frame (process + physics) for each level, independent of GPU.
##   godot --headless --audio-driver Dummy --path . --script test/perf.gd

func _initialize() -> void:
	_run.call_deferred()


func _run() -> void:
	var session := root.get_node("Session")
	for id in ["forest", "cave", "tower", "boss"]:
		session.start_level(id, false)
		for i in 400:
			await process_frame
		var p = current_scene.player
		p.bot = {"x": 1.0, "y": 0.0, "held": {"lantern": true}, "pressed": {}}
		var proc := 0.0
		var phys := 0.0
		var worst := 0.0
		for i in 240:
			await process_frame
			var a := Performance.get_monitor(Performance.TIME_PROCESS)
			var b := Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS)
			proc += a
			phys += b
			worst = maxf(worst, a + b)
		print("[%s] avg process %.2f ms  physics %.2f ms  worst %.2f ms  nodes %d" % [id, proc / 240.0 * 1000.0, phys / 240.0 * 1000.0, worst * 1000.0, Performance.get_monitor(Performance.OBJECT_NODE_COUNT)])
	quit()
