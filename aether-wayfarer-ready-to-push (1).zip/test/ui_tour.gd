extends SceneTree
## UI tour: captures every menu/overlay state to /tmp/ui for visual review.
##   godot --audio-driver Dummy --path . --script test/ui_tour.gd [-- WxH]

const OUT := "/tmp/ui"


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute(OUT)
	var args := OS.get_cmdline_user_args()
	if not args.is_empty():
		var wh: PackedStringArray = args[0].split("x")
		root.size = Vector2i(int(wh[0]), int(wh[1]))
	_run.call_deferred()


func _frames(n: int) -> void:
	for i in n:
		await process_frame


func _shot(name: String) -> void:
	await process_frame
	var img := root.get_viewport().get_texture().get_image()
	img.save_png("%s/%s.png" % [OUT, name])
	print("shot ", name)


func _run() -> void:
	var i18n := root.get_node("I18n")
	var session := root.get_node("Session")
	for loc in ["en", "zh-CN"]:
		i18n.set_locale(loc)
		change_scene_to_file("res://scenes/title_screen.tscn")
		await _frames(80)
		await _shot("title_" + loc)
		var title := current_scene
		title._open_chapters()
		await _frames(30)
		await _shot("chapters_" + loc)
		title._close_modal()
		await _frames(5)
		title._open_controls()
		await _frames(30)
		await _shot("controls_" + loc)
		title._close_modal()
		await _frames(5)
		title._open_settings()
		await _frames(30)
		await _shot("settings_" + loc)
	i18n.set_locale("en")
	# In-level: pause + settings from pause, touch overlay.
	session.start_level("cave", false)
	await _frames(240)
	var game := current_scene
	await _shot("cave_hint")
	session.touch_seen = true
	session.device = "touch"
	game._update_touch()
	await _frames(20)
	await _shot("touch_layer")
	game._toggle_pause()
	await _frames(20)
	await _shot("pause")
	game._open_settings()
	await _frames(20)
	await _shot("pause_settings")
	game._close_pause()
	session.touch_seen = false
	session.device = "keyboard"
	# Boss: defeat via direct hits to reach final results.
	session.start_level("boss", true)
	await _frames(300)
	game = current_scene
	await _shot("boss_intro")
	var boss = game.level.boss
	for k in 3:
		boss._take_hit(true)
		await _frames(150)
		await _shot("boss_after_hit%d" % k)
	await _frames(300)
	await _shot("final_results")
	print("UI TOUR DONE")
	quit()
