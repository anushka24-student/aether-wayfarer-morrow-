extends SceneTree
## Reachability check with the REAL player physics.
##   godot --headless --fixed-fps 60 --audio-driver Dummy --path . --script test/reach.gd -- [level ...]
## Spawns many scripted Player instances that explore each level with macro
## actions (walk, jump heights, jump+dash, wall-climb, plank drop), BFS over
## landing spots, and reports whether every ember, checkpoint, the beacon and
## (boss) every brazier can be reached from the spawn. Enemies are removed.

const SIMS := 40
const MAX_STATES := 2600
var level_ids: Array = ["forest", "cave", "tower", "boss"]
var actions: Array = []
var failures := 0


func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if not args.is_empty():
		level_ids = Array(args)
	_build_actions()
	_run.call_deferred()


func _build_actions() -> void:
	for d in [-1, 1]:
		actions.append({"kind": "walk", "dir": d, "steps": 8})
		actions.append({"kind": "walk", "dir": d, "steps": 26})
		actions.append({"kind": "gdash", "dir": d})
		for pol in ["zig", "hug"]:
			actions.append({"kind": "climb", "dir": d, "policy": pol})
		for at in [8, 18]:
			for dv in [Vector2(d, 0), Vector2(d, -1)]:
				actions.append({"kind": "jump", "dir": d, "hold": 40, "dash_at": at, "dash": dv})
		actions.append({"kind": "jump", "dir": d, "hold": 40, "dash_at": 14, "dash": Vector2(0, -1)})
		actions.append({"kind": "jump", "dir": d, "hold": 40, "dash_at": 22, "dash": Vector2(-d, -1), "air_dir": d})
	for d in [-1, 0, 1]:
		for h in [4, 10, 40]:
			actions.append({"kind": "jump", "dir": d, "hold": h})
		actions.append({"kind": "drop", "dir": d})
		actions.append({"kind": "jump", "dir": d, "hold": 40, "late_dir": -d if d != 0 else 1})


func _frames(n: int) -> void:
	for i in n:
		await physics_frame


func _run() -> void:
	var session := root.get_node("Session")
	for id: String in level_ids:
		session.start_level(id, false)
		await _frames(20)
		await _check_level(id, current_scene)
	print("REACH SUMMARY: ", "OK" if failures == 0 else "%d FAILURES" % failures)
	quit(1 if failures > 0 else 0)


func _check_level(id: String, game: Node) -> void:
	var lvl = game.level
	# Strip everything that is not geometry.
	for e in lvl.enemies:
		e.queue_free()
	lvl.enemies.clear()
	if lvl.boss:
		lvl.boss.queue_free()
		lvl.boss = null
	game.fx.queue_free()
	game.player.frozen = true
	game.player.set_physics_process(false)
	game.player.global_position = Vector2(-99999, -99999)
	game.player.light.enabled = false
	game.show_hints = false
	var targets: Array = []
	for i in lvl.embers.size():
		var em = lvl.embers[i]
		em.set_deferred("monitoring", false)
		targets.append({"name": "ember%d" % i, "pos": em.global_position, "r": 26.0, "hit": false})
	for i in lvl.checkpoints.size():
		var cp = lvl.checkpoints[i]
		cp.set_deferred("monitoring", false)
		targets.append({"name": "waylamp%d" % i, "pos": cp.global_position + Vector2(0, -20), "r": 40.0, "hit": false})
	if lvl.beacon:
		lvl.beacon.set_deferred("monitoring", false)
		targets.append({"name": "beacon", "pos": lvl.beacon.global_position + Vector2(0, -30), "r": 44.0, "hit": false})
	for i in lvl.braziers.size():
		var bz = lvl.braziers[i]
		bz.set_deferred("monitoring", false)
		targets.append({"name": "brazier%d" % i, "pos": bz.global_position + Vector2(0, -30), "r": 40.0, "hit": false})
	await _frames(2)
	var sims: Array = []
	for i in SIMS:
		var p: Node = (load("res://scripts/actors/player.gd") as GDScript).new()
		p.name = "Sim%d" % i
		p.position = Vector2(-99999, -99999)
		lvl.world.add_child(p)
		p.bot = {"x": 0.0, "y": 0.0, "held": {}, "pressed": {}}
		sims.append({"p": p, "job": null})
	await _frames(2)
	var visited := {}
	var jobs: Array = []
	var start: Vector2 = lvl.spawn
	visited[_key(start)] = start
	for a in actions:
		jobs.append({"from": start, "a": a})
	var bottom: float = lvl.size_px.y + 40.0
	var frames := 0
	var t0 := Time.get_ticks_msec()
	while (not jobs.is_empty() or _busy(sims)) and frames < 400000:
		Engine.time_scale = 1.0
		for s in sims:
			if s.job == null and not jobs.is_empty():
				s.job = jobs.pop_back()
				s.job["f"] = 0
				s.job["last_press"] = -100
				s.job["hug_side"] = 0
				s.job["still"] = 0
				_reset_sim(s.p, s.job.from)
			if s.job != null:
				_drive(s.p, s.job)
		await physics_frame
		frames += 1
		for s in sims:
			if s.job == null:
				continue
			var p = s.p
			var job: Dictionary = s.job
			job.f += 1
			for t in targets:
				if not t.hit and p.alive and p.global_position.distance_to(t.pos) < t.r + 14.0:
					t.hit = true
			var done := false
			if not p.alive or p.global_position.y > bottom:
				done = true
			elif job.f > 8 and p.is_on_floor() and absf(p.velocity.x) < 4.0 and p.dash_timer <= 0.0:
				job.still += 1
				if job.still >= 2:
					done = true
					if visited.size() < MAX_STATES:
						var k := _key(p.global_position)
						if not visited.has(k):
							visited[k] = p.global_position
							for a in actions:
								jobs.append({"from": p.global_position, "a": a})
			else:
				job.still = 0
			if job.f > 320:
				done = true
			if done:
				if OS.has_environment("REACH_DEBUG") and frames < 400:
					print(job.a, " f=", job.f, " from=", job.from, " to=", p.global_position.round(), " alive=", p.alive)
				s.job = null
				p.bot = {"x": 0.0, "y": 0.0, "held": {}, "pressed": {}}
				p.global_position = Vector2(-99999, -99999)
	var ms := Time.get_ticks_msec() - t0
	var missing: Array = []
	for t in targets:
		if not t.hit:
			missing.append(t.name)
	print("[%s] states=%d frames=%d time=%.1fs  missing=%s" % [id, visited.size(), frames, ms / 1000.0, str(missing)])
	if not missing.is_empty():
		failures += 1
		_dump_map(id, lvl, visited)
	for s in sims:
		s.p.queue_free()
	await _frames(2)


func _busy(sims: Array) -> bool:
	for s in sims:
		if s.job != null:
			return true
	return false


func _key(p: Vector2) -> Vector2i:
	return Vector2i(roundi(p.x / 16.0), roundi(p.y / 8.0))


func _reset_sim(p, at: Vector2) -> void:
	p.global_position = at
	p.velocity = Vector2.ZERO
	p.alive = true
	p.frozen = false
	p.invulnerable = 0.0
	p.oil = 1.0
	p.flare_locked = false
	p.dash_ready = true
	p.dash_timer = 0.0
	p.jump_buffer = 0.0
	p.dash_buffer = 0.0
	p.coyote = 0.1
	p.jumping = false
	p.wall_lock = 0.0
	p.light.enabled = true
	p.visual.visible = true
	p.reset_physics_interpolation()


func _drive(p, job: Dictionary) -> void:
	var a: Dictionary = job.a
	var f: int = job.f
	var b := {"x": 0.0, "y": 0.0, "held": {}, "pressed": {}}
	var dir := float(a.dir)
	match a.kind:
		"walk":
			b.x = dir if f < int(a.steps) else 0.0
		"gdash":
			if f == 1:
				b.pressed["dash"] = true
				b.x = dir
		"drop":
			b.y = 1.0
			b.x = dir if f > 4 else 0.0
			if f == 1:
				b.pressed["jump"] = true
				b.held["jump"] = true
		"jump":
			b.x = dir
			if a.has("late_dir") and f > 16:
				b.x = float(a.late_dir)
			if a.has("air_dir") and f > int(a.get("dash_at", 0)) + 9:
				b.x = float(a.air_dir)
			if f == 1:
				b.pressed["jump"] = true
			b.held["jump"] = f >= 1 and f <= int(a.hold)
			if a.has("dash_at") and f == int(a.dash_at):
				b.pressed["dash"] = true
				b.x = a.dash.x
				b.y = a.dash.y
			elif a.has("dash_at") and f > int(a.dash_at) and f < int(a.dash_at) + 9:
				b.x = a.dash.x
				b.y = a.dash.y
		"climb":
			b.x = dir
			b.held["jump"] = true
			if f == 1:
				b.pressed["jump"] = true
				job.last_press = f
			elif not p.is_on_floor() and p.wall_dir != 0 and f - int(job.last_press) > 8:
				b.pressed["jump"] = true
				job.last_press = f
				job.hug_side = p.wall_dir
			if job.hug_side != 0:
				if a.policy == "zig":
					b.x = -float(job.hug_side)
				else:
					b.x = -float(job.hug_side) if f - int(job.last_press) < 7 else float(job.hug_side)
	if not p.is_on_floor():
		job["airborne"] = true
	elif job.get("airborne", false) and a.kind != "walk" and f > 3:
		b.x = 0.0
	p.bot = b


func _dump_map(id: String, lvl, visited: Dictionary) -> void:
	var rows: Array = lvl.data.map.duplicate()
	for k in visited:
		var pos: Vector2 = visited[k]
		var c := int(pos.x / 32.0)
		var r := int((pos.y - 1.0) / 32.0)
		if r >= 0 and r < rows.size() and c >= 0 and c < rows[r].length():
			var line: String = rows[r]
			if line[c] == ".":
				rows[r] = line.substr(0, c) + "o" + line.substr(c + 1)
	var f := FileAccess.open("/tmp/reach_%s.txt" % id, FileAccess.WRITE)
	for line in rows:
		f.store_line(line)
	print("  map with reached spots -> /tmp/reach_%s.txt" % id)
