extends SceneTree
## Visual + runtime smoke pass. Run with a display:
##   godot --audio-driver Dummy --path . --script test/playtest.gd -- [level ...]
## Loads each level, visits spawn / checkpoints / embers / beacon, saves
## screenshots to /tmp/shots, and exercises the results screen.

const OUT := "/tmp/shots"
var _levels: Array = ["forest", "cave", "tower", "boss"]


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute(OUT)
	var args := OS.get_cmdline_user_args()
	if not args.is_empty():
		_levels = Array(args)
	_run.call_deferred()


func _frames(n: int) -> void:
	for i in n:
		await process_frame


func _shot(name: String) -> void:
	await process_frame
	var img := root.get_viewport().get_texture().get_image()
	img.save_png("%s/%s.png" % [OUT, name])
	print("shot ", name)


func _teleport(game: Node, pos: Vector2) -> void:
	var p = game.player
	p.global_position = pos
	p.velocity = Vector2.ZERO
	p.reset_physics_interpolation()
	game.camera.snap_to_target()


func _run() -> void:
	var session := root.get_node("Session")
	if "title" in _levels:
		change_scene_to_file("res://scenes/title_screen.tscn")
		await _frames(90)
		await _shot("title")
		_levels.erase("title")
	for id: String in _levels:
		session.start_level(id, false)
		await _frames(100)
		var game := current_scene
		var lvl = game.level
		await _shot(id + "_00_spawn")
		var i := 0
		for lamp in lvl.checkpoints:
			_teleport(game, lamp.global_position + Vector2(-40, -4))
			await _frames(45)
			await _shot("%s_cp%d" % [id, i])
			i += 1
		i = 0
		for ember in lvl.embers:
			_teleport(game, ember.global_position + Vector2(0, 30))
			await _frames(40)
			await _shot("%s_ember%d" % [id, i])
			i += 1
		if id == "boss":
			await _frames(200)
			await _shot("boss_fight_a")
			await _frames(120)
			await _shot("boss_fight_b")
			lvl.braziers[1].set_ready(true)
			_teleport(game, lvl.braziers[1].global_position + Vector2(0, -10))
			await _frames(60)
			await _shot("boss_stunned")
		elif lvl.beacon:
			_teleport(game, lvl.beacon.global_position + Vector2(-8, -4))
			await _frames(20)
			await _shot(id + "_beacon")
			await _frames(160)
			await _shot(id + "_results")
	print("PLAYTEST DONE")
	quit()
