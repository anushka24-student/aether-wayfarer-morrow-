extends SceneTree
## Checks Down+Jump drops through a one-way plank and plain Jump does not.
##   godot --headless --fixed-fps 60 --audio-driver Dummy --path . --script test/drop_check.gd

func _initialize() -> void:
	_run.call_deferred()


func _frames(n: int) -> void:
	for i in n:
		await physics_frame


func _find_plank(lvl) -> Vector2:
	var t = lvl.terrain
	for r in range(2, t.rows - 3):
		for c in range(1, t.cols - 1):
			if t.cell(c, r) == "=" and t.cell(c, r - 1) == "." and t.cell(c, r - 2) == "." and t.cell(c, r + 1) == "." and t.cell(c, r + 2) == ".":
				return Vector2(c * 32 + 16, r * 32)
	return Vector2.INF


func _run() -> void:
	root.get_node("Session").start_level("tower", false)
	await _frames(30)
	var game = current_scene
	var p = game.player
	var top: Vector2 = _find_plank(game.level)
	if top == Vector2.INF:
		print("DROP CHECK: no plank found")
		quit(1)
		return
	for mode in ["jump_only", "down_jump"]:
		p.respawn(top + Vector2(0, -2))
		p.bot = {"x": 0.0, "y": 0.0, "held": {}, "pressed": {}}
		await _frames(20)
		var y0: float = p.global_position.y
		var on0: bool = p.is_on_floor()
		p.bot = {"x": 0.0, "y": 1.0 if mode == "down_jump" else 0.0, "held": {}, "pressed": {"jump": true}}
		await _frames(1)
		p.bot = {"x": 0.0, "y": 1.0 if mode == "down_jump" else 0.0, "held": {}, "pressed": {}}
		await _frames(24)
		print("DROP CHECK %s: start_y %.1f on_floor %s -> y %.1f (delta %.1f)" % [mode, y0, on0, p.global_position.y, p.global_position.y - y0])
	quit()
