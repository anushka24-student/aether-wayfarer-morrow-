extends Control
## Title screen: animated key art, logo, main menu, chapter select, controls.

const BG := preload("res://assets/art/bg/title.jpg")
const HERO := preload("res://assets/art/hero/idle.png")

var _bg: TextureRect
var _menu_box: VBoxContainer
var _logo: Control
var _t := 0.0
var _modal: Control
var _order: Array = []
var _first_button: Button
var _footer: Label
var _account_badge: Button
var _account_modal: Control
var _settings_open := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = false
	Engine.time_scale = 1.0
	_order = Level.campaign_order()
	_bg = TextureRect.new()
	_bg.texture = BG
	_bg.modulate = Color(0.78, 0.9, 1.0, 1.0)
	_bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bg)
	var shade := TextureRect.new()
	shade.texture = _vignette()
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	add_child(_aether_overlay())
	add_child(_fireflies())
	_build()
	I18n.locale_changed.connect(func(_l: String) -> void: _rebuild())
	CloudProfile.session_changed.connect(func(_s: Dictionary) -> void: _refresh_account_badge())
	CloudProfile.sync_state_changed.connect(func(_s: String) -> void: _refresh_account_badge())
	_refresh_account_badge()
	GameAudio.set_track("title")
	GameAudio.begin_title()


func _vignette() -> Texture2D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	g.colors = PackedColorArray([Color(0.02, 0.01, 0.05, 0.0), Color(0.02, 0.01, 0.05, 0.25), Color(0.02, 0.01, 0.05, 0.85)])
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.42)
	t.fill_to = Vector2(1.1, 1.1)
	t.width = 256
	t.height = 144
	return t


func _aether_overlay() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.42, 1.0])
	gradient.colors = PackedColorArray([
		Color(0.20, 0.72, 1.0, 0.0),
		Color(0.34, 0.22, 0.84, 0.13),
		Color(0.06, 0.04, 0.24, 0.32),
	])
	var tex := GradientTexture2D.new()
	tex.gradient = gradient
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.52, 0.28)
	tex.fill_to = Vector2(1.1, 0.92)
	tex.width = 256
	tex.height = 144
	var aura := TextureRect.new()
	aura.texture = tex
	aura.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	aura.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	aura.set_anchors_preset(Control.PRESET_FULL_RECT)
	aura.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(aura)
	return root


func _fireflies() -> Node2D:
	var holder := Node2D.new()
	var p := CPUParticles2D.new()
	p.amount = 40
	p.lifetime = 8.0
	p.preprocess = 8.0
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(700, 380)
	p.position = Vector2(640, 380)
	p.direction = Vector2(0.2, -1)
	p.spread = 70
	p.gravity = Vector2(0, -3)
	p.initial_velocity_min = 5
	p.initial_velocity_max = 22
	p.texture = Fx.dot()
	p.scale_amount_min = 0.15
	p.scale_amount_max = 0.4
	var ramp := Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
	ramp.colors = PackedColorArray([Color(0.35, 0.9, 1.0, 0), Color(0.72, 0.62, 1.0, 0.9), Color(0.35, 0.9, 1.0, 0)])
	p.color_ramp = ramp
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	p.material = mat
	holder.add_child(p)
	return holder


func _rebuild() -> void:
	for n in [_logo, _menu_box, _footer, _account_badge, _account_modal]:
		if is_instance_valid(n):
			n.queue_free()
	_account_badge = null
	_account_modal = null
	_build()


func _build() -> void:
	var zh := I18n.get_locale().begins_with("zh")
	var logo := VBoxContainer.new()
	logo.set_anchors_preset(Control.PRESET_CENTER_TOP)
	logo.offset_left = -520
	logo.offset_right = 520
	logo.offset_top = 30
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logo.add_theme_constant_override("separation", -6)
	add_child(logo)
	var main := UiKit.title(I18n.t("title.name"), 88 if zh else 84, Color("#98f4ff"))
	logo.add_child(main)
	var second := UiKit.title(I18n.t("title.name_secondary"), 34, Color("#d7b9ff"))
	logo.add_child(second)
	var tag := UiKit.label(I18n.t("title.tagline"), 22, Color("#e8d7ba"))
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo.add_child(tag)
	_logo = logo
	_build_account_badge()
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.offset_left = -190
	box.offset_right = 190
	box.offset_top = -36
	box.offset_bottom = 300
	box.alignment = BoxContainer.ALIGNMENT_BEGIN
	box.add_theme_constant_override("separation", 7)
	add_child(box)
	_menu_box = box
	var buttons: Array = []
	if SaveStore.has_resume():
		var res := SaveStore.resume_state()
		var cont := UiKit.button(I18n.t("menu.continue", {"level": I18n.t(Level.load_level(str(res.level)).get("name_key", ""))}), 380, 24)
		cont.pressed.connect(func() -> void: Session.start_level(str(res.level), bool(res.get("campaign", false)), res))
		buttons.append(cont)
	var new_game := UiKit.button(I18n.t("menu.new_journey"), 380)
	new_game.pressed.connect(func() -> void:
		SaveStore.clear_resume()
		Session.start_level(_order[0], true))
	buttons.append(new_game)
	var chapters := UiKit.button(I18n.t("menu.chapters"), 380)
	chapters.pressed.connect(_open_chapters)
	buttons.append(chapters)
	var controls := UiKit.button(I18n.t("menu.controls"), 380)
	controls.pressed.connect(_open_controls)
	buttons.append(controls)
	var settings := UiKit.button(I18n.t("settings.title"), 380)
	settings.pressed.connect(_open_settings)
	buttons.append(settings)
	for b: Button in buttons:
		box.add_child(b)
	UiKit.wire_focus(buttons)
	_first_button = buttons[0]
	if _settings_open or _modal:
		box.visible = false
		logo.visible = false
	else:
		_first_button.call_deferred("grab_focus")
	var best := SaveStore.campaign_best()
	var footer_text := I18n.t("title.embers", {"n": SaveStore.total_embers()})
	if best > 0.0:
		footer_text = I18n.t("title.best_journey", {"time": Session.format_time(best)}) + "     " + footer_text
	_footer = UiKit.label(footer_text, 20, Color("#e8d7ba"))
	_footer.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_footer.offset_left = -500
	_footer.offset_right = 500
	_footer.offset_top = -44
	_footer.offset_bottom = -14
	_footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_footer)
	_footer.visible = logo.visible
	# entrance
	for i in buttons.size():
		var b: Button = buttons[i]
		b.modulate.a = 0.0
		var tw := b.create_tween()
		tw.tween_interval(0.15 + i * 0.07)
		tw.tween_property(b, "modulate:a", 1.0, 0.25)


func _process(delta: float) -> void:
	_t += delta
	# Slow drift on the key art (Ken Burns) and a breathing logo.
	var s := 1.06 + sin(_t * 0.12) * 0.03
	_bg.pivot_offset = size * 0.5
	_bg.scale = Vector2(s, s)
	_bg.position = Vector2(sin(_t * 0.09) * 18.0, cos(_t * 0.07) * 8.0)
	if is_instance_valid(_logo):
		_logo.position.y = 46 + sin(_t * 1.2) * 4.0


func _build_account_badge() -> void:
	var badge := UiKit.button("", 340, 20)
	badge.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	badge.offset_left = -364
	badge.offset_right = -24
	badge.offset_top = 24
	badge.offset_bottom = 66
	badge.pressed.connect(_account_action)
	add_child(badge)
	_account_badge = badge
	_refresh_account_badge()


func _refresh_account_badge() -> void:
	if not is_instance_valid(_account_badge):
		return
	if CloudProfile.is_authenticated():
		var name := CloudProfile.display_name()
		if name.is_empty():
			name = I18n.t("account.wayfarer")
		_account_badge.text = I18n.t("account.signed_in", {"name": name}) + "  ·  " + I18n.t("account.sync.%s" % CloudProfile.status)
	else:
		_account_badge.text = I18n.t("account.login")


func _account_action() -> void:
	if CloudProfile.is_authenticated():
		_open_account()
	else:
		# Keep this direct so the browser retains user activation for standalone OAuth.
		ManusAuth.login()


func _open_account() -> void:
	_set_menu_visible(false)
	var parts := UiKit.modal(self, 700)
	_account_modal = parts[0]
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("account.title"), 46, Color("#98f4ff")))
	var name := CloudProfile.display_name()
	box.add_child(UiKit.label(I18n.t("account.profile", {"name": name}), 24, UiKit.CREAM))
	box.add_child(UiKit.label(I18n.t("account.sync_status", {"status": I18n.t("account.sync.%s" % CloudProfile.status)}), 20, UiKit.DIM))
	box.add_child(UiKit.label(I18n.t("account.records", {"n": CloudProfile.records.size()}), 20, UiKit.DIM))
	box.add_child(UiKit.label(I18n.t("account.cross_device"), 20, UiKit.DIM))
	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 14)
	var logout := UiKit.button(I18n.t("account.logout"), 220, 22)
	logout.pressed.connect(func() -> void:
		ManusAuth.logout()
		_close_account())
	var back := UiKit.button(I18n.t("menu.back"), 220, 22)
	back.pressed.connect(_close_account)
	buttons.add_child(logout)
	buttons.add_child(back)
	box.add_child(buttons)
	UiKit.wire_focus([logout, back])
	logout.call_deferred("grab_focus")


func _close_account() -> void:
	if is_instance_valid(_account_modal):
		_account_modal.queue_free()
	_account_modal = null
	_set_menu_visible(true)
	_refresh_account_badge()


func _set_menu_visible(v: bool) -> void:
	_menu_box.visible = v
	if is_instance_valid(_logo):
		_logo.visible = v
	if is_instance_valid(_footer):
		_footer.visible = v


func _close_modal() -> void:
	if is_instance_valid(_modal):
		_modal.queue_free()
	_modal = null
	_set_menu_visible(true)
	_first_button.grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if _account_modal and (event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause")):
		get_viewport().set_input_as_handled()
		_close_account()
		return
	if _modal and (event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause")):
		get_viewport().set_input_as_handled()
		_close_modal()


func _open_settings() -> void:
	_set_menu_visible(false)
	_settings_open = true
	var menu := SettingsMenu.open(self)
	menu.closed.connect(func() -> void:
		_settings_open = false
		_set_menu_visible(true)
		if is_instance_valid(_first_button):
			_first_button.grab_focus())


func _open_chapters() -> void:
	_set_menu_visible(false)
	var parts := UiKit.modal(self, 760)
	_modal = parts[0]
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("menu.chapters"), 46))
	var buttons: Array = []
	for id: String in _order:
		var data := Level.load_level(id)
		var rec := SaveStore.level_record(id)
		var unlocked := SaveStore.is_unlocked(id, _order)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		var b := UiKit.button(I18n.t(data.name_key) if unlocked else I18n.t("chapter.locked"), 330, 24)
		b.disabled = not unlocked
		b.pressed.connect(func() -> void:
			SaveStore.clear_resume()
			Session.start_level(id, false))
		row.add_child(b)
		if unlocked:
			buttons.append(b)
		var info := VBoxContainer.new()
		info.add_theme_constant_override("separation", 0)
		var best := float(rec.get("best_time", 0.0))
		info.add_child(UiKit.label(I18n.t("chapter.best", {"time": Session.format_time(best) if best > 0.0 else "--:--"}), 20, UiKit.CREAM))
		if id != "boss":
			var got := SaveStore.count_bits(int(rec.get("embers", 0)))
			info.add_child(UiKit.label(I18n.t("chapter.embers", {"n": got}), 20, Color("#ffcf7a") if got == 3 else UiKit.DIM))
		else:
			info.add_child(UiKit.label(I18n.t("chapter.cleared") if rec.get("cleared", false) else "", 20, UiKit.DIM))
		row.add_child(info)
		box.add_child(row)
	var back := UiKit.button(I18n.t("menu.back"), 260, 22)
	back.set_meta("audio_cue", &"back")
	back.pressed.connect(_close_modal)
	var holder := CenterContainer.new()
	holder.add_child(back)
	box.add_child(holder)
	buttons.append(back)
	UiKit.wire_focus(buttons)
	buttons[0].call_deferred("grab_focus")


func _open_controls() -> void:
	_set_menu_visible(false)
	var parts := UiKit.modal(self, 820)
	_modal = parts[0]
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("menu.controls"), 46))
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 36)
	grid.add_theme_constant_override("v_separation", 6)
	box.add_child(grid)
	var rows := [
		["", "controls.keyboard", "controls.gamepad"],
		["controls.move", "A D / ← →", "L-Stick / D-Pad"],
		["controls.jump", "Space / Z / W", "A"],
		["controls.dash", "Shift / X / J", "X / B / RT"],
		["controls.lantern", "C / E / K", "Y / RB / LT"],
		["controls.drop", "S / ↓ + Jump", "↓ + A"],
		["controls.retry", "R", "LB"],
		["controls.pause", "Esc / P", "Start"],
	]
	for r in rows.size():
		for c in 3:
			var key: String = rows[r][c]
			var text := I18n.t(key) if key.contains(".") and not key.contains(" ") else key
			var l := UiKit.label(text, 22 if r > 0 else 22, UiKit.GOLD if r == 0 or c == 0 else UiKit.CREAM)
			grid.add_child(l)
	var tip := UiKit.label(I18n.t("controls.tip"), 20, UiKit.DIM)
	tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.custom_minimum_size = Vector2(700, 0)
	tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(tip)
	var back := UiKit.button(I18n.t("menu.back"), 260, 22)
	back.set_meta("audio_cue", &"back")
	back.pressed.connect(_close_modal)
	var holder := CenterContainer.new()
	holder.add_child(back)
	box.add_child(holder)
	back.call_deferred("grab_focus")
