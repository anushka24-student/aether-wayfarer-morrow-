extends Node2D
## Game controller for one level. Reads Session.level_id, builds the Level
## from data, owns the run timer, checkpoints, deaths, pause and results.

const GLYPHS := {
	"keyboard": {"move": "A / D", "jump": "Space", "dash": "Shift", "lantern": "C", "retry": "R", "down": "S"},
	"gamepad": {"move": "L-Stick", "jump": "A", "dash": "X", "lantern": "Y / RB", "retry": "LB", "down": "↓"},
}

var level: Level
var player: Player
var camera: GameCamera
var fx: Fx
var hud: Hud
var touch: TouchControls
var ui_layer: CanvasLayer
var level_id := "forest"
var level_data: Dictionary
var state := "play"          # play | dead | clear | done
var run_time := 0.0
var deaths := 0
var ember_bits := 0
var checkpoint: Waylamp
var show_hints := false
var _pause_root: Control
var _settings_open := false
var _respawn_t := 0.0
var _order: Array = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	Engine.time_scale = 1.0
	level_id = Session.level_id
	_order = Level.campaign_order()
	level_data = Level.load_level(level_id)
	if level_data.is_empty():
		level_id = "forest"
		level_data = Level.load_level(level_id)
	var resume: Dictionary = Session.resume
	Session.resume = {}
	if not resume.is_empty() and str(resume.get("level", "")) == level_id:
		run_time = float(resume.get("time", 0.0))
		deaths = int(resume.get("deaths", 0))
		ember_bits = int(resume.get("embers", 0))
	else:
		resume = {}
	level = Level.new()
	level.name = "Level"
	level.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(level)
	level.build(level_data, SaveStore.ember_mask(level_id))
	fx = Fx.new()
	fx.name = "Fx"
	level.world.add_child(fx)
	player = Player.new()
	player.name = "Player"
	player.position = level.spawn
	level.world.add_child(player)
	camera = GameCamera.new()
	camera.target = player
	camera.bounds = level.bounds()
	camera.base_zoom = float(level_data.get("camera_zoom", 1.0))
	level.world.add_child(camera)
	camera.make_current()
	fx.camera = camera
	hud = Hud.new()
	hud.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(hud)
	fx.flash_rect = hud.flash_rect
	hud.pause_pressed.connect(_toggle_pause)
	ui_layer = CanvasLayer.new()
	ui_layer.layer = 20
	ui_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(ui_layer)
	_wire_level(resume)
	_update_touch()
	Session.device_changed.connect(func(_d: String) -> void: _update_touch())
	show_hints = SaveStore.hints_setting() and SaveStore.level_record(level_id).is_empty()
	camera.snap_to_target()
	hud.set_embers(ember_bits)
	hud.set_time(run_time)
	hud.show_banner(I18n.t(level_data.name_key), I18n.t(level_data.subtitle_key))
	GameAudio.set_track(str(level_data.get("music", "explore")))
	GameAudio.begin_game()
	TuningStore.begin_run()
	if level.boss:
		get_tree().create_timer(1.0, false).timeout.connect(_start_boss)
	else:
		_save_resume()


func _wire_level(resume: Dictionary) -> void:
	player.died.connect(_on_player_died)
	level.terrain.hazard_touched.connect(func(b: Node) -> void:
		if b is Player:
			(b as Player).die())
	for lamp in level.checkpoints:
		lamp.activated.connect(_on_checkpoint)
	for ember in level.embers:
		if (ember_bits >> ember.index) & 1 == 1:
			ember.taken = true
			ember.visible = false
		ember.collected.connect(_on_ember)
	if level.beacon:
		level.beacon.reached.connect(_on_beacon)
	var cp := int(resume.get("checkpoint", -1))
	if cp >= 0 and cp < level.checkpoints.size():
		checkpoint = level.checkpoints[cp]
		checkpoint.set_lit(true, false)
		player.position = checkpoint.respawn_point()


func _start_boss() -> void:
	if not level.boss:
		return
	hud.show_boss(I18n.t("boss.name"), level.boss.hp, level.boss.max_hp)
	level.boss.hp_changed.connect(func(hp: int, mx: int) -> void: hud.set_boss_hp(hp, mx))
	level.boss.phase_started.connect(func(i: int) -> void:
		hud.show_hint(I18n.t("hint.boss_%d" % mini(i, 2), _glyphs()), 5.0))
	level.boss.defeated.connect(_on_boss_defeated)
	level.boss.begin()


func _glyphs() -> Dictionary:
	var out := {}
	if Session.device == "touch":
		for k in ["move", "jump", "dash", "lantern", "down"]:
			out[k] = I18n.t("glyph.touch_" + k)
		out["retry"] = ""
		return out
	var g: Dictionary = GLYPHS.get(Session.device, GLYPHS.keyboard)
	for k in g:
		out[k] = g[k]
	return out


func _update_touch() -> void:
	var want := Session.touch_seen
	if want and touch == null:
		touch = TouchControls.new()
		touch.process_mode = Node.PROCESS_MODE_PAUSABLE
		add_child(touch)
	if touch:
		touch.visible = want and (state == "play" or state == "dead")
	hud.set_touch_mode(want)


func _physics_process(delta: float) -> void:
	if get_tree().paused:
		return
	if state == "play" or state == "dead":
		run_time += delta
		hud.set_time(run_time)
	hud.set_oil(player.oil, player.flare_locked)
	if state == "play" and player.alive:
		if player.global_position.y > level.size_px.y + 60.0:
			player.invulnerable = 0.0
			player.die()
		if show_hints:
			for h: Dictionary in level.hints:
				if not h.shown and player.global_position.x >= h.x - 4.0 and absf(player.global_position.y - h.y) < 360.0:
					h.shown = true
					hud.show_hint(I18n.t(h.key, _glyphs()), 6.5)
	if state == "dead":
		_respawn_t -= delta
		if _respawn_t <= 0.0:
			_respawn()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		get_viewport().set_input_as_handled()
		if not _settings_open:
			_toggle_pause()
	elif event.is_action_pressed("retry") and state == "play" and not get_tree().paused:
		get_viewport().set_input_as_handled()
		if player.alive:
			player.invulnerable = 0.0
			player.die()


func _on_player_died() -> void:
	if state != "play":
		return
	deaths += 1
	state = "dead"
	_respawn_t = Tune.v("respawn_delay")


func _respawn() -> void:
	state = "play"
	var at := checkpoint.respawn_point() if checkpoint else level.spawn
	level.reset_enemies()
	if level.boss:
		level.boss.on_player_respawn()
	player.respawn(at)
	camera.snap_to_target()


func _on_checkpoint(lamp: Waylamp) -> void:
	checkpoint = lamp
	hud.show_toast(I18n.t("toast.checkpoint"), 0.8)
	_save_resume()


func _on_ember(ember: Ember) -> void:
	ember_bits |= 1 << ember.index
	hud.set_embers(ember_bits)
	hud.show_toast(I18n.t("toast.ember", {"n": SaveStore.count_bits(ember_bits)}), 0.7)
	_save_resume()


func _campaign_fields(d: Dictionary) -> Dictionary:
	d["campaign"] = Session.campaign
	d["campaign_time"] = Session.campaign_time
	d["campaign_deaths"] = Session.campaign_deaths
	d["campaign_embers"] = Session.campaign_embers
	return d


func _save_resume() -> void:
	if level.boss:
		return
	SaveStore.set_resume(_campaign_fields({
		"level": level_id,
		"checkpoint": checkpoint.order if checkpoint else -1,
		"time": run_time,
		"deaths": deaths,
		"embers": ember_bits,
	}))


func _on_beacon() -> void:
	if state != "play":
		return
	state = "clear"
	player.frozen = true
	if touch:
		touch.release_all()
		touch.visible = false
	hud.show_toast(I18n.t("toast.beacon"), 1.4)
	var result := SaveStore.record_clear(level_id, run_time, ember_bits, deaths)
	CloudProfile.append_record("level_clear", level_id, "victory", roundi(run_time * 1000.0), deaths, SaveStore.count_bits(ember_bits), {"campaign": Session.campaign})
	if level_id == "forest":
		SaveStore.mark_tutorial_done()
	if Session.campaign:
		Session.campaign_time += run_time
		Session.campaign_deaths += deaths
		Session.campaign_embers += SaveStore.count_bits(ember_bits)
	var next := _next_level()
	if next != "":
		SaveStore.set_resume(_campaign_fields({"level": next, "checkpoint": -1, "time": 0.0, "deaths": 0, "embers": 0}))
	else:
		SaveStore.clear_resume()
	TuningStore.end_run()
	GameAudio.play(&"clear")
	await get_tree().create_timer(1.8, false).timeout
	_show_level_results(result, next)


func _on_boss_defeated() -> void:
	if state == "done":
		return
	state = "done"
	player.frozen = true
	if touch:
		touch.release_all()
		touch.visible = false
	for e in level.actors.get_children():
		if e is Enemy and e.alive:
			e.defeat(true)
	var tw := create_tween()
	tw.tween_method(func(v: float) -> void: level.light_field.darkness = v, level.light_field.darkness, 0.12, 2.5)
	var result := SaveStore.record_clear(level_id, run_time, 0, deaths)
	CloudProfile.append_record("boss_defeat", level_id, "victory", roundi(run_time * 1000.0), deaths, 0, {"campaign": Session.campaign})
	var campaign_new_best := false
	if Session.campaign:
		Session.campaign_time += run_time
		Session.campaign_deaths += deaths
		campaign_new_best = SaveStore.record_campaign(Session.campaign_time)
		CloudProfile.append_record("campaign_complete", level_id, "victory", roundi(Session.campaign_time * 1000.0), Session.campaign_deaths, Session.campaign_embers, {"new_best": campaign_new_best})
	SaveStore.clear_resume()
	TuningStore.end_run()
	GameAudio.play(&"beacon")
	GameAudio.play(&"clear")
	hud.show_toast(I18n.t("toast.boss_down"), 2.0)
	await get_tree().create_timer(3.0, false).timeout
	_show_final_results(result, campaign_new_best)


func _next_level() -> String:
	var i := _order.find(level_id)
	return _order[i + 1] if i >= 0 and i + 1 < _order.size() else ""


func _stat_row(box: VBoxContainer, icon: Texture2D, name_text: String, value: String, badge := "") -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row.add_child(UiKit.icon(icon, 40))
	var n := UiKit.label(name_text, 26, UiKit.DIM)
	n.custom_minimum_size = Vector2(190, 0)
	row.add_child(n)
	var v := UiKit.label(value, 30, UiKit.CREAM)
	v.custom_minimum_size = Vector2(170, 0)
	row.add_child(v)
	if badge != "":
		var b := UiKit.label(badge, 22, Color("#ffd36e"))
		row.add_child(b)
		b.pivot_offset = Vector2(30, 14)
		var tw := b.create_tween().set_loops()
		tw.tween_property(b, "scale", Vector2(1.12, 1.12), 0.4)
		tw.tween_property(b, "scale", Vector2.ONE, 0.4)
	box.add_child(row)


func _add_buttons(box: VBoxContainer, buttons: Array) -> void:
	for b in buttons:
		var holder := CenterContainer.new()
		holder.add_child(b)
		box.add_child(holder)
	UiKit.wire_focus(buttons)
	buttons[0].call_deferred("grab_focus")


func _show_level_results(result: Dictionary, next: String) -> void:
	get_tree().paused = true
	var parts := UiKit.modal(ui_layer, 640)
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("results.title"), 50))
	var sub := UiKit.label(I18n.t(level_data.name_key), 24, UiKit.DIM)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)
	var stats := VBoxContainer.new()
	stats.add_theme_constant_override("separation", 6)
	box.add_child(stats)
	var got := SaveStore.count_bits(ember_bits)
	_stat_row(stats, preload("res://assets/art/ui/icon_watch.png"), I18n.t("results.time"), Session.format_time(run_time),
		I18n.t("results.new_best") if result.new_best else "")
	_stat_row(stats, preload("res://assets/art/ui/icon_beacon.png"), I18n.t("results.best"), Session.format_time(result.best))
	_stat_row(stats, preload("res://assets/art/props/ember.png"), I18n.t("results.embers"), "%d / 3   %d%%" % [got, roundi(got / 3.0 * 100.0)])
	_stat_row(stats, preload("res://assets/art/ui/icon_candle.png"), I18n.t("results.deaths"), str(deaths))
	var buttons: Array = []
	if next != "":
		var nb := UiKit.button(I18n.t("results.next_boss") if next == "boss" else I18n.t("results.next"), 380)
		nb.pressed.connect(func() -> void: Session.start_level(next, Session.campaign, SaveStore.resume_state()))
		buttons.append(nb)
	var rb := UiKit.button(I18n.t("results.retry"), 380)
	rb.pressed.connect(func() -> void: Session.start_level(level_id, false))
	buttons.append(rb)
	var tb := UiKit.button(I18n.t("menu.title"), 380)
	tb.set_meta("audio_cue", &"back")
	tb.pressed.connect(Session.to_title)
	buttons.append(tb)
	_add_buttons(box, buttons)


func _show_final_results(result: Dictionary, campaign_new_best: bool) -> void:
	get_tree().paused = true
	var parts := UiKit.modal(ui_layer, 720)
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("final.title"), 54))
	var story := UiKit.label(I18n.t("final.story"), 22, UiKit.DIM)
	story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	story.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	story.custom_minimum_size = Vector2(600, 0)
	box.add_child(story)
	var stats := VBoxContainer.new()
	stats.add_theme_constant_override("separation", 6)
	box.add_child(stats)
	_stat_row(stats, preload("res://assets/art/ui/icon_watch.png"), I18n.t("results.boss_time"), Session.format_time(run_time),
		I18n.t("results.new_best") if result.new_best else "")
	if Session.campaign:
		_stat_row(stats, preload("res://assets/art/ui/icon_beacon.png"), I18n.t("results.journey_time"), Session.format_time(Session.campaign_time),
			I18n.t("results.new_best") if campaign_new_best else "")
		_stat_row(stats, preload("res://assets/art/ui/icon_candle.png"), I18n.t("results.deaths"), str(Session.campaign_deaths))
	var total := SaveStore.total_embers()
	_stat_row(stats, preload("res://assets/art/props/ember.png"), I18n.t("results.all_embers"), "%d / 9   %d%%" % [total, roundi(total / 9.0 * 100.0)])
	var tb := UiKit.button(I18n.t("menu.title"), 380)
	tb.pressed.connect(Session.to_title)
	var rb := UiKit.button(I18n.t("results.retry"), 380)
	rb.pressed.connect(func() -> void: Session.start_level(level_id, false))
	_add_buttons(box, [tb, rb])


func _toggle_pause() -> void:
	if state == "clear" or state == "done" or _settings_open:
		return
	if _pause_root and is_instance_valid(_pause_root):
		_close_pause()
		return
	get_tree().paused = true
	GameAudio.play(&"ui_pause")
	if touch:
		touch.release_all()
	var parts := UiKit.modal(ui_layer, 540)
	_pause_root = parts[0]
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("pause.title"), 50))
	var info := UiKit.label("%s   ·   %s   ·   %d/3" % [I18n.t(level_data.name_key), Session.format_time(run_time), SaveStore.count_bits(ember_bits)], 22, UiKit.DIM)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(info)
	var defs := [
		["pause.resume", _close_pause],
		["pause.checkpoint", func() -> void:
			_close_pause()
			if player.alive and state == "play":
				player.invulnerable = 0.0
				player.die()],
		["pause.restart", func() -> void: Session.start_level(level_id, Session.campaign and level_id == _order[0])],
		["settings.title", _open_settings],
		["menu.title", Session.to_title],
	]
	var buttons: Array = []
	for d: Array in defs:
		var b := UiKit.button(I18n.t(d[0]), 360)
		b.pressed.connect(d[1])
		buttons.append(b)
	buttons[0].name = "PauseFirst"
	buttons[-1].set_meta("audio_cue", &"back")
	_add_buttons(box, buttons)


func _open_settings() -> void:
	_settings_open = true
	_pause_root.visible = false
	var menu := SettingsMenu.open(ui_layer)
	menu.closed.connect(func() -> void:
		_settings_open = false
		if is_instance_valid(_pause_root):
			_pause_root.visible = true
			var first := _pause_root.find_child("PauseFirst", true, false) as Control
			if first:
				first.grab_focus())


func _close_pause() -> void:
	if _pause_root and is_instance_valid(_pause_root):
		_pause_root.queue_free()
	_pause_root = null
	get_tree().paused = false


func _exit_tree() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false
