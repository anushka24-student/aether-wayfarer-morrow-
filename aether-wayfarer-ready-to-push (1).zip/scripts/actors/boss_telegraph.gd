class_name BossTelegraph
extends Node2D
## Draws attack warnings above the murk so they always read clearly.

var floor_y := 608.0
var top_y := 32.0
var column_xs: Array = []
var column_time := 0.0
var column_total := 1.0
var lane_dir := 0
var lane_x := 0.0
var lane_time := 0.0
var lane_total := 1.0
var target_x := -1.0
var target_time := 1.0
var _t := 0.0


func _ready() -> void:
	z_index = 20


func columns(xs: Array, duration: float) -> void:
	column_xs = xs
	column_total = maxf(duration, 0.05)
	column_time = column_total


func lane(dir: int, x: float, _y: float, duration: float) -> void:
	lane_dir = dir
	lane_x = x
	lane_total = maxf(duration, 0.05)
	lane_time = lane_total


func clear() -> void:
	column_time = 0.0
	lane_time = 0.0
	target_x = -1.0


func _process(delta: float) -> void:
	_t += delta
	column_time = maxf(0.0, column_time - delta)
	lane_time = maxf(0.0, lane_time - delta)
	queue_redraw()


func _draw() -> void:
	var pulse := 0.5 + 0.5 * sin(_t * 18.0)
	if column_time > 0.0:
		var k := 1.0 - column_time / column_total
		for x: float in column_xs:
			var w := lerpf(46.0, 30.0, k)
			draw_rect(Rect2(x - w * 0.5, top_y, w, floor_y - top_y), Color(0.55, 0.2, 0.75, 0.10 + 0.12 * k))
			draw_line(Vector2(x - w * 0.5, top_y), Vector2(x - w * 0.5, floor_y), Color(0.9, 0.55, 1.0, 0.35 + 0.3 * pulse), 2.0)
			draw_line(Vector2(x + w * 0.5, top_y), Vector2(x + w * 0.5, floor_y), Color(0.9, 0.55, 1.0, 0.35 + 0.3 * pulse), 2.0)
			draw_circle(Vector2(x, floor_y - 3), lerpf(8.0, 22.0, k), Color(0.9, 0.5, 1.0, 0.35 + 0.25 * pulse))
			_chevron(Vector2(x, top_y + 30 + fmod(_t * 120.0, 60.0)), Color(1.0, 0.75, 1.0, 0.8))
	if lane_time > 0.0:
		var k2 := 1.0 - lane_time / lane_total
		var end_x := lane_x + lane_dir * 1200.0
		draw_rect(Rect2(minf(lane_x, end_x), floor_y - 40, absf(end_x - lane_x), 40), Color(0.55, 0.2, 0.75, 0.10 + 0.15 * k2))
		for i in 6:
			var px := lane_x + lane_dir * (60.0 + i * 150.0 + fmod(_t * 200.0, 150.0))
			_arrow(Vector2(px, floor_y - 20), lane_dir, Color(1.0, 0.7, 1.0, 0.75 * pulse + 0.2))
	if target_x >= 0.0:
		var r := 60.0 + 10.0 * pulse
		draw_set_transform(Vector2(target_x, floor_y - 2), 0.0, Vector2(1.0, 0.28))
		draw_circle(Vector2.ZERO, r, Color(0.5, 0.15, 0.7, 0.35))
		draw_arc(Vector2.ZERO, r, 0, TAU, 40, Color(1.0, 0.6, 1.0, 0.8), 3.0)
		draw_set_transform(Vector2.ZERO)


func _chevron(p: Vector2, c: Color) -> void:
	draw_polyline(PackedVector2Array([p + Vector2(-10, -8), p, p + Vector2(10, -8)]), c, 3.0)


func _arrow(p: Vector2, dir: int, c: Color) -> void:
	var d := float(dir)
	draw_polyline(PackedVector2Array([p + Vector2(-10 * d, -10), p + Vector2(4 * d, 0), p + Vector2(-10 * d, 10)]), c, 4.0)
