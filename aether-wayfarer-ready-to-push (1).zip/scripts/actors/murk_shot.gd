class_name MurkShot
extends Node2D
## Boss hazards. kind "drop": falls from the ceiling (the flare pops it).
## kind "wave": a murk crest rolling along the floor (jump it).

var kind := "drop"
var velocity := Vector2.ZERO
var floor_y := 608.0
var min_x := 64.0
var max_x := 1216.0
var radius := 13.0
var player: Player
var _t := 0.0
var _trail := 0.0
var _dead := false


func _ready() -> void:
	z_index = 8
	player = get_tree().get_first_node_in_group("player") as Player


func _physics_process(delta: float) -> void:
	if _dead:
		return
	_t += delta
	position += velocity * delta
	var fx := Fx.find(self)
	_trail -= delta
	if _trail <= 0.0 and fx:
		_trail = 0.05
		if kind == "drop":
			fx.burst(position + Vector2(0, -8), Color(0.45, 0.25, 0.6, 0.7), 2, 30.0, 0.35, -20.0, 0.9, false, 40.0)
		else:
			fx.burst(position + Vector2(0, -10), Color(0.5, 0.3, 0.7, 0.8), 3, 90.0, 0.4, -120.0, 1.0, false, 50.0, Vector2(-signf(velocity.x), -1))
	if kind == "drop":
		velocity.y = minf(velocity.y + 900.0 * delta, 760.0)
		if position.y >= floor_y - 6.0:
			pop(true)
			return
		if player and player.flare_reach() > 0.0 and position.distance_to(player.lantern_world_pos()) < player.flare_reach() * 0.9:
			pop(false)
			GameAudio.play(&"dispel")
			return
	else:
		if position.x < min_x - 10.0 or position.x > max_x + 10.0:
			pop(false)
			return
	if player and player.alive:
		var pr := player.hurt_rect()
		var hit := false
		if kind == "drop":
			var closest := Vector2(clampf(position.x, pr.position.x, pr.end.x), clampf(position.y, pr.position.y, pr.end.y))
			hit = closest.distance_to(position) < radius
		else:
			hit = pr.intersects(Rect2(position + Vector2(-16, -34), Vector2(32, 34)))
		if hit:
			player.die()
	queue_redraw()


func pop(splash: bool) -> void:
	_dead = true
	var fx := Fx.find(self)
	if fx:
		fx.burst(position, Color(0.5, 0.3, 0.7, 0.9), 12 if splash else 8, 150.0, 0.5, 200.0, 1.0, false, 70.0 if splash else 180.0)
		if not splash:
			fx.burst(position, Color(1.0, 0.8, 0.5, 0.9), 8, 120.0, 0.35)
	queue_free()


func _draw() -> void:
	if kind == "drop":
		var wob := sin(_t * 20.0) * 1.5
		draw_circle(Vector2(0, -4), radius + 5.0, Color(0.22, 0.1, 0.32, 0.45))
		draw_circle(Vector2.ZERO, radius + wob * 0.3, Color(0.16, 0.07, 0.24, 1.0))
		draw_circle(Vector2(-3, -4), radius * 0.45, Color(0.62, 0.42, 0.85, 0.9))
		draw_circle(Vector2(0, 0), radius + 1.5, Color(0.8, 0.55, 1.0, 0.5), false, 2.0)
	else:
		var d := signf(velocity.x)
		var pts := PackedVector2Array()
		for i in 9:
			var f := float(i) / 8.0
			var x := lerpf(-20.0, 20.0, f) * d
			var h := sin(f * PI) * (30.0 + sin(_t * 18.0 + f * 6.0) * 4.0)
			pts.append(Vector2(x, -h))
		pts.append(Vector2(20 * d, 0))
		pts.append(Vector2(-20 * d, 0))
		draw_colored_polygon(pts, Color(0.18, 0.08, 0.26, 0.95))
		draw_polyline(pts.slice(0, 9), Color(0.85, 0.6, 1.0, 0.8), 2.5)
