class_name Player
extends CharacterBody2D
## The lantern traveller. All feel parameters come from config/tuning.json via Tune.v().
## Origin is at the feet. States: normal, dashing, dead, frozen (cutscenes).

signal died
signal dashed
signal jumped
signal flare_started

const ART_SCALE := 0.44
const FEET_PX := 124.0
const CELL := Vector2(150, 128)
const BODY := Vector2(18, 36)

var facing := 1
var alive := true
var frozen := false
var invulnerable := 0.0
var dash_ready := true
var dash_timer := 0.0
var dash_dir := Vector2.RIGHT
var dash_buffer := 0.0
var coyote := 0.0
var jump_buffer := 0.0
var drop_timer := 0.0   # >0 while falling through one-way planks
var jumping := false
var wall_dir := 0
var last_wall := 0
var wall_coyote := 0.0
var wall_lock := 0.0
var wall_lock_dir := 0
var oil := 1.0
var flaring := false
var flare_locked := false
var regen_wait := 0.0
var land_timer := 0.0
var fall_peak := 0.0
var was_on_floor := true
var input_x := 0.0
var input_y := 0.0
## Scripted input for automated tests (test/reach.gd). Empty = real devices.
## Keys: x, y (axes), held {action: bool}, pressed {action: bool}.
var bot: Dictionary = {}
var _afterimage_t := 0.0
var _dust_t := 0.0
var _lantern_angle := 0.0
var _lantern_vel := 0.0
var _prev_vx := 0.0
var _t := 0.0

var visual: Node2D
var sprite: AnimatedSprite2D
var lantern_pivot: Node2D
var lantern_sprite: Sprite2D
var light: LightSource
var fx: Fx


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1 | 16
	floor_snap_length = 6.0
	floor_max_angle = deg_to_rad(50)
	safe_margin = 0.06
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = BODY
	shape.shape = box
	shape.position = Vector2(0, -BODY.y * 0.5)
	add_child(shape)
	visual = Node2D.new()
	visual.name = "Visual"
	add_child(visual)
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = _build_frames()
	sprite.scale = Vector2(ART_SCALE, ART_SCALE)
	sprite.offset = Vector2(0, CELL.y * 0.5 - FEET_PX)
	sprite.play("idle")
	visual.add_child(sprite)
	lantern_pivot = Node2D.new()
	lantern_pivot.name = "LanternPivot"
	visual.add_child(lantern_pivot)
	lantern_sprite = Sprite2D.new()
	lantern_sprite.texture = preload("res://assets/art/hero/lantern.png")
	lantern_sprite.scale = Vector2(0.58, 0.58)
	lantern_sprite.modulate = Color("#b9f7ff")
	lantern_sprite.offset = Vector2(0, 21)
	lantern_pivot.add_child(lantern_sprite)
	light = LightSource.new()
	light.name = "Lantern"
	light.radius = Tune.v("lantern_radius")
	light.halo_color = Color(0.42, 0.9, 1.0, 0.34)
	light.position = Vector2(0, 16)
	lantern_pivot.add_child(light)


func _build_frames() -> SpriteFrames:
	var f := SpriteFrames.new()
	f.remove_animation(&"default")
	var sheets := {"idle": ["res://assets/art/hero/idle.png", 4, 7.0, true],
		"run": ["res://assets/art/hero/run.png", 6, 12.0, true]}
	for anim: String in sheets:
		var info: Array = sheets[anim]
		var tex: Texture2D = load(info[0])
		f.add_animation(anim)
		f.set_animation_speed(anim, info[2])
		f.set_animation_loop(anim, info[3])
		for i in int(info[1]):
			var atlas := AtlasTexture.new()
			atlas.atlas = tex
			atlas.region = Rect2(i * CELL.x, 0, CELL.x, CELL.y)
			f.add_frame(anim, atlas)
	for single in ["jump", "fall", "wall", "dash", "land", "hurt"]:
		f.add_animation(single)
		f.set_animation_loop(single, false)
		f.add_frame(single, load("res://assets/art/hero/%s.png" % single))
	return f


func hurt_rect() -> Rect2:
	return Rect2(global_position + Vector2(-7, -32), Vector2(14, 29))


## Radius inside which enemies are burned by the flare (0 when not flaring).
func flare_reach() -> float:
	return light.current_radius() * 0.85 if flaring and alive else 0.0


func lantern_world_pos() -> Vector2:
	return light.global_position


func _physics_process(delta: float) -> void:
	_t += delta
	if fx == null:
		fx = Fx.find(self)
	invulnerable = maxf(0.0, invulnerable - delta)
	if not alive:
		return
	_read_input()
	var on_floor := is_on_floor()
	_update_timers(delta, on_floor)
	_update_lantern(delta)
	if dash_timer > 0.0:
		_process_dash(delta)
	else:
		_process_move(delta, on_floor)
	var pre_vy := velocity.y
	move_and_slide()
	_post_move(pre_vy)
	_animate(delta)


func _read_input() -> void:
	if frozen:
		input_x = 0.0
		input_y = 0.0
		return
	if not bot.is_empty():
		input_x = float(bot.get("x", 0.0))
		input_y = float(bot.get("y", 0.0))
		return
	input_x = Input.get_axis("move_left", "move_right")
	input_y = Input.get_axis("move_up", "move_down")
	if absf(input_x) < 0.25:
		input_x = 0.0
	if absf(input_y) < 0.35:
		input_y = 0.0


func _pressed(action: String) -> bool:
	if not bot.is_empty():
		return bool(bot.pressed.get(action, false))
	return not frozen and Input.is_action_just_pressed(action)


func _held(action: String) -> bool:
	if not bot.is_empty():
		return bool(bot.held.get(action, false))
	return not frozen and Input.is_action_pressed(action)


func _update_timers(delta: float, on_floor: bool) -> void:
	if on_floor:
		coyote = Tune.v("coyote_time")
		if dash_timer <= 0.0:
			dash_ready = true
	else:
		coyote -= delta
	if _pressed("jump"):
		jump_buffer = Tune.v("jump_buffer")
	else:
		jump_buffer -= delta
	if _pressed("dash"):
		dash_buffer = 0.08
	else:
		dash_buffer -= delta
	wall_lock -= delta
	land_timer -= delta
	if drop_timer > 0.0:
		drop_timer -= delta
		if drop_timer <= 0.0:
			set_collision_mask_value(5, true)
	wall_dir = 0
	if not on_floor:
		if test_move(global_transform, Vector2(3, 0)):
			wall_dir = 1
		elif test_move(global_transform, Vector2(-3, 0)):
			wall_dir = -1
	if wall_dir != 0:
		wall_coyote = Tune.v("wall_coyote")
		last_wall = wall_dir
	else:
		wall_coyote -= delta


func _process_move(delta: float, on_floor: bool) -> void:
	var x := input_x
	var run := Tune.v("run_speed")
	var accel: float
	if wall_lock > 0.0 and signf(x) == float(wall_lock_dir):
		x = 0.0
		accel = 0.0
	elif on_floor:
		if x != 0.0 and signf(x) != signf(velocity.x) and absf(velocity.x) > 10.0:
			accel = Tune.v("ground_decel") * 1.2
		elif x != 0.0:
			accel = Tune.v("ground_accel")
		else:
			accel = Tune.v("ground_decel")
	else:
		accel = Tune.v("air_accel") * (1.0 if x != 0.0 else 0.55)
	var target := x * run
	if absf(velocity.x) > run and signf(velocity.x) == signf(target) and not on_floor:
		accel *= 0.35   # keep dash / wall-jump momentum a little longer in the air
	velocity.x = move_toward(velocity.x, target, accel * delta)
	if x != 0.0 and wall_lock <= 0.0:
		facing = int(signf(x))
	# Down + Jump on a one-way plank drops through it.
	if jump_buffer > 0.0 and on_floor and input_y > 0.5 and _on_one_way():
		_drop_through()
		on_floor = false
	# Jumping: ground/coyote first, then wall jump.
	if jump_buffer > 0.0:
		if on_floor or coyote > 0.0:
			_jump()
		elif wall_coyote > 0.0:
			_wall_jump(last_wall)
	# Variable height: releasing jump early cuts the rise.
	if jumping and velocity.y < 0.0 and not _held("jump"):
		velocity.y *= Tune.v("jump_cut")
		jumping = false
	if velocity.y >= 0.0:
		jumping = false
	# Gravity with fall multiplier and apex hang.
	if not on_floor:
		var g := Tune.v("gravity")
		if velocity.y > 0.0:
			g *= Tune.v("fall_gravity_mult")
		elif jumping and absf(velocity.y) < Tune.v("apex_threshold"):
			g *= Tune.v("apex_gravity_mult")
		velocity.y += g * delta
		var max_fall := Tune.v("fast_fall_speed") if input_y > 0.5 else Tune.v("max_fall_speed")
		if wall_dir != 0 and velocity.y > 0.0 and signf(input_x) == float(wall_dir):
			max_fall = Tune.v("wall_slide_speed")
			_dust_t -= delta
			if _dust_t <= 0.0 and fx:
				_dust_t = 0.09
				fx.dust(global_position + Vector2(wall_dir * 9, -20), 0.4, Vector2(-wall_dir, -0.3))
		velocity.y = minf(velocity.y, max_fall)
	if dash_buffer > 0.0 and dash_ready:
		_start_dash()


func _on_one_way() -> bool:
	# Standing on a plank/spirit stone only (no solid ground under the feet).
	var saved := collision_mask
	collision_mask = 1
	var hits_solid := test_move(global_transform, Vector2(0, 4))
	collision_mask = saved
	return not hits_solid


func _drop_through() -> void:
	set_collision_mask_value(5, false)
	drop_timer = 0.22
	jump_buffer = 0.0
	coyote = 0.0
	global_position.y += 2.0
	velocity.y = maxf(velocity.y, 60.0)


func _jump() -> void:
	velocity.y = -Tune.v("jump_speed")
	coyote = 0.0
	jump_buffer = 0.0
	jumping = true
	visual.scale = Vector2(0.78, 1.22)
	if fx:
		fx.dust(global_position, 0.8)
	GameAudio.play(&"jump")
	jumped.emit()


func _wall_jump(side: int) -> void:
	velocity.x = -side * Tune.v("wall_jump_x")
	velocity.y = -Tune.v("wall_jump_y")
	wall_lock = Tune.v("wall_jump_lock")
	wall_lock_dir = side
	wall_coyote = 0.0
	jump_buffer = 0.0
	jumping = true
	facing = -side
	visual.scale = Vector2(0.8, 1.2)
	if fx:
		fx.dust(global_position + Vector2(side * 10, -16), 0.9, Vector2(-side, -0.5))
	GameAudio.play(&"walljump")
	jumped.emit()


func _start_dash() -> void:
	var dir := Vector2(input_x, input_y)
	dir = Vector2(signf(dir.x) if absf(dir.x) > 0.3 else 0.0, signf(dir.y) if absf(dir.y) > 0.3 else 0.0)
	if dir == Vector2.ZERO:
		dir = Vector2(facing, 0)
	if is_on_floor() and dir.y > 0.0:
		dir.y = 0.0
		if dir.x == 0.0:
			dir.x = facing
	dash_dir = dir.normalized()
	dash_timer = Tune.v("dash_time")
	dash_ready = false
	dash_buffer = 0.0
	jump_buffer = 0.0
	jumping = false
	if dash_dir.x != 0.0:
		facing = int(signf(dash_dir.x))
	visual.scale = Vector2(1.25, 0.8)
	if fx:
		fx.burst(global_position + Vector2(0, -18), Color(1.0, 0.7, 0.35, 0.9), 12, 160.0, 0.35, 0.0, 1.0, true, 60.0, -dash_dir)
		fx.shake(3.0, 0.1)
	GameAudio.play(&"dash")
	dashed.emit()


func _process_dash(delta: float) -> void:
	dash_timer -= delta
	velocity = dash_dir * Tune.v("dash_speed")
	_afterimage_t -= delta
	if _afterimage_t <= 0.0 and fx:
		_afterimage_t = 0.03
		fx.afterimage(sprite)
	if dash_timer <= 0.0:
		velocity *= Tune.v("dash_carry")
		if velocity.y < 0.0:
			velocity.y *= 0.7
		if is_on_floor():
			dash_ready = true
	# A buffered jump during a ground dash becomes a long jump.
	if jump_buffer > 0.0 and is_on_floor() and dash_dir.y == 0.0:
		dash_timer = 0.0
		velocity.x = dash_dir.x * Tune.v("dash_speed") * 0.8
		_jump()


func _post_move(pre_vy: float) -> void:
	var on_floor := is_on_floor()
	if not on_floor:
		fall_peak = maxf(fall_peak, velocity.y)
	if on_floor and not was_on_floor:
		var impact := maxf(fall_peak, pre_vy)
		if impact > 180.0:
			land_timer = 0.09
			var k := clampf(impact / 700.0, 0.2, 1.0)
			visual.scale = Vector2(1.0 + 0.3 * k, 1.0 - 0.28 * k)
			if fx:
				fx.dust(global_position, 0.6 + k)
			GameAudio.play(&"land")
		fall_peak = 0.0
		wall_lock = 0.0
	if is_on_ceiling() and velocity.y < 0.0:
		velocity.y = 0.0
		jumping = false
	was_on_floor = on_floor


func _update_lantern(delta: float) -> void:
	var want := _held("lantern") and not flare_locked and oil > 0.0
	if want and not flaring:
		GameAudio.play(&"flare")
		flare_started.emit()
		if fx:
			fx.burst(light.global_position, Color(1.0, 0.72, 0.3, 0.9), 18, 200.0, 0.5)
	flaring = want
	if flaring:
		oil = maxf(0.0, oil - Tune.v("flare_drain") * delta)
		regen_wait = Tune.v("flare_regen_delay")
		if oil <= 0.0:
			flare_locked = true
			flaring = false
	else:
		regen_wait -= delta
		if regen_wait <= 0.0:
			oil = minf(1.0, oil + Tune.v("flare_regen") * delta)
	if flare_locked and not _held("lantern") and oil >= 0.35:
		flare_locked = false
	light.radius = Tune.v("lantern_radius")
	var boost := (Tune.v("flare_radius") - light.radius) if flaring else 0.0
	light.boost_radius = lerpf(light.boost_radius, boost, 1.0 - exp(-(14.0 if flaring else 6.0) * delta))
	light.strength = 1.0 if not flare_locked else 0.85
	light.halo_color.a = 0.3 + (0.25 if flaring else 0.0)


func _animate(delta: float) -> void:
	var on_floor := is_on_floor()
	var anim := "idle"
	var sliding := wall_dir != 0 and not on_floor and velocity.y > 0.0 and signf(input_x) == float(wall_dir)
	if dash_timer > 0.0:
		anim = "dash"
	elif not on_floor:
		if sliding:
			anim = "wall"
			facing = wall_dir
		elif velocity.y < -60.0:
			anim = "jump"
		else:
			anim = "fall"
	elif land_timer > 0.0:
		anim = "land"
	elif absf(velocity.x) > 25.0:
		anim = "run"
	if sprite.animation != anim:
		sprite.play(anim)
	if anim == "run":
		sprite.speed_scale = clampf(absf(velocity.x) / Tune.v("run_speed"), 0.5, 1.4)
		_dust_t -= delta
		if _dust_t <= 0.0 and absf(velocity.x) > 170.0 and fx:
			_dust_t = 0.16
			fx.dust(global_position + Vector2(-facing * 8, 0), 0.35, Vector2(-facing, -1))
	else:
		sprite.speed_scale = 1.0
	sprite.flip_h = facing < 0
	visual.scale = visual.scale.lerp(Vector2.ONE, 1.0 - exp(-14.0 * delta))
	# Lantern hangs from the front hand and swings with acceleration.
	var ax := (velocity.x - _prev_vx) / maxf(delta, 0.001)
	_prev_vx = velocity.x
	_lantern_vel += (-_lantern_angle * 90.0 - _lantern_vel * 7.0 - ax * 0.006) * delta
	_lantern_angle = clampf(_lantern_angle + _lantern_vel * delta, -1.1, 1.1)
	var hand := Vector2(15, -27)
	match anim:
		"run": hand = Vector2(16, -26 + sin(_t * 18.0) * 1.5)
		"jump": hand = Vector2(14, -33)
		"fall": hand = Vector2(15, -31)
		"wall": hand = Vector2(-12, -30)
		"dash": hand = Vector2(-16, -20)
		"land": hand = Vector2(15, -22)
	lantern_pivot.position = Vector2(hand.x * facing, hand.y)
	lantern_pivot.rotation = _lantern_angle + sin(_t * 2.3) * 0.06


func bounce() -> void:
	velocity.y = -(Tune.v("stomp_bounce_held") if _held("jump") else Tune.v("stomp_bounce"))
	jumping = _held("jump")
	dash_ready = true
	dash_timer = 0.0
	coyote = 0.0
	visual.scale = Vector2(0.8, 1.2)


func die() -> void:
	if not alive or invulnerable > 0.0:
		return
	alive = false
	velocity = Vector2.ZERO
	dash_timer = 0.0
	flaring = false
	light.enabled = false
	sprite.play("hurt")
	var tw := create_tween()
	tw.tween_property(visual, "scale", Vector2(1.3, 0.2), 0.16).set_delay(0.08)
	tw.tween_callback(func() -> void: visual.visible = false)
	if fx:
		fx.burst(global_position + Vector2(0, -18), Color(1.0, 0.6, 0.3, 1.0), 26, 260.0, 0.8, 200.0, 1.2)
		fx.burst(global_position + Vector2(0, -18), Color(0.2, 0.12, 0.3, 0.9), 18, 140.0, 0.9, -40.0, 1.8, false)
		fx.shake(9.0, 0.3)
		fx.hitstop(0.06)
		fx.flash(Color(0.35, 0.1, 0.25), 0.3, 0.3)
	GameAudio.play(&"death")
	died.emit()


func respawn(at: Vector2) -> void:
	drop_timer = 0.0
	set_collision_mask_value(5, true)
	global_position = at
	velocity = Vector2.ZERO
	alive = true
	frozen = false
	invulnerable = 0.4
	oil = 1.0
	flare_locked = false
	dash_ready = true
	dash_timer = 0.0
	jump_buffer = 0.0
	coyote = 0.0
	was_on_floor = true
	light.enabled = true
	light.boost_radius = 0.0
	visual.visible = true
	visual.scale = Vector2(0.4, 1.5)
	sprite.play("idle")
	if fx:
		fx.burst(at + Vector2(0, -20), Color(1.0, 0.8, 0.45, 1.0), 22, 150.0, 0.6, -60.0, 1.0)
	GameAudio.play(&"respawn")
	reset_physics_interpolation()
