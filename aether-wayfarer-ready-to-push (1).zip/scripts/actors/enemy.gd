class_name Enemy
extends CharacterBody2D
## Data-driven murk creature (see data/enemies.json).
## Walkers patrol and turn at walls/ledges; flyers bob and drift toward the
## player. Stompable kinds die when landed on; every kind is dispelled by
## holding the lantern flare on it for `tolerance` seconds.

signal defeated(enemy: Enemy, by_light: bool)

const FLASH := preload("res://shaders/flash.gdshader")
static var defs: Dictionary = {}

var kind := "murkling"
var def: Dictionary
var home := Vector2.ZERO
var dir := -1
var alive := true
var exposure := 0.0
var aggro := false
var sprite: AnimatedSprite2D
var _aura: Sprite2D
var player: Player
var _mat: ShaderMaterial
var _flash := 0.0
var _t := randf() * 10.0
var _body := Vector2(30, 30)
var _burn_fx := 0.0


static func load_defs() -> Dictionary:
	if defs.is_empty():
		defs = JSON.parse_string(FileAccess.get_file_as_string("res://data/enemies.json"))
	return defs


static func kind_for_glyph(glyph: String) -> String:
	for k in load_defs():
		if defs[k].glyph == glyph:
			return k
	return ""


func setup(kind_name: String, pos: Vector2) -> void:
	kind = kind_name
	def = load_defs()[kind]
	home = pos
	position = pos


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1 | 16
	_body = Vector2(def.body[0], def.body[1])
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(minf(_body.x, 24), _body.y)
	shape.shape = box
	shape.position = Vector2(0, -_body.y * 0.5)
	add_child(shape)
	var frames := SpriteFrames.new()
	frames.remove_animation(&"default")
	frames.add_animation(&"move")
	frames.set_animation_speed(&"move", def.fps)
	var tex: Texture2D = load(def.sheet)
	for i in int(def.frames):
		var atlas := AtlasTexture.new()
		atlas.atlas = tex
		atlas.region = Rect2(i * def.cell[0], 0, def.cell[0], def.cell[1])
		frames.add_frame(&"move", atlas)
	# Faint violet aura so murk creatures read against the dark.
	var aura := Sprite2D.new()
	aura.texture = LightSource.glow_texture()
	var aura_px: float = def.cell[0] * def.scale * 1.9
	aura.scale = Vector2.ONE * aura_px / float(aura.texture.get_width())
	aura.position = Vector2(0, -def.cell[1] * def.scale * 0.45)
	aura.modulate = Color(0.62, 0.36, 1.0, 0.32)
	var add_mat := CanvasItemMaterial.new()
	add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	aura.material = add_mat
	add_child(aura)
	_aura = aura
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = frames
	sprite.scale = Vector2(def.scale, def.scale)
	sprite.offset = Vector2(0, def.cell[1] * 0.5 - def.feet)
	sprite.play(&"move")
	sprite.frame = randi() % int(def.frames)
	_mat = ShaderMaterial.new()
	_mat.shader = FLASH
	sprite.material = _mat
	add_child(sprite)


func reset() -> void:
	position = home
	velocity = Vector2.ZERO
	alive = true
	exposure = 0.0
	if _aura:
		_aura.modulate.a = 0.32
	aggro = false
	visible = true
	sprite.modulate = Color.WHITE
	sprite.scale = Vector2(def.scale, def.scale)
	set_physics_process(true)
	reset_physics_interpolation()


func rect() -> Rect2:
	return Rect2(global_position + Vector2(-_body.x * 0.5, -_body.y), _body)


func _physics_process(delta: float) -> void:
	if not alive:
		return
	_t += delta
	if player == null or not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player") as Player
		if player == null:
			return
	var to_player := player.global_position - global_position
	var aggro_range := Tune.v("enemy_aggro_range")
	var was_aggro := aggro
	aggro = player.alive and absf(to_player.x) < aggro_range and absf(to_player.y) < (aggro_range if def.flying else 70.0)
	if aggro and not was_aggro:
		GameAudio.play(&"alert")
		if not def.flying and is_on_floor():
			velocity.y = -180.0
	if def.flying:
		_fly(delta, to_player)
	else:
		_walk(delta, to_player)
	_light_exposure(delta)
	_contact()
	_flash = move_toward(_flash, 0.0, delta * 4.0)
	_mat.set_shader_parameter("flash", _flash)
	var facing_left := dir < 0
	sprite.flip_h = facing_left != bool(def.faces_left)
	# Readability in the dark: never fully swallowed, brighter when lit.
	var field := get_tree().get_first_node_in_group("light_field") as LightField
	var lit := field.light_at(global_position + Vector2(0, -16)) if field else 1.0
	var shiver := exposure / maxf(Tune.v(def.tolerance_key), 0.05)
	sprite.position = Vector2(randf_range(-2, 2), 0) * shiver
	sprite.modulate = Color(1, 1, 1).lerp(Color(0.72, 0.68, 0.9), 1.0 - lit)


func _walk(delta: float, to_player: Vector2) -> void:
	var speed := Tune.v(def.chase_key if aggro else def.speed_key)
	if aggro and absf(to_player.x) > 6.0:
		dir = int(signf(to_player.x))
	var ahead := Vector2(dir * (_body.x * 0.5 + 4), 0)
	if is_on_floor():
		var blocked := test_move(global_transform, Vector2(dir * 4, 0))
		var probe := global_transform.translated(ahead)
		var ledge := not test_move(probe, Vector2(0, 12))
		if blocked or ledge:
			dir = -dir
			if aggro:
				speed = 0.0
	velocity.x = dir * speed
	velocity.y = minf(velocity.y + 1500.0 * delta, 700.0)
	move_and_slide()


func _fly(delta: float, to_player: Vector2) -> void:
	var target := home + Vector2(sin(_t * 0.8) * 60.0, sin(_t * 1.6) * 14.0)
	if aggro:
		target = player.global_position + Vector2(0, -10)
	var speed := Tune.v(def.speed_key) * (1.35 if aggro else 1.0)
	var desired := (target - global_position)
	if desired.length() > 2.0:
		desired = desired.normalized() * speed
	velocity = velocity.lerp(desired, 1.0 - exp(-2.5 * delta))
	if absf(velocity.x) > 4.0:
		dir = int(signf(velocity.x))
	global_position += velocity * delta
	sprite.rotation = sin(_t * 3.0) * 0.08


func _light_exposure(delta: float) -> void:
	var reach := player.flare_reach()
	var center := global_position + Vector2(0, -_body.y * 0.5)
	if reach > 0.0 and center.distance_to(player.lantern_world_pos()) < reach:
		exposure += delta
		_flash = maxf(_flash, 0.35 + 0.3 * sin(_t * 40.0))
		_burn_fx -= delta
		if _burn_fx <= 0.0:
			_burn_fx = 0.07
			var fx := Fx.find(self)
			if fx:
				fx.burst(center, Color(1.0, 0.85, 0.55, 0.8), 3, 60.0, 0.4, -80.0, 0.8, true, 60.0)
		if exposure >= Tune.v(def.tolerance_key):
			defeat(true)
	else:
		exposure = maxf(0.0, exposure - delta * 0.6)


func _contact() -> void:
	if not player.alive:
		return
	var pr := player.hurt_rect()
	var er := rect().grow(-3)
	if not pr.intersects(er):
		return
	var falling_onto := player.velocity.y > 30.0 and player.global_position.y <= er.position.y + 12.0
	if falling_onto and def.stompable:
		player.bounce()
		defeat(false)
	else:
		player.die()


func defeat(by_light: bool) -> void:
	if not alive:
		return
	alive = false
	set_physics_process(false)
	_flash = 1.0
	_mat.set_shader_parameter("flash", 1.0)
	var fx := Fx.find(self)
	var center := global_position + Vector2(0, -_body.y * 0.5)
	if fx:
		fx.burst(center, Color(0.25, 0.12, 0.35, 0.95), 18, 170.0, 0.7, -30.0, 1.6, false)
		fx.burst(center, Color(1.0, 0.8, 0.45, 1.0), 14, 200.0, 0.5, 0.0, 0.9)
		fx.hitstop(0.05 if not by_light else 0.03)
		fx.shake(5.0 if not by_light else 3.0, 0.15)
	GameAudio.play(&"dispel" if by_light else &"stomp")
	var tw := create_tween().set_parallel()
	tw.tween_property(_aura, "modulate:a", 0.0, 0.25)
	if by_light:
		tw.tween_property(sprite, "scale", sprite.scale * Vector2(1.3, 1.3), 0.3)
		tw.tween_property(sprite, "modulate:a", 0.0, 0.3)
	else:
		tw.tween_property(sprite, "scale", Vector2(def.scale * 1.5, def.scale * 0.3), 0.12)
		tw.tween_property(sprite, "modulate:a", 0.0, 0.25).set_delay(0.08)
	tw.chain().tween_callback(func() -> void: visible = false)
	defeated.emit(self, by_light)
