class_name Boss
extends Node2D
## Murkmaw, the fog that swallowed the belltower. Data: level.boss in boss.json.
## Loop per phase: hover + telegraphed attacks while one brazier is "ready".
## Lighting it stuns the boss; stomp it or hold the flare on it to land a hit.

signal hp_changed(hp: int, max_hp: int)
signal defeated
signal phase_started(index: int)

const IDLE := preload("res://assets/art/boss/idle.png")
const STUNNED := preload("res://assets/art/boss/stunned.png")
const FLASH := preload("res://shaders/flash.gdshader")

var cfg: Dictionary
var max_hp := 3
var hp := 3
var phase := 0
var state := "intro"
var state_t := 0.0
var anchor := Vector2(640, 176)
var floor_y := 608.0
var arena := Rect2(64, 32, 1152, 576)
var braziers: Array = []
var shots_parent: Node2D
var enemies_parent: Node2D
var player: Player
var sprite: Sprite2D
var light: LightSource
var telegraph: BossTelegraph
var _mat: ShaderMaterial
var _flash := 0.0
var _t := 0.0
var _attack_i := 0
var _gap := 2.0
var _attack := ""
var _side := 1
var _stun_exposure := 0.0
var _summons: Array = []
var _from := Vector2.ZERO
var _target := Vector2.ZERO
var _vel := Vector2.ZERO


func setup(config: Dictionary, arena_rect: Rect2, floor_level: float, anchor_pos: Vector2) -> void:
	cfg = config
	max_hp = int(cfg.get("hp", 3))
	hp = max_hp
	arena = arena_rect
	floor_y = floor_level
	anchor = anchor_pos
	position = Vector2(anchor.x, floor_y + 160)


func _ready() -> void:
	add_to_group("boss")
	z_index = 5
	sprite = Sprite2D.new()
	sprite.texture = IDLE
	sprite.scale = Vector2(0.55, 0.55)
	_mat = ShaderMaterial.new()
	_mat.shader = FLASH
	sprite.material = _mat
	add_child(sprite)
	light = LightSource.new()
	light.radius = 90
	light.strength = 0.35
	light.halo_color = Color(0.6, 0.35, 0.9, 0.35)
	add_child(light)
	telegraph = BossTelegraph.new()
	telegraph.floor_y = floor_y
	telegraph.top_y = arena.position.y
	sprite.modulate = Color(1, 1, 1, 0)


func begin() -> void:
	get_parent().add_child(telegraph)
	player = get_tree().get_first_node_in_group("player") as Player
	_set_state("intro")
	GameAudio.play(&"boss_roar")
	var fx := Fx.find(self)
	if fx:
		fx.shake(10.0, 1.2)


func _set_state(s: String) -> void:
	state = s
	state_t = 0.0


func _phase_cfg() -> Dictionary:
	var phases: Array = cfg.phases
	return phases[mini(phase, phases.size() - 1)]


func _speed() -> float:
	return float(_phase_cfg().get("speed", 1.0))


func _start_phase() -> void:
	_attack_i = 0
	_gap = Tune.v("boss_attack_gap") * 0.8
	for b in braziers:
		b.extinguish()
	var idx := int(_phase_cfg().brazier)
	if idx < braziers.size():
		braziers[idx].set_ready(true)
	phase_started.emit(phase)
	_set_state("hover")


func on_brazier_lit(_b: Brazier) -> void:
	if state in ["intro", "hurt", "dead", "stunned", "fall"]:
		return
	telegraph.clear()
	_from = position
	_target = Vector2(clampf(position.x, arena.position.x + 90, arena.end.x - 90), floor_y - 72)
	_set_state("fall")
	_flash = 1.0
	GameAudio.play(&"boss_hit")


func _physics_process(delta: float) -> void:
	_t += delta
	state_t += delta
	if player == null:
		player = get_tree().get_first_node_in_group("player") as Player
		if player == null:
			return
	match state:
		"intro":
			sprite.modulate.a = minf(1.0, state_t / 1.2)
			position = position.lerp(anchor, 1.0 - exp(-2.2 * delta))
			if state_t > 2.0:
				_start_phase()
		"hover":
			_hover(delta)
			if player.alive:
				_gap -= delta
			if _gap <= 0.0:
				_next_attack()
		"rain_tele":
			_hover(delta, 0.4)
			if state_t >= Tune.v("boss_telegraph") / _speed():
				_release_rain()
				_end_attack()
		"wave_move":
			position = _from.lerp(_target, _ease(state_t / 0.7))
			if state_t >= 0.7:
				_set_state("wave_tele")
				telegraph.lane(_side * -1, position.x, floor_y, Tune.v("boss_telegraph") / _speed())
				GameAudio.play(&"telegraph")
		"wave_tele":
			sprite.position = Vector2(randf_range(-3, 3), randf_range(-2, 2))
			if state_t >= Tune.v("boss_telegraph") / _speed():
				sprite.position = Vector2.ZERO
				_spawn_wave(position.x, -_side)
				_from = position
				_target = anchor
				_set_state("return")
		"slam_track":
			var tx := clampf(player.global_position.x, arena.position.x + 80, arena.end.x - 80)
			position.x = lerpf(position.x, tx, 1.0 - exp(-3.0 * delta))
			position.y = lerpf(position.y, anchor.y - 20, 1.0 - exp(-3.0 * delta))
			telegraph.target_x = position.x
			if state_t >= Tune.v("boss_telegraph") * 1.2 / _speed():
				_from = position
				_set_state("slam_fall")
		"slam_fall":
			position.y = move_toward(position.y, floor_y - 70, 1100.0 * delta)
			if position.y >= floor_y - 70.5:
				telegraph.target_x = -1.0
				_spawn_wave(position.x, -1)
				_spawn_wave(position.x, 1)
				_set_state("slam_rest")
		"slam_rest":
			if state_t > 0.6:
				_from = position
				_target = anchor
				_set_state("return")
		"return":
			position = _from.lerp(_target, _ease(state_t / 0.8))
			if state_t >= 0.8:
				_end_attack()
		"fall":
			position = _from.lerp(_target, _ease(state_t / 0.45))
			if state_t >= 0.45:
				sprite.texture = STUNNED
				sprite.scale = Vector2(0.44, 0.44)
				sprite.position = Vector2(0, -8)
				_stun_exposure = 0.0
				var fx := Fx.find(self)
				if fx:
					fx.dust(Vector2(position.x, floor_y), 3.0)
					fx.shake(12.0, 0.4)
				_set_state("stunned")
		"stunned":
			sprite.rotation = sin(_t * 3.0) * 0.04
			_stunned_checks(delta)
			if state_t >= Tune.v("boss_stun_time"):
				_recover(false)
		"hurt":
			sprite.position = Vector2(randf_range(-6, 6), randf_range(-4, 4)) * clampf(1.0 - state_t, 0.0, 1.0)
			position = _from.lerp(anchor, _ease(state_t / 1.2))
			if state_t >= 1.4:
				sprite.position = Vector2.ZERO
				_start_phase()
		"dead":
			sprite.position = Vector2(randf_range(-8, 8), randf_range(-6, 6))
			sprite.modulate.a = maxf(0.0, 1.0 - state_t / 2.2)
			if fmod(state_t, 0.18) < delta:
				var fx := Fx.find(self)
				if fx:
					fx.burst(position + Vector2(randf_range(-70, 70), randf_range(-60, 60)), Color(1.0, 0.8, 0.45, 1.0), 12, 200.0, 0.6)
					fx.shake(5.0, 0.15)
			if state_t >= 2.4 and visible:
				visible = false
				defeated.emit()
	_contact()
	_flash = move_toward(_flash, 0.0, delta * 3.0)
	_mat.set_shader_parameter("flash", _flash)
	_summons = _summons.filter(func(e: Variant) -> bool: return is_instance_valid(e) and e.alive)


func _ease(k: float) -> float:
	k = clampf(k, 0.0, 1.0)
	return k * k * (3.0 - 2.0 * k)


func _hover(delta: float, damp := 1.0) -> void:
	var goal := anchor + Vector2(sin(_t * 0.7) * 300.0, sin(_t * 1.4) * 34.0) * damp
	position = position.lerp(goal, 1.0 - exp(-1.8 * delta))
	sprite.rotation = sin(_t * 1.1) * 0.05
	sprite.flip_h = player.global_position.x > position.x


func _next_attack() -> void:
	var attacks: Array = _phase_cfg().attacks
	_attack = attacks[_attack_i % attacks.size()]
	_attack_i += 1
	_flash = 0.5
	match _attack:
		"rain":
			var xs := _rain_columns(int(_phase_cfg().get("rain_count", 4)))
			telegraph.columns(xs, Tune.v("boss_telegraph") / _speed())
			GameAudio.play(&"telegraph")
			_set_state("rain_tele")
		"wave":
			_side = 1 if player.global_position.x < arena.get_center().x else -1
			_from = position
			_target = Vector2(arena.get_center().x + _side * (arena.size.x * 0.5 - 90), floor_y - 90)
			_set_state("wave_move")
		"summon":
			_summon()
			_end_attack()
		"slam":
			GameAudio.play(&"telegraph")
			telegraph.target_x = position.x
			telegraph.target_time = Tune.v("boss_telegraph") * 1.2 / _speed()
			_set_state("slam_track")
		_:
			_end_attack()


func _end_attack() -> void:
	_gap = Tune.v("boss_attack_gap") / _speed()
	_set_state("hover")


func _rain_columns(count: int) -> Array:
	var xs: Array = [clampf(player.global_position.x, arena.position.x + 30, arena.end.x - 30)]
	var tries := 0
	while xs.size() < count and tries < 80:
		tries += 1
		var x := randf_range(arena.position.x + 30, arena.end.x - 30)
		var ok := true
		for other: float in xs:
			if absf(other - x) < 110.0:
				ok = false
				break
		if ok:
			xs.append(x)
	return xs


func _release_rain() -> void:
	var i := 0
	for x: float in telegraph.column_xs:
		var shot := MurkShot.new()
		shot.kind = "drop"
		shot.position = Vector2(x, arena.position.y + 10 - i * 26)
		shot.velocity = Vector2(0, 260)
		shot.floor_y = floor_y
		shots_parent.add_child(shot)
		i += 1
	telegraph.clear()
	GameAudio.play(&"boss_attack")


func _spawn_wave(x: float, dir: int) -> void:
	var shot := MurkShot.new()
	shot.kind = "wave"
	shot.position = Vector2(x + dir * 60, floor_y)
	shot.velocity = Vector2(dir * 330.0 * _speed(), 0)
	shot.min_x = arena.position.x
	shot.max_x = arena.end.x
	shots_parent.add_child(shot)
	GameAudio.play(&"boss_attack")
	var fx := Fx.find(self)
	if fx:
		fx.shake(9.0, 0.3)
		fx.dust(Vector2(x, floor_y), 2.5)


func _summon() -> void:
	GameAudio.play(&"boss_roar")
	if _summons.size() >= 3:
		return
	for side in [-1, 1]:
		var e := Enemy.new()
		e.setup("wisp", position + Vector2(side * 110, 20))
		enemies_parent.add_child(e)
		_summons.append(e)
		var fx := Fx.find(self)
		if fx:
			fx.burst(e.position, Color(0.4, 0.2, 0.55, 0.9), 14, 150.0, 0.6, 0.0, 1.4, false)


func _stunned_checks(delta: float) -> void:
	if not player.alive:
		return
	# Stomp: falling onto the slumped head.
	var feet := player.global_position
	if player.velocity.y > 0.0 and feet.y < position.y - 4.0 and feet.y > position.y - 120.0 and absf(feet.x - position.x) < 64.0:
		player.bounce()
		_take_hit(false)
		return
	# Flare: hold the lantern on it.
	var reach := player.flare_reach()
	if reach > 0.0 and position.distance_to(player.lantern_world_pos()) < reach + 40.0:
		_stun_exposure += delta
		_flash = maxf(_flash, 0.4 + 0.3 * sin(_t * 40.0))
		if _stun_exposure >= 0.75:
			_take_hit(true)


func _take_hit(by_light: bool) -> void:
	hp -= 1
	hp_changed.emit(hp, max_hp)
	_flash = 1.0
	sprite.texture = IDLE
	sprite.scale = Vector2(0.55, 0.55)
	sprite.rotation = 0.0
	telegraph.clear()
	for b in braziers:
		b.extinguish()
	GameAudio.play(&"boss_hit")
	GameAudio.play(&"boss_roar")
	var fx := Fx.find(self)
	if fx:
		fx.burst(position, Color(1.0, 0.85, 0.5, 1.0), 40, 320.0, 0.8, 100.0, 1.4)
		fx.burst(position, Color(0.3, 0.12, 0.4, 0.95), 30, 240.0, 1.0, -40.0, 2.0, false)
		fx.hitstop(0.14)
		fx.shake(16.0, 0.5)
		fx.flash(Color(1.0, 0.9, 0.7), 0.45, 0.35)
	for s in _summons:
		if is_instance_valid(s):
			s.defeat(true)
	if hp <= 0:
		_set_state("dead")
		for shot in shots_parent.get_children():
			if shot is MurkShot:
				shot.pop(false)
		return
	phase += 1
	_from = position
	_set_state("hurt")
	if by_light:
		pass


func _recover(_hit: bool) -> void:
	sprite.texture = IDLE
	sprite.scale = Vector2(0.55, 0.55)
	sprite.rotation = 0.0
	GameAudio.play(&"boss_roar")
	var fx := Fx.find(self)
	if fx:
		fx.shake(6.0, 0.3)
	# Same brazier becomes available again shortly.
	for b in braziers:
		b.extinguish()
	var idx := int(_phase_cfg().brazier)
	get_tree().create_timer(1.5, false).timeout.connect(func() -> void:
		if state != "dead" and idx < braziers.size():
			braziers[idx].set_ready(true))
	_from = position
	_target = anchor
	_set_state("return")


func _contact() -> void:
	if state in ["stunned", "intro", "dead", "hurt", "fall"] or not player.alive:
		return
	var pr := player.hurt_rect()
	var c := position + Vector2(0, -6)
	var closest := Vector2(clampf(c.x, pr.position.x, pr.end.x), clampf(c.y, pr.position.y, pr.end.y))
	if closest.distance_to(c) < 56.0:
		player.die()


## Called when the player respawns: clear hazards, keep boss progress.
func on_player_respawn() -> void:
	telegraph.clear()
	for shot in shots_parent.get_children():
		if shot is MurkShot:
			shot.queue_free()
	for s in _summons:
		if is_instance_valid(s):
			s.queue_free()
	_summons.clear()
	if state in ["rain_tele", "wave_move", "wave_tele", "slam_track", "slam_fall", "slam_rest"]:
		sprite.position = Vector2.ZERO
		_from = position
		_target = anchor
		_set_state("return")
	_gap = maxf(_gap, 1.6)
