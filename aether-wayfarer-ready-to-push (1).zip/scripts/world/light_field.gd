class_name LightField
extends CanvasLayer
## Collects every LightSource in the level, feeds the murk shader and answers
## "how lit is this point?" for spirit platforms and enemies.

const MAX_LIGHTS := 24
const SHADER := preload("res://shaders/murk.gdshader")

var darkness := 0.9
var rect: ColorRect
var _material: ShaderMaterial
var _sources: Array[LightSource] = []
var _packed := PackedVector4Array()


func _init() -> void:
	layer = 5
	name = "LightField"


func _ready() -> void:
	add_to_group("light_field")
	rect = ColorRect.new()
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_material = ShaderMaterial.new()
	_material.shader = SHADER
	rect.material = _material
	add_child(rect)
	_packed.resize(MAX_LIGHTS)


func configure(level_darkness: float, fog: Color, rim: Color) -> void:
	darkness = level_darkness
	_material.set_shader_parameter("fog_color", fog)
	_material.set_shader_parameter("rim_color", rim)


func register(source: LightSource) -> void:
	if not source in _sources:
		_sources.append(source)


func unregister(source: LightSource) -> void:
	_sources.erase(source)


func set_detail(high: bool) -> void:
	_material.set_shader_parameter("fog_detail", 1.0 if high else 0.0)


## Light intensity 0..1 at a world point (matches the shader falloff).
func light_at(world_pos: Vector2, ignore_flare := false) -> float:
	var best := 0.0
	for source in _sources:
		if not source.is_active():
			continue
		var radius := source.base_radius() if ignore_flare else source.current_radius()
		var d := world_pos.distance_to(source.global_position) / maxf(radius, 1.0)
		best = maxf(best, (1.0 - smoothstep(0.35, 1.0, d)) * source.strength)
	return best


func _process(_delta: float) -> void:
	var viewport := get_viewport()
	var canvas := viewport.get_canvas_transform()
	var size := viewport.get_visible_rect().size
	var scale := canvas.get_scale().x
	var count := 0
	var screen := Rect2(Vector2.ZERO, size)
	for source in _sources:
		if count >= MAX_LIGHTS or not source.is_active():
			continue
		var p := canvas * source.global_position
		var r := source.current_radius() * scale
		if not screen.grow(r).has_point(p):
			continue
		_packed[count] = Vector4(p.x, p.y, r, source.strength)
		count += 1
	_material.set_shader_parameter("lights", _packed)
	_material.set_shader_parameter("light_count", count)
	_material.set_shader_parameter("rect_size", size)
	var tuning := get_node_or_null("/root/TuningStore")
	var scale_dark: float = tuning.get_value("darkness_scale") if tuning else 1.0
	_material.set_shader_parameter("darkness", clampf(darkness * scale_dark, 0.0, 1.0))
	_material.set_shader_parameter("fog_offset", -canvas.origin * 0.6)
