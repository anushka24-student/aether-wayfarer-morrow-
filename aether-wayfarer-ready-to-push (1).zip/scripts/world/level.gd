class_name Level
extends Node2D
## Builds one playable level from data/levels/<id>.json + data/themes.json.
## Layers: Backdrop (-10) < World (0) < LightField murk (5) < AboveFog (6).

const TILE := 32

var data: Dictionary
var theme: Dictionary
var terrain: Terrain
var light_field: LightField
var backdrop: Backdrop
var above_fog: CanvasLayer
var actors: Node2D
var world: Node2D
var spawn := Vector2.ZERO
var checkpoints: Array[Waylamp] = []
var embers: Array[Ember] = []
var enemies: Array[Enemy] = []
var braziers: Array = []
var beacon: Beacon
var boss: Boss
var hints: Array = []
var motes: CPUParticles2D
var size_px := Vector2.ZERO


static func load_level(id: String) -> Dictionary:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/levels/%s.json" % id))
	return parsed if parsed is Dictionary else {}


static func campaign_order() -> Array:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/levels/campaign.json"))
	return parsed.order if parsed is Dictionary else ["forest", "cave", "tower", "boss"]


static func load_theme(name: String) -> Dictionary:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/themes.json"))
	return parsed.get(name, {}) if parsed is Dictionary else {}


func build(level_data: Dictionary, ember_mask: int) -> void:
	data = level_data
	theme = load_theme(data.theme)
	var map: Array = data.map
	size_px = Vector2(str(map[0]).length(), map.size()) * TILE
	backdrop = Backdrop.new()
	backdrop.setup(theme, size_px)
	add_child(backdrop)
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	terrain = Terrain.new()
	terrain.name = "Terrain"
	terrain.setup(map, theme)
	world.add_child(terrain)
	for run in terrain.spirit_runs():
		var sp := SpiritPlatform.new()
		sp.setup(run)
		world.add_child(sp)
	light_field = LightField.new()
	add_child(light_field)
	light_field.configure(float(data.get("darkness", 0.85)), Color(theme.fog), Color(theme.rim))
	light_field.set_detail(Tune.quality_high())
	above_fog = CanvasLayer.new()
	above_fog.name = "AboveFog"
	above_fog.layer = 6
	above_fog.follow_viewport_enabled = true
	add_child(above_fog)
	actors = Node2D.new()
	actors.name = "Actors"
	above_fog.add_child(actors)
	var glint := HazardGlint.new()
	glint.up_runs = terrain.thorn_up
	glint.down_runs = terrain.thorn_down
	above_fog.add_child(glint)
	motes = Glowcap.ambient_motes(Color(theme.get("mote", "#ffe0a0")))
	world.add_child(motes)
	_spawn_entities(map, ember_mask)


func _spawn_entities(map: Array, ember_mask: int) -> void:
	var ember_i := 0
	var lamp_i := 0
	var hint_keys: Array = data.get("hints", [])
	var anchor := Vector2(size_px.x * 0.5, 176)
	for r in map.size():
		var line: String = map[r]
		for c in line.length():
			var ch := line[c]
			var bottom := Vector2(c * TILE + 16, r * TILE + TILE)
			var center := Vector2(c * TILE + 16, r * TILE + 16)
			match ch:
				"P":
					spawn = bottom
				"C":
					var lamp := Waylamp.new()
					lamp.setup(bottom, lamp_i)
					lamp_i += 1
					world.add_child(lamp)
					checkpoints.append(lamp)
				"B":
					beacon = Beacon.new()
					beacon.position = bottom
					world.add_child(beacon)
				"*":
					var ember := Ember.new()
					ember.setup(center, ember_i, (ember_mask >> ember_i) & 1 == 1)
					ember_i += 1
					world.add_child(ember)
					embers.append(ember)
				"l":
					var cap := Glowcap.new()
					cap.tint = Color(theme.get("mote", "#b0ffd0"))
					cap.position = bottom
					world.add_child(cap)
				"Z":
					var brazier := Brazier.new()
					brazier.index = braziers.size()
					brazier.position = bottom
					actors.add_child(brazier)
					braziers.append(brazier)
				"X":
					anchor = Vector2(size_px.x * 0.5, float(data.get("boss", {}).get("hover_row", 5)) * TILE + 16)
				_:
					if ch.is_valid_int() and int(ch) >= 1:
						var idx := int(ch) - 1
						if idx < hint_keys.size():
							hints.append({"x": float(c * TILE), "y": float(r * TILE), "key": hint_keys[idx], "shown": false})
					else:
						var kind := Enemy.kind_for_glyph(ch)
						if kind != "":
							var enemy := Enemy.new()
							enemy.setup(kind, center if Enemy.defs[kind].flying else bottom)
							actors.add_child(enemy)
							enemies.append(enemy)
	if data.has("boss"):
		boss = Boss.new()
		var floor_y := _floor_below(anchor.x)
		boss.setup(data.boss, Rect2(64, 32, size_px.x - 128, floor_y - 32), floor_y, anchor)
		boss.braziers = braziers
		boss.shots_parent = actors
		boss.enemies_parent = actors
		actors.add_child(boss)
		for b in braziers:
			b.lit_up.connect(boss.on_brazier_lit)


func _floor_below(x: float) -> float:
	var c := int(x / TILE)
	for r in terrain.rows:
		if r > 4 and terrain.cell(c, r) == "#":
			return r * TILE
	return size_px.y - TILE


func bounds() -> Rect2:
	return Rect2(Vector2.ZERO, size_px)


func reset_enemies() -> void:
	for e in enemies:
		if is_instance_valid(e):
			e.reset()


func _process(_delta: float) -> void:
	var cam := get_viewport().get_camera_2d()
	if cam and motes:
		motes.global_position = cam.get_screen_center_position()
