class_name HazardGlint
extends Node2D
## Draws a faint pulsing outline over thorn tiles above the murk, so hazards
## stay readable in the dark without being fully lit.

const TILE := 32
var up_runs: Array[Rect2i] = []
var down_runs: Array[Rect2i] = []
var _t := 0.0


func _ready() -> void:
	z_index = -5


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	var vp := get_viewport_rect()
	var cam := get_viewport().get_camera_2d()
	var view := Rect2(cam.get_screen_center_position() - vp.size, vp.size * 2.0) if cam else Rect2(-1e5, -1e5, 2e5, 2e5)
	for r in up_runs:
		_row(r, -1.0, view)
	for r in down_runs:
		_row(r, 1.0, view)


func _row(r: Rect2i, dir: float, view: Rect2) -> void:
	var y := float(r.position.y * TILE + (TILE if dir < 0.0 else 0))
	var x0 := float(r.position.x * TILE)
	var w := float(r.size.x * TILE)
	if not view.intersects(Rect2(x0, y - TILE, w, TILE * 2)):
		return
	var spikes := r.size.x * 3
	var sw := w / spikes
	for i in spikes:
		var x := x0 + i * sw
		var a := 0.22 + 0.12 * sin(_t * 3.0 + i * 0.7)
		var c := Color(1.0, 0.42, 0.52, a)
		var tip := Vector2(x + sw * 0.5, y + dir * 16.0)
		draw_polyline(PackedVector2Array([Vector2(x + 1, y), tip, Vector2(x + sw - 1, y)]), c, 1.5, true)
