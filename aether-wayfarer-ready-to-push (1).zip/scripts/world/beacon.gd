class_name Beacon
extends Area2D
## Level goal. Touching it lights the beacon and ends the level.

signal reached

const UNLIT := preload("res://assets/art/props/beacon_unlit.png")
const LIT := preload("res://assets/art/props/beacon_lit.png")

var lit := false
var sprite: Sprite2D
var light: LightSource
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitorable = false
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(56, 150)
	shape.shape = box
	shape.position = Vector2(0, -75)
	add_child(shape)
	sprite = Sprite2D.new()
	sprite.texture = UNLIT
	sprite.scale = Vector2(0.44, 0.44)
	sprite.offset = Vector2(0, -196)
	add_child(sprite)
	light = LightSource.new()
	light.position = Vector2(0, -140)
	light.radius = 90
	light.strength = 0.6
	light.halo_color = Color(0.42, 0.86, 1.0, 0.28)
	add_child(light)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	_t += delta
	if not lit:
		light.strength = 0.5 + sin(_t * 2.0) * 0.1


func _on_body(body: Node) -> void:
	if lit or not body is Player or not (body as Player).alive:
		return
	ignite()
	reached.emit()


func ignite() -> void:
	lit = true
	sprite.texture = LIT
	light.strength = 1.0
	light.halo_color = Color(0.5, 0.92, 1.0, 0.72)
	var tw := create_tween()
	tw.tween_property(light, "radius", 520.0, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	var fx := Fx.find(self)
	if fx:
		fx.burst(global_position + Vector2(0, -150), Color(0.55, 0.82, 1.0, 1.0), 40, 320.0, 1.2, -20.0, 1.4)
		fx.shake(6.0, 0.4)
		fx.flash(Color(0.62, 0.88, 1.0), 0.35, 0.6)
	GameAudio.play(&"beacon")
