class_name Terrain
extends Node2D
## Builds collision and draws the painted terrain for one ASCII level.
## Solid tiles are merged into rectangles; exposed tops get the biome's
## grass/moss/brass edge strip, thorns get a hazard Area2D.

const TILE := 32
signal hazard_touched(body: Node)

var grid: PackedStringArray
var cols := 0
var rows := 0
var fill_tex: Texture2D
var edge_tex: Texture2D
var plank_tex: Texture2D
var thorn_tex: Texture2D = preload("res://assets/art/props/thorns.png")
var fill_tint := Color(0.62, 0.64, 0.56)
var solid_rects: Array[Rect2i] = []
var plank_runs: Array[Rect2i] = []
var thorn_up: Array[Rect2i] = []
var thorn_down: Array[Rect2i] = []


func setup(map_rows: Array, theme: Dictionary) -> void:
	grid = PackedStringArray(map_rows)
	rows = grid.size()
	cols = 0
	for line in grid:
		cols = maxi(cols, line.length())
	fill_tex = load(theme.fill)
	edge_tex = load(theme.edge)
	plank_tex = load(theme.plank)
	fill_tint = Color(theme.get("fill_tint", "#9aa08a"))
	texture_repeat = CanvasItem.TEXTURE_REPEAT_ENABLED
	_build_solids()
	_build_runs()
	_build_collision()
	queue_redraw()


func cell(c: int, r: int) -> String:
	if r < 0 or r >= rows or c < 0:
		return "."
	var line := grid[r]
	return line[c] if c < line.length() else "."


func is_solid(c: int, r: int) -> bool:
	if c < 0 or c >= cols:
		return true
	if r >= rows:
		return true
	return cell(c, r) == "#"


func _build_solids() -> void:
	# Greedy merge: horizontal runs, then extend identical runs downward.
	var used := {}
	for r in rows:
		var c := 0
		while c < cols:
			if cell(c, r) != "#" or used.has(Vector2i(c, r)):
				c += 1
				continue
			var w := 0
			while c + w < cols and cell(c + w, r) == "#" and not used.has(Vector2i(c + w, r)):
				w += 1
			var h := 1
			while r + h < rows:
				var ok := true
				for i in w:
					if cell(c + i, r + h) != "#" or used.has(Vector2i(c + i, r + h)):
						ok = false
						break
				if not ok:
					break
				h += 1
			for y in h:
				for x in w:
					used[Vector2i(c + x, r + y)] = true
			solid_rects.append(Rect2i(c, r, w, h))
			c += w


func _runs_of(ch: String) -> Array[Rect2i]:
	var out: Array[Rect2i] = []
	for r in rows:
		var c := 0
		while c < cols:
			if cell(c, r) == ch:
				var w := 0
				while cell(c + w, r) == ch:
					w += 1
				out.append(Rect2i(c, r, w, 1))
				c += w
			else:
				c += 1
	return out


func _build_runs() -> void:
	plank_runs = _runs_of("=")
	thorn_up = _runs_of("^")
	thorn_down = _runs_of("v")


func spirit_runs() -> Array[Rect2i]:
	return _runs_of("%")


func _build_collision() -> void:
	var body := StaticBody2D.new()
	body.name = "Solids"
	body.collision_layer = 1
	body.collision_mask = 0
	add_child(body)
	for rect in solid_rects:
		var shape := CollisionShape2D.new()
		var box := RectangleShape2D.new()
		box.size = Vector2(rect.size) * TILE
		shape.shape = box
		shape.position = (Vector2(rect.position) + Vector2(rect.size) * 0.5) * TILE
		body.add_child(shape)
	# World bounds: side walls and a ceiling above the map.
	var h := rows * TILE
	for side in [-1, 1]:
		var wall := CollisionShape2D.new()
		var wall_box := RectangleShape2D.new()
		wall_box.size = Vector2(64, h + 2000)
		wall.shape = wall_box
		wall.position = Vector2(-32 if side < 0 else cols * TILE + 32, h * 0.5 - 1000)
		body.add_child(wall)
	var ceiling := CollisionShape2D.new()
	var ceil_box := RectangleShape2D.new()
	ceil_box.size = Vector2(cols * TILE + 128, 64)
	ceiling.shape = ceil_box
	ceiling.position = Vector2(cols * TILE * 0.5, -32 - 96)
	body.add_child(ceiling)
	var planks := StaticBody2D.new()
	planks.name = "Planks"
	planks.collision_layer = 16   # one-way layer (drop-through)
	planks.collision_mask = 0
	add_child(planks)
	for run in plank_runs:
		var shape := CollisionShape2D.new()
		var box := RectangleShape2D.new()
		box.size = Vector2(run.size.x * TILE, 10)
		shape.shape = box
		shape.one_way_collision = true
		shape.one_way_collision_margin = 6.0
		shape.position = Vector2((run.position.x + run.size.x * 0.5) * TILE, run.position.y * TILE + 5)
		planks.add_child(shape)
	var hazards := Area2D.new()
	hazards.name = "Thorns"
	hazards.collision_layer = 8
	hazards.collision_mask = 2
	hazards.monitorable = false
	add_child(hazards)
	for run in thorn_up:
		_hazard_shape(hazards, Rect2(run.position.x * TILE + 5, run.position.y * TILE + 16, run.size.x * TILE - 10, 16))
	for run in thorn_down:
		_hazard_shape(hazards, Rect2(run.position.x * TILE + 5, run.position.y * TILE, run.size.x * TILE - 10, 16))
	hazards.body_entered.connect(func(b: Node) -> void: hazard_touched.emit(b))


func _hazard_shape(area: Area2D, rect: Rect2) -> void:
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = rect.size
	shape.shape = box
	shape.position = rect.get_center()
	area.add_child(shape)


func _draw() -> void:
	var t := TILE
	# Body fill (tiled at native texel size) with gentle depth tint.
	for rect in solid_rects:
		var r := Rect2(Vector2(rect.position) * t, Vector2(rect.size) * t)
		draw_texture_rect(fill_tex, r, true, fill_tint)
	# Exposed faces: soft dark rim on sides and undersides.
	var rim := Color(0.02, 0.02, 0.05, 0.55)
	for r in rows:
		for c in cols:
			if cell(c, r) != "#":
				continue
			var p := Vector2(c * t, r * t)
			if not is_solid(c, r + 1) and r + 1 < rows:
				draw_rect(Rect2(p + Vector2(0, t - 6), Vector2(t, 6)), rim)
			if not is_solid(c - 1, r):
				draw_rect(Rect2(p, Vector2(4, t)), rim)
			if not is_solid(c + 1, r):
				draw_rect(Rect2(p + Vector2(t - 4, 0), Vector2(4, t)), rim)
	# Top edges: grass / moss / brass trim, continuous along runs.
	var edge_h := float(edge_tex.get_height())
	var dest_h := 30.0 if edge_h > 45 else 22.0
	var src_w := t * edge_h / dest_h
	var tex_w := float(edge_tex.get_width())
	for r in rows:
		for c in cols:
			if cell(c, r) != "#" or is_solid(c, r - 1) or r == 0 and false:
				continue
			if r > 0 and cell(c, r - 1) == "#":
				continue
			var p := Vector2(c * t, r * t)
			draw_rect(Rect2(p + Vector2(0, 8), Vector2(t, 10)), Color(0, 0, 0, 0.22))
			var sx := fmod(c * src_w, tex_w - src_w)
			var left_cap := not is_solid(c - 1, r) or cell(c - 1, r - 1) == "#"
			var right_cap := not is_solid(c + 1, r) or cell(c + 1, r - 1) == "#"
			var extra_l := 4.0 if left_cap else 0.0
			var extra_r := 4.0 if right_cap else 0.0
			draw_texture_rect_region(edge_tex,
				Rect2(p.x - extra_l, p.y - dest_h * 0.42, t + extra_l + extra_r, dest_h),
				Rect2(sx, 0, src_w, edge_h))
	# One-way planks, drawn in chunks of up to four tiles.
	var ph := float(plank_tex.get_height())
	var plank_h := 16.0 if ph < 40 else 20.0
	for run in plank_runs:
		var x := run.position.x * t
		var remaining := run.size.x
		while remaining > 0:
			var n := mini(remaining, 4)
			draw_texture_rect(plank_tex, Rect2(x - 2, run.position.y * t - 2, n * t + 4, plank_h), false)
			x += n * t
			remaining -= n
	# Thorns.
	var th := float(thorn_tex.get_height())
	var tw := float(thorn_tex.get_width())
	var th_src := tw / 4.0
	for run in thorn_up:
		for i in run.size.x:
			var sx := fmod((run.position.x + i) * th_src, tw - th_src)
			draw_texture_rect_region(thorn_tex, Rect2((run.position.x + i) * t - 2, run.position.y * t + 6, t + 4, 26), Rect2(sx, 0, th_src, th))
	for run in thorn_down:
		for i in run.size.x:
			var sx := fmod((run.position.x + i) * th_src, tw - th_src)
			draw_set_transform(Vector2((run.position.x + i) * t - 2, run.position.y * t + 26), 0.0, Vector2(1, -1))
			draw_texture_rect_region(thorn_tex, Rect2(0, 0, t + 4, 26), Rect2(sx, 0, th_src, th))
		draw_set_transform(Vector2.ZERO)
