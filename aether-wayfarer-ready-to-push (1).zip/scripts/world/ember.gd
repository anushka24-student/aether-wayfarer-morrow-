class_name Ember
extends Area2D
## Hidden collectible (3 per level). `index` is its bit in the save mask.

signal collected(ember: Ember)

var index := 0
var taken := false
var seen_before := false
var sprite: Sprite2D
var light: LightSource
var _t := randf() * 6.0
var _home := Vector2.ZERO


func setup(pos: Vector2, idx: int, already: bool) -> void:
	position = pos
	_home = pos
	index = idx
	seen_before = already


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitorable = false
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 16
	shape.shape = circle
	add_child(shape)
	sprite = Sprite2D.new()
	sprite.texture = preload("res://assets/art/props/ember.png")
	sprite.scale = Vector2(0.55, 0.55)
	add_child(sprite)
	if seen_before:
		sprite.modulate = Color(1, 1, 1, 0.5)
	light = LightSource.new()
	light.radius = 70
	light.strength = 0.8
	light.halo_color = Color(1.0, 0.55, 0.2, 0.45)
	add_child(light)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	_t += delta
	if taken:
		return
	position = _home + Vector2(0, sin(_t * 2.4) * 4.0)
	sprite.rotation = sin(_t * 1.7) * 0.12
	var s := 0.55 + sin(_t * 5.0) * 0.03
	sprite.scale = Vector2(s, s)


func _on_body(body: Node) -> void:
	if taken or not body is Player or not (body as Player).alive:
		return
	taken = true
	GameAudio.play(&"collect")
	var fx := Fx.find(self)
	if fx:
		fx.burst(global_position, Color(1.0, 0.7, 0.25, 1.0), 26, 220.0, 0.7, 120.0, 1.0)
		fx.hitstop(0.03)
	light.enabled = false
	var tw := create_tween().set_parallel()
	tw.tween_property(sprite, "scale", Vector2(1.2, 1.2), 0.25).set_trans(Tween.TRANS_BACK)
	tw.tween_property(sprite, "modulate:a", 0.0, 0.3).set_delay(0.1)
	tw.tween_property(self, "position:y", position.y - 30, 0.35)
	collected.emit(self)
