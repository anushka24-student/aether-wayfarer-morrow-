class_name Waylamp
extends Area2D
## Checkpoint. Touch to light it; deaths respawn at the most recent one.

signal activated(lamp: Waylamp)

const UNLIT := preload("res://assets/art/props/waylamp_unlit.png")
const LIT := preload("res://assets/art/props/waylamp_lit.png")

var lit := false
var order := 0
var sprite: Sprite2D
var light: LightSource


func setup(pos: Vector2, idx: int) -> void:
	position = pos
	order = idx


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitorable = false
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(40, 80)
	shape.shape = box
	shape.position = Vector2(0, -40)
	add_child(shape)
	sprite = Sprite2D.new()
	sprite.texture = UNLIT
	sprite.scale = Vector2(0.52, 0.52)
	sprite.offset = Vector2(0, -75)
	add_child(sprite)
	light = LightSource.new()
	light.position = Vector2(0, -62)
	light.radius = 56
	light.strength = 0.45
	light.halo_color = Color(0.7, 0.8, 1.0, 0.15)
	add_child(light)
	body_entered.connect(_on_body)


func respawn_point() -> Vector2:
	return global_position + Vector2(0, -2)


func set_lit(value: bool, animate := true) -> void:
	if lit == value:
		return
	lit = value
	sprite.texture = LIT if lit else UNLIT
	light.radius = 135.0 if lit else 56.0
	light.strength = 1.0 if lit else 0.45
	light.halo_color = Color(1.0, 0.72, 0.35, 0.45) if lit else Color(0.7, 0.8, 1.0, 0.15)
	if lit and animate:
		sprite.scale = Vector2(0.62, 0.44)
		create_tween().tween_property(sprite, "scale", Vector2(0.52, 0.52), 0.35).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
		var fx := Fx.find(self)
		if fx:
			fx.burst(global_position + Vector2(0, -62), Color(1.0, 0.75, 0.35, 1.0), 24, 180.0, 0.8, -40.0, 1.0)
		GameAudio.play(&"checkpoint")


func _on_body(body: Node) -> void:
	if lit or not body is Player or not (body as Player).alive:
		return
	set_lit(true)
	activated.emit(self)
