class_name SpiritPlatform
extends Node2D
## A one-way platform that only exists while light touches it. Sampled along
## its length against LightField; stays solid for `spirit_linger` seconds.

const TILE := 32
const TEX := preload("res://assets/art/props/platform_spirit.png")

var run := Rect2i()
var revealed := false
var reveal := 0.0          # 0..1 visual blend
var _linger := 0.0
var _shape: CollisionShape2D
var _field: LightField
var _t := randf() * 5.0
var _samples: Array[Vector2] = []


func setup(r: Rect2i) -> void:
	run = r
	position = Vector2(r.position) * TILE
	var body := StaticBody2D.new()
	body.collision_layer = 16   # one-way layer (drop-through)
	body.collision_mask = 0
	add_child(body)
	_shape = CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(r.size.x * TILE, 10)
	_shape.shape = box
	_shape.one_way_collision = true
	_shape.one_way_collision_margin = 6.0
	_shape.position = Vector2(r.size.x * TILE * 0.5, 5)
	_shape.disabled = true
	body.add_child(_shape)
	for i in r.size.x:
		_samples.append(Vector2(i * TILE + 16, 4))


func _ready() -> void:
	z_index = 2


func _physics_process(delta: float) -> void:
	_t += delta
	if _field == null:
		_field = get_tree().get_first_node_in_group("light_field") as LightField
		if _field == null:
			return
	var lit := 0.0
	for s in _samples:
		lit = maxf(lit, _field.light_at(global_position + s))
	var threshold := Tune.v("reveal_threshold")
	if lit >= threshold:
		_linger = Tune.v("spirit_linger")
		if not revealed:
			revealed = true
			_shape.set_deferred("disabled", false)
			GameAudio.play(&"spirit")
			var fx := Fx.find(self)
			if fx:
				fx.burst(global_position + Vector2(run.size.x * TILE * 0.5, 4), Color(0.55, 0.95, 1.0, 0.9), 10, 70.0, 0.6, -30.0, 0.8, true, 180.0)
	else:
		_linger -= delta
		if revealed and _linger <= 0.0:
			revealed = false
			_shape.set_deferred("disabled", true)
	reveal = move_toward(reveal, 1.0 if revealed else 0.0, delta * (7.0 if revealed else 2.5))
	queue_redraw()


func _draw() -> void:
	var w := run.size.x * TILE
	if reveal <= 0.01:
		# A barely-there shimmer so curious players can spot where stones hide.
		var a := 0.05 + 0.04 * sin(_t * 2.0)
		for i in run.size.x:
			draw_circle(Vector2(i * TILE + 16, 2 + sin(_t * 1.6 + i) * 3.0), 2.0, Color(0.6, 0.95, 1.0, a))
		return
	var fading := _linger < 0.35 and revealed
	var blink := 0.55 + 0.45 * sin(_t * 30.0) if fading else 1.0
	var col := Color(1, 1, 1, reveal * blink)
	var x := 0.0
	var remaining := run.size.x
	while remaining > 0:
		var n := mini(remaining, 3)
		draw_texture_rect(TEX, Rect2(x - 4, -6, n * TILE + 8, 22), false, col)
		x += n * TILE
		remaining -= n
	draw_rect(Rect2(0, -2, w, 3), Color(0.6, 1.0, 1.0, 0.35 * reveal * blink))
