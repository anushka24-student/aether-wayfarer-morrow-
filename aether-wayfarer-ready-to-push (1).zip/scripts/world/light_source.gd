class_name LightSource
extends Node2D
## A point light the murk mask respects. Optional additive halo sprite.

static var _glow_texture: Texture2D

@export var radius := 120.0
@export var strength := 1.0
@export var enabled := true
@export var halo_color := Color(0.42, 0.88, 1.0, 0.32)
@export var flicker := 0.03
var boost_radius := 0.0     # extra radius (lantern flare), animated by owner
var halo: Sprite2D
var _field: LightField
var _t := randf() * 10.0


static func glow_texture() -> Texture2D:
	if _glow_texture == null:
		var gradient := Gradient.new()
		gradient.set_color(0, Color(1, 1, 1, 1))
		gradient.set_color(1, Color(1, 1, 1, 0))
		gradient.add_point(0.35, Color(1, 1, 1, 0.45))
		var tex := GradientTexture2D.new()
		tex.gradient = gradient
		tex.fill = GradientTexture2D.FILL_RADIAL
		tex.fill_from = Vector2(0.5, 0.5)
		tex.fill_to = Vector2(1.0, 0.5)
		tex.width = 128
		tex.height = 128
		_glow_texture = tex
	return _glow_texture


func _ready() -> void:
	halo = Sprite2D.new()
	halo.texture = glow_texture()
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	halo.material = mat
	halo.modulate = halo_color
	halo.z_index = 30
	add_child(halo)
	_update_halo()
	call_deferred("_attach")


func _attach() -> void:
	_field = get_tree().get_first_node_in_group("light_field") as LightField
	if _field:
		_field.register(self)


func _exit_tree() -> void:
	if _field:
		_field.unregister(self)


func is_active() -> bool:
	return enabled and is_visible_in_tree() and strength > 0.01


func base_radius() -> float:
	return radius


func current_radius() -> float:
	return (radius + boost_radius) * (1.0 + sin(_t * 7.3) * flicker + sin(_t * 2.1) * flicker * 0.6)


func _process(delta: float) -> void:
	_t += delta
	_update_halo()


func _update_halo() -> void:
	if halo == null:
		return
	halo.visible = is_active()
	var s := current_radius() * 1.1 / 64.0
	halo.scale = Vector2(s, s)
	halo.modulate = Color(halo_color.r, halo_color.g, halo_color.b, halo_color.a * strength)
