class_name Backdrop
extends CanvasLayer
## Screen-space parallax: sky colour, far painting and mid silhouettes.
## Scroll factors come from data/themes.json.

var far_tex: Texture2D
var mid_tex: Texture2D
var sky := Color("#141a2e")
var accent := Color("#8e86ff")
var far_scroll := 0.12
var mid_scroll := 0.35
var vertical := false
var level_size := Vector2(1280, 720)
var _canvas: Node2D
var _t := 0.0


func setup(theme: Dictionary, size_px: Vector2) -> void:
	layer = -10
	far_tex = load(theme.far) if str(theme.get("far", "")) != "" else null
	mid_tex = load(theme.mid) if str(theme.get("mid", "")) != "" else null
	sky = Color(theme.get("sky", "#141a2e"))
	accent = Color(theme.get("accent", "#8e86ff"))
	far_scroll = float(theme.get("far_scroll", 0.12))
	mid_scroll = float(theme.get("mid_scroll", 0.35))
	vertical = bool(theme.get("vertical", false))
	level_size = size_px
	_canvas = Node2D.new()
	_canvas.draw.connect(_draw_layers)
	add_child(_canvas)


func _process(delta: float) -> void:
	if _canvas:
		_t += delta
		_canvas.queue_redraw()


func _draw_layers() -> void:
	var vp := _canvas.get_viewport()
	var size := vp.get_visible_rect().size
	var cam := vp.get_camera_2d()
	var cam_pos := cam.get_screen_center_position() if cam else size * 0.5
	_canvas.draw_rect(Rect2(Vector2.ZERO, size), sky)
	if far_tex:
		var ts := Vector2(far_tex.get_size())
		if vertical:
			var s := size.x / ts.x * 1.08
			var h := ts.y * s
			var progress := clampf(cam_pos.y / maxf(level_size.y, 1.0), 0.0, 1.0)
			var y := -(h - size.y) * progress
			_canvas.draw_texture_rect(far_tex, Rect2(Vector2(-(ts.x * s - size.x) * 0.5, y), Vector2(ts.x * s, h)), false)
		else:
			var s := size.y / ts.y * 1.12
			var w := ts.x * s
			var x := -fmod(cam_pos.x * far_scroll, w)
			var y := -(ts.y * s - size.y) * 0.5 - (cam_pos.y - level_size.y * 0.5) * far_scroll * 0.3
			while x < size.x:
				_canvas.draw_texture_rect(far_tex, Rect2(Vector2(x, y), Vector2(w, ts.y * s)), false)
				x += w - 1.0
	if mid_tex:
		var ms := Vector2(mid_tex.get_size())
		if vertical:
			var s2 := size.x / ms.x
			var h2 := ms.y * s2
			var y2 := fmod(-cam_pos.y * mid_scroll, h2)
			if y2 > 0.0:
				y2 -= h2
			while y2 < size.y:
				_canvas.draw_texture_rect(mid_tex, Rect2(Vector2(0, y2), Vector2(size.x, h2)), false, Color(1, 1, 1, 0.85))
				y2 += h2 - 1.0
		else:
			var s2 := size.y / ms.y * 0.95
			var w2 := ms.x * s2
			var x2 := -fmod(cam_pos.x * mid_scroll, w2)
			var y2 := size.y - ms.y * s2 - (cam_pos.y - level_size.y * 0.6) * mid_scroll * 0.4 + 40.0
			while x2 < size.x:
				_canvas.draw_texture_rect(mid_tex, Rect2(Vector2(x2, y2), Vector2(w2, ms.y * s2)), false)
				x2 += w2 - 1.0
	_draw_astral_glyphs(size, cam_pos)


func _draw_astral_glyphs(size: Vector2, cam_pos: Vector2) -> void:
	# Presentation-only decoration: it lives below the world and never affects
	# collision, lantern reveal logic, or camera bounds.
	var pulse := 0.55 + sin(_t * 0.7) * 0.12
	var c := Color(accent.r, accent.g, accent.b, 0.11 * pulse)
	var cyan := Color(0.35, 0.92, 1.0, 0.08 * pulse)
	var anchors := [
		Vector2(size.x * 0.18, size.y * 0.24),
		Vector2(size.x * 0.82, size.y * 0.30),
		Vector2(size.x * 0.67, size.y * 0.76),
	]
	for i in anchors.size():
		var p: Vector2 = anchors[i] + Vector2(sin(_t * 0.17 + i) * 10.0, cos(_t * 0.13 + i * 1.7) * 7.0)
		var r := 42.0 + i * 10.0
		_canvas.draw_arc(p, r, -PI * 0.85, PI * 0.55, 28, c, 1.2)
		_canvas.draw_arc(p, r * 0.62, PI * 0.18, PI * 1.36, 20, cyan, 1.0)
		_canvas.draw_circle(p, 2.5, Color(0.72, 0.96, 1.0, 0.22 * pulse))
		_canvas.draw_line(p + Vector2(-r * 0.22, 0), p + Vector2(r * 0.22, 0), c, 1.0)
		_canvas.draw_line(p + Vector2(0, -r * 0.22), p + Vector2(0, r * 0.22), cyan, 1.0)
	var horizon := size.y * (0.68 if not vertical else 0.54)
	for j in range(5):
		var x := fmod(float(j * 280) - cam_pos.x * 0.035, size.x + 180.0) - 90.0
		_canvas.draw_line(Vector2(x, horizon), Vector2(x + 72.0, horizon - 18.0), Color(cyan, 0.45), 1.0)
