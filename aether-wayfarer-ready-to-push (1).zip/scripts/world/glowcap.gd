class_name Glowcap
extends Node2D
## Small static light ("l" in maps): a glowing mushroom cluster. Helps
## pacing in dark stretches and shows spirit stones nearby.

var tint := Color(0.7, 1.0, 0.8)
var light: LightSource
var _t := randf() * 6.0


func _ready() -> void:
	z_index = 1
	light = LightSource.new()
	light.position = Vector2(0, -14)
	light.radius = 92
	light.strength = 0.75
	light.flicker = 0.02
	light.halo_color = Color(tint.r, tint.g, tint.b, 0.3)
	add_child(light)


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	var glow := 0.75 + 0.25 * sin(_t * 1.8)
	var stem := Color(0.93, 0.88, 0.76)
	var caps := [[Vector2(-7, -10), 9.0], [Vector2(6, -16), 11.0], [Vector2(13, -7), 6.0]]
	for cap: Array in caps:
		var p: Vector2 = cap[0]
		var r: float = cap[1]
		draw_line(Vector2(p.x, 0), p, stem, 3.0)
		draw_circle(p, r * 1.6, Color(tint.r, tint.g, tint.b, 0.12 * glow))
		var pts := PackedVector2Array()
		for i in 13:
			var a := PI + PI * float(i) / 12.0
			pts.append(p + Vector2(cos(a) * r, sin(a) * r * 0.7))
		draw_colored_polygon(pts, Color(tint.r * 0.8, tint.g * 0.9, tint.b, 1.0))
		draw_circle(p + Vector2(-r * 0.3, -r * 0.3), r * 0.18, Color(1, 1, 1, 0.8 * glow))


static func ambient_motes(color: Color) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = 46 if Tune.quality_high() else 18
	p.lifetime = 7.0
	p.preprocess = 7.0
	p.local_coords = false
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(760, 440)
	p.direction = Vector2(0.3, -1)
	p.spread = 60.0
	p.gravity = Vector2(0, -4)
	p.initial_velocity_min = 6.0
	p.initial_velocity_max = 20.0
	p.texture = Fx.dot()
	p.scale_amount_min = 0.12
	p.scale_amount_max = 0.32
	var ramp := Gradient.new()
	ramp.offsets = PackedFloat32Array([0.0, 0.3, 1.0])
	ramp.colors = PackedColorArray([Color(color.r, color.g, color.b, 0.0), Color(color.r, color.g, color.b, 0.8), Color(color.r, color.g, color.b, 0.0)])
	p.color_ramp = ramp
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	p.material = mat
	p.z_index = 35
	return p
