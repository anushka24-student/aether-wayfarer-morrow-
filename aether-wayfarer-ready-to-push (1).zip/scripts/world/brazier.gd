class_name Brazier
extends Area2D
## Boss-arena brazier. Dormant -> ready (pulsing, marked) -> lit.
## Lighting a ready brazier stuns the boss.

signal lit_up(brazier: Brazier)

const UNLIT := preload("res://assets/art/props/brazier_unlit.png")
const LIT := preload("res://assets/art/props/brazier_lit.png")

var index := 0
var ready_to_light := false
var lit := false
var sprite: Sprite2D
var light: LightSource
var _t := 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitorable = false
	z_index = 3
	var shape := CollisionShape2D.new()
	var box := RectangleShape2D.new()
	box.size = Vector2(56, 64)
	shape.shape = box
	shape.position = Vector2(0, -32)
	add_child(shape)
	sprite = Sprite2D.new()
	sprite.centered = false
	add_child(sprite)
	light = LightSource.new()
	light.position = Vector2(0, -60)
	add_child(light)
	body_entered.connect(_on_body)
	_apply()


func _apply() -> void:
	var tex: Texture2D = LIT if lit else UNLIT
	sprite.texture = tex
	var s := 0.42
	sprite.scale = Vector2(s, s)
	sprite.position = Vector2(-tex.get_width() * s * 0.5, -tex.get_height() * s + 4)
	light.radius = 250.0 if lit else (80.0 if ready_to_light else 40.0)
	light.strength = 1.0 if lit else (0.8 if ready_to_light else 0.3)
	light.halo_color = Color(1.0, 0.6, 0.25, 0.55) if lit else Color(1.0, 0.45, 0.2, 0.3 if ready_to_light else 0.1)


func set_ready(value: bool) -> void:
	ready_to_light = value
	if value:
		lit = false
	_apply()
	queue_redraw()


func extinguish() -> void:
	lit = false
	ready_to_light = false
	_apply()
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	if ready_to_light:
		light.strength = 0.65 + sin(_t * 5.0) * 0.25
		queue_redraw()


func _draw() -> void:
	if not ready_to_light:
		return
	# Bobbing chevron marker so the objective reads through the murk.
	var y := -110.0 + sin(_t * 4.0) * 6.0
	var c := Color(1.0, 0.78, 0.35, 0.9)
	draw_colored_polygon(PackedVector2Array([Vector2(-12, y - 14), Vector2(12, y - 14), Vector2(0, y)]), c)
	draw_colored_polygon(PackedVector2Array([Vector2(-8, y - 30), Vector2(8, y - 30), Vector2(0, y - 20)]), Color(c, 0.55))


func _on_body(body: Node) -> void:
	if not ready_to_light or lit or not body is Player or not (body as Player).alive:
		return
	lit = true
	ready_to_light = false
	_apply()
	queue_redraw()
	var fx := Fx.find(self)
	if fx:
		fx.burst(global_position + Vector2(0, -60), Color(1.0, 0.7, 0.3, 1.0), 34, 280.0, 0.9, -60.0, 1.4)
		fx.shake(7.0, 0.3)
		fx.flash(Color(1.0, 0.8, 0.5), 0.3, 0.4)
	GameAudio.play(&"beacon")
	lit_up.emit(self)
