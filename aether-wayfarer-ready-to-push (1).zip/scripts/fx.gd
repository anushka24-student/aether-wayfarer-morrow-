class_name Fx
extends Node2D
## World-space feedback: particle bursts, dust, afterimages, screen shake,
## hit-stop and flashes. One instance lives in the level (group "fx").

static var _dot: Texture2D
var camera: GameCamera
var flash_rect: ColorRect
var _hitstop_token := 0


static func dot() -> Texture2D:
	if _dot == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var tex := GradientTexture2D.new()
		tex.gradient = g
		tex.fill = GradientTexture2D.FILL_RADIAL
		tex.fill_from = Vector2(0.5, 0.5)
		tex.fill_to = Vector2(1.0, 0.5)
		tex.width = 24
		tex.height = 24
		_dot = tex
	return _dot


static func find(node: Node) -> Fx:
	return node.get_tree().get_first_node_in_group("fx") as Fx


func _ready() -> void:
	add_to_group("fx")
	z_index = 40


## Generic one-shot burst.
func burst(pos: Vector2, color: Color, amount: int = 14, speed: float = 120.0, life: float = 0.6,
		gravity: float = 0.0, size: float = 1.0, additive := true, spread := 180.0, dir := Vector2.UP) -> void:
	var n := amount if Tune.quality_high() else maxi(3, amount / 2)
	var p := CPUParticles2D.new()
	p.one_shot = true
	p.emitting = false
	p.amount = n
	p.lifetime = life
	p.explosiveness = 0.95
	p.texture = dot()
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector2(0, gravity)
	p.damping_min = speed * 0.6
	p.damping_max = speed * 1.2
	p.scale_amount_min = 0.25 * size
	p.scale_amount_max = 0.6 * size
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	p.scale_amount_curve = curve
	var ramp := Gradient.new()
	ramp.set_color(0, color)
	ramp.set_color(1, Color(color.r, color.g, color.b, 0.0))
	p.color_ramp = ramp
	if additive:
		var mat := CanvasItemMaterial.new()
		mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		p.material = mat
	p.position = pos
	add_child(p)
	p.emitting = true
	get_tree().create_timer(life + 0.2, false).timeout.connect(p.queue_free)


func dust(pos: Vector2, strength := 1.0, dir := Vector2.UP) -> void:
	burst(pos, Color(0.85, 0.8, 0.7, 0.55), int(8 * strength), 70.0 * strength, 0.45, 60.0, 1.3, false, 70.0, dir)


func sparks(pos: Vector2, color := Color(1.0, 0.75, 0.35), amount := 16) -> void:
	burst(pos, color, amount, 220.0, 0.55, 240.0, 0.8, true, 180.0)


func afterimage(sprite: AnimatedSprite2D, tint := Color(1.0, 0.72, 0.4, 0.55)) -> void:
	if sprite.sprite_frames == null:
		return
	var ghost := Sprite2D.new()
	ghost.texture = sprite.sprite_frames.get_frame_texture(sprite.animation, sprite.frame)
	ghost.global_transform = sprite.global_transform
	ghost.offset = sprite.offset
	ghost.flip_h = sprite.flip_h
	ghost.modulate = tint
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	ghost.material = mat
	add_child(ghost)
	ghost.global_position = sprite.global_position
	var tw := ghost.create_tween()
	tw.tween_property(ghost, "modulate:a", 0.0, 0.28)
	tw.tween_callback(ghost.queue_free)


func shake(strength: float, duration := 0.25) -> void:
	if camera and Tune.motion_ok():
		camera.add_shake(strength * Tune.v("shake_strength"), duration)


## Brief freeze-frame for impact. Uses real time so it always ends.
func hitstop(duration: float) -> void:
	var d := duration * Tune.v("hitstop_scale")
	if d <= 0.005:
		return
	_hitstop_token += 1
	var token := _hitstop_token
	Engine.time_scale = 0.05
	await get_tree().create_timer(d, true, false, true).timeout
	if token == _hitstop_token:
		Engine.time_scale = 1.0


func flash(color := Color(1, 1, 1), alpha := 0.35, duration := 0.18) -> void:
	if flash_rect == null or not Tune.motion_ok():
		return
	flash_rect.color = Color(color.r, color.g, color.b, alpha)
	var tw := flash_rect.create_tween()
	tw.tween_property(flash_rect, "color:a", 0.0, duration)


func _exit_tree() -> void:
	Engine.time_scale = 1.0
