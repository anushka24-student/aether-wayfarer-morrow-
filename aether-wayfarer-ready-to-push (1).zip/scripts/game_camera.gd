class_name GameCamera
extends Camera2D
## Smooth follow with look-ahead, level limits and trauma-style shake.

var target: Node2D
var bounds := Rect2()
var base_zoom := 1.0
var look_ahead := 0.0
var _shake := 0.0
var _shake_time := 0.0
var _shake_total := 0.0
var _noise_t := 0.0
var _pos := Vector2.ZERO


func _ready() -> void:
	position_smoothing_enabled = false
	process_callback = Camera2D.CAMERA2D_PROCESS_PHYSICS


func snap_to_target() -> void:
	if target:
		_pos = _desired()
		global_position = _clamped(_pos)
		reset_physics_interpolation()


func add_shake(strength: float, duration: float) -> void:
	_shake = maxf(_shake, strength)
	_shake_time = maxf(_shake_time, duration)
	_shake_total = maxf(_shake_time, 0.01)


func _desired() -> Vector2:
	var p := target.global_position + Vector2(0, -40)
	if target is Player:
		var pl := target as Player
		look_ahead = lerpf(look_ahead, pl.facing * 70.0 + clampf(pl.velocity.x * 0.12, -40, 40), 0.04)
		p.x += look_ahead
		if pl.velocity.y > 300:
			p.y += 60.0
	return p


func _clamped(p: Vector2) -> Vector2:
	var view := get_viewport_rect().size / zoom
	var half := view * 0.5
	var out := p
	if bounds.size.x <= view.x:
		out.x = bounds.get_center().x
	else:
		out.x = clampf(p.x, bounds.position.x + half.x, bounds.end.x - half.x)
	if bounds.size.y <= view.y:
		out.y = bounds.end.y - half.y
	else:
		out.y = clampf(p.y, bounds.position.y + half.y, bounds.end.y - half.y)
	return out


func _physics_process(delta: float) -> void:
	var z := base_zoom * Tune.v("camera_zoom_scale") * ViewportPolicy.world_scale()
	zoom = Vector2(z, z)
	if target:
		var k := 1.0 - exp(-Tune.v("camera_smoothing") * delta)
		_pos = _pos.lerp(_desired(), k)
		global_position = _clamped(_pos)
	_noise_t += delta * 40.0
	if _shake_time > 0.0:
		_shake_time -= delta
		var amt := _shake * clampf(_shake_time / _shake_total, 0.0, 1.0)
		offset = Vector2(sin(_noise_t * 1.7) + sin(_noise_t * 3.1) * 0.5, cos(_noise_t * 1.3) + sin(_noise_t * 2.7) * 0.5) * amt
	else:
		offset = Vector2.ZERO
