extends Node
## Account-backed profile, progress and game-record sync. Local SaveStore remains
## usable when the browser bridge is unavailable or the player is logged out.
signal sync_state_changed(status: String)
signal session_changed(state: Dictionary)

var status := "offline" # offline | syncing | pending | synced | error
var session: Dictionary = {}
var profile: Dictionary = {}
var records: Array = []

var _upload_timer: Timer
var _syncing := false
var _suppress_upload := false
var _queue_busy := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_upload_timer = Timer.new()
	_upload_timer.one_shot = true
	_upload_timer.wait_time = 0.8
	_upload_timer.timeout.connect(_flush_progress)
	add_child(_upload_timer)
	ManusAuth.auth_state_changed.connect(_on_auth_state)
	ManusAuth.auth_error.connect(_on_auth_error)
	SaveStore.changed.connect(_on_local_changed)
	call_deferred("_on_auth_state", ManusAuth.get_session())


func is_authenticated() -> bool:
	return str(session.get("status", "")) == "authenticated" and session.get("user") is Dictionary


func display_name() -> String:
	var value := str(profile.get("displayName", ""))
	if not value.is_empty():
		return value
	return str(session.get("user", {}).get("name", ""))


func sync_label() -> String:
	return status


func _on_auth_state(state: Dictionary) -> void:
	session = state.duplicate(true)
	session_changed.emit(session)
	if is_authenticated():
		_sync_account()
	else:
		profile = {}
		records = []
		_set_status("offline")


func _on_auth_error(_code: String) -> void:
	if not is_authenticated():
		_set_status("offline")


func _sync_account() -> void:
	if _syncing:
		return
	_syncing = true
	_set_status("syncing")
	ManusAuth.query("profile.get", {}, func(result: Variant, error: String) -> void:
		if not error.is_empty():
			_sync_failed(error)
			return
		var packet: Dictionary = result if result is Dictionary else {}
		profile = packet.get("profile", {}) if packet.get("profile", {}) is Dictionary else {}
		ManusAuth.query("progress.get", {}, func(progress_result: Variant, progress_error: String) -> void:
			if not progress_error.is_empty():
				_sync_failed(progress_error)
				return
			var remote: Dictionary = progress_result if progress_result is Dictionary else {}
			_suppress_upload = true
			SaveStore.merge_cloud(remote.get("data", {}) if remote.get("data", {}) is Dictionary else {})
			_suppress_upload = false
			ManusAuth.query("records.list", {"limit": 20}, func(record_result: Variant, record_error: String) -> void:
				if not record_error.is_empty():
					_sync_failed(record_error)
					return
				records = record_result if record_result is Array else []
				_syncing = false
				_set_status("synced")
				_update_profile()
				_schedule_upload()
				_flush_records()
			)
		)
	)


func _update_profile() -> void:
	if not is_authenticated():
		return
	var locale := "zh-CN" if I18n.get_locale().begins_with("zh") else "en"
	var name := str(session.get("user", {}).get("name", ""))
	ManusAuth.mutate("profile.update", {"displayName": name, "locale": locale}, func(result: Variant, error: String) -> void:
		if error.is_empty() and result is Dictionary:
			profile = result
	)


func _on_local_changed() -> void:
	if _suppress_upload or not is_authenticated():
		return
	_set_status("pending")
	_schedule_upload()


func _schedule_upload() -> void:
	if not is_authenticated() or _syncing:
		return
	_upload_timer.start()


func _flush_progress() -> void:
	if not is_authenticated() or _syncing:
		return
	ManusAuth.mutate("progress.upsert", {"schemaVersion": 1, "data": SaveStore.cloud_snapshot()}, func(_result: Variant, error: String) -> void:
		if error.is_empty():
			_set_status("synced")
			_flush_records()
		else:
			_set_status("error")
	)


func append_record(kind: String, level_id: String, outcome: String, duration_ms: int, deaths: int, embers: int, payload: Dictionary = {}) -> void:
	var record_id := "%s-%s-%s" % [kind, level_id, str(Time.get_ticks_msec())]
	var record := {
		"recordId": record_id,
		"kind": kind,
		"levelId": level_id,
		"outcome": outcome,
		"durationMs": maxi(duration_ms, 0),
		"deaths": maxi(deaths, 0),
		"embers": maxi(embers, 0),
		"payload": payload,
	}
	SaveStore.queue_cloud_record(record)
	if is_authenticated():
		_flush_records()


func _flush_records() -> void:
	if _queue_busy or not is_authenticated():
		return
	var next := SaveStore.peek_cloud_record()
	if next.is_empty():
		return
	_queue_busy = true
	ManusAuth.mutate("records.append", next, func(_result: Variant, error: String) -> void:
		_queue_busy = false
		if error.is_empty():
			SaveStore.remove_cloud_record(str(next.get("recordId", "")))
			records.push_front(next)
			if records.size() > 20:
				records.resize(20)
			_flush_records()
		else:
			_set_status("error")
	)


func _sync_failed(_error: String) -> void:
	_syncing = false
	_suppress_upload = false
	_set_status("error")


func _set_status(next: String) -> void:
	if status == next:
		return
	status = next
	sync_state_changed.emit(status)
