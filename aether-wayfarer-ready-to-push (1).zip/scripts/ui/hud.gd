class_name Hud
extends CanvasLayer
## In-level heads-up display. Pure presentation; Game pushes state into it.

const ICON_WATCH := preload("res://assets/art/ui/icon_watch.png")
const ICON_EMBER := preload("res://assets/art/props/ember.png")
const ICON_LANTERN := preload("res://assets/art/ui/icon_lantern.png")
const ICON_FLAME := preload("res://assets/art/ui/icon_flame.png")

var time_label: Label
var ember_icons: Array[TextureRect] = []
var oil_bar: Control
var oil := 1.0
var oil_locked := false
var boss_box: Control
var boss_name: Label
var boss_pips: Array[TextureRect] = []
var banner: Control
var banner_title: Label
var banner_sub: Label
var hint_box: PanelContainer
var hint_label: Label
var toast: Label
var pause_button: Button
var flash_rect: ColorRect
var _hint_t := 0.0
var _hint_bottom := 96.0
var _root: Control

signal pause_pressed


func _ready() -> void:
	layer = 10
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	flash_rect = ColorRect.new()
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	flash_rect.color = Color(1, 1, 1, 0)
	_root.add_child(flash_rect)
	_build_top_left()
	_build_boss()
	_build_banner()
	_build_hint()
	_build_pause()


func _plate() -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.06, 0.16, 0.78)
	sb.border_color = Color(0.42, 0.86, 1.0, 0.55)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.shadow_color = Color(0.02, 0.03, 0.12, 0.72)
	sb.shadow_size = 8
	sb.content_margin_left = 14
	sb.content_margin_right = 16
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p


func _build_top_left() -> void:
	var box := VBoxContainer.new()
	box.position = Vector2(18, 14)
	box.add_theme_constant_override("separation", 8)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(box)
	var plate := _plate()
	box.add_child(plate)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	plate.add_child(row)
	row.add_child(UiKit.icon(ICON_WATCH, 30))
	time_label = UiKit.label("0:00.0", 24)
	time_label.custom_minimum_size = Vector2(96, 0)
	row.add_child(time_label)
	var sep := Control.new()
	sep.custom_minimum_size = Vector2(8, 0)
	row.add_child(sep)
	for i in 3:
		var ic := UiKit.icon(ICON_EMBER, 30)
		ic.modulate = Color(0.25, 0.22, 0.3, 0.8)
		row.add_child(ic)
		ember_icons.append(ic)
	var oil_plate := _plate()
	box.add_child(oil_plate)
	var oil_row := HBoxContainer.new()
	oil_row.add_theme_constant_override("separation", 8)
	oil_plate.add_child(oil_row)
	oil_row.add_child(UiKit.icon(ICON_LANTERN, 28))
	oil_bar = Control.new()
	oil_bar.custom_minimum_size = Vector2(150, 28)
	oil_bar.draw.connect(_draw_oil)
	oil_row.add_child(oil_bar)


func _draw_oil() -> void:
	var r := Rect2(Vector2(0, 9), Vector2(oil_bar.size.x, 11))
	oil_bar.draw_rect(r, Color(0.1, 0.06, 0.1, 0.9))
	var fill := r
	fill.size.x *= oil
	var c := Color("#74efff") if not oil_locked else Color(0.58, 0.38, 0.86)
	oil_bar.draw_rect(fill, c)
	oil_bar.draw_rect(Rect2(fill.position, Vector2(fill.size.x, 3)), Color(0.85, 1.0, 1.0, 0.68))
	oil_bar.draw_rect(r, Color(0.55, 0.9, 1.0, 0.85), false, 1.5)
	var thresh := r.position.x + r.size.x * 0.35
	oil_bar.draw_line(Vector2(thresh, r.position.y - 2), Vector2(thresh, r.end.y + 2), Color(1, 0.9, 0.7, 0.35), 1.0)


func _build_boss() -> void:
	boss_box = HBoxContainer.new()
	_place(boss_box, Control.PRESET_CENTER_TOP, Rect2(-220, 6, 440, 46))
	(boss_box as HBoxContainer).alignment = BoxContainer.ALIGNMENT_CENTER
	boss_box.add_theme_constant_override("separation", 14)
	boss_box.visible = false
	boss_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(boss_box)
	boss_name = UiKit.title("", 26, Color("#e7c6ff"))
	boss_box.add_child(boss_name)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 6)
	boss_box.add_child(row)
	for i in 3:
		var pip := UiKit.icon(ICON_FLAME, 32)
		pip.modulate = Color(0.48, 0.9, 1.0)
		row.add_child(pip)
		boss_pips.append(pip)


func _build_banner() -> void:
	banner = VBoxContainer.new()
	_place(banner, Control.PRESET_CENTER, Rect2(-460, -200, 920, 130))
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner.modulate.a = 0.0
	_root.add_child(banner)
	banner_title = UiKit.title("", 64)
	banner.add_child(banner_title)
	banner_sub = UiKit.label("", 26, UiKit.DIM)
	banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner.add_child(banner_sub)
	toast = UiKit.title("", 44, Color("#ffe3a3"))
	_place(toast, Control.PRESET_CENTER, Rect2(-420, -60, 840, 70))
	toast.modulate.a = 0.0
	toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(toast)


func _build_hint() -> void:
	hint_box = _plate()
	_place(hint_box, Control.PRESET_CENTER_BOTTOM, Rect2(-200, -160, 400, 48))
	hint_box.modulate.a = 0.0
	_root.add_child(hint_box)
	hint_label = UiKit.label("", 24, UiKit.CREAM)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_box.add_child(hint_label)


func _build_pause() -> void:
	pause_button = Button.new()
	_place(pause_button, Control.PRESET_TOP_RIGHT, Rect2(-74, 14, 58, 58))
	pause_button.icon = preload("res://assets/art/ui/icon_gear.png")
	pause_button.expand_icon = true
	pause_button.focus_mode = Control.FOCUS_NONE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.06, 0.16, 0.72)
	sb.border_color = Color(0.48, 0.82, 1.0, 0.62)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(29)
	sb.set_content_margin_all(8)
	pause_button.add_theme_stylebox_override("normal", sb)
	pause_button.add_theme_stylebox_override("hover", sb)
	pause_button.add_theme_stylebox_override("pressed", sb)
	pause_button.pressed.connect(func() -> void: pause_pressed.emit())
	_root.add_child(pause_button)


func set_time(seconds: float) -> void:
	time_label.text = Session.format_time(seconds)


func set_embers(mask: int) -> void:
	for i in ember_icons.size():
		var got := (mask >> i) & 1 == 1
		var ic := ember_icons[i]
		var target := Color.WHITE if got else Color(0.25, 0.22, 0.3, 0.8)
		if got and ic.modulate != Color.WHITE:
			ic.pivot_offset = ic.size * 0.5
			var tw := ic.create_tween()
			tw.tween_property(ic, "scale", Vector2(1.6, 1.6), 0.12)
			tw.tween_property(ic, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)
		ic.modulate = target


func set_oil(value: float, locked: bool) -> void:
	if absf(value - oil) > 0.002 or locked != oil_locked:
		oil = value
		oil_locked = locked
		oil_bar.queue_redraw()


func show_boss(name_text: String, hp: int, max_hp: int) -> void:
	boss_box.visible = true
	boss_name.text = name_text
	set_boss_hp(hp, max_hp)


func set_boss_hp(hp: int, max_hp: int) -> void:
	for i in boss_pips.size():
			boss_pips[i].visible = i < max_hp
			var alive := i < hp
			var pip := boss_pips[i]
			if not alive and pip.modulate.a > 0.5:
				pip.pivot_offset = pip.size * 0.5
				var tw := pip.create_tween()
				tw.tween_property(pip, "scale", Vector2(1.8, 1.8), 0.1)
				tw.tween_property(pip, "scale", Vector2.ONE, 0.2)
			pip.modulate = Color(0.48, 0.9, 1.0) if alive else Color(0.3, 0.25, 0.45, 0.4)


func show_banner(title_text: String, sub: String) -> void:
	banner_title.text = title_text
	banner_sub.text = sub
	var tw := banner.create_tween()
	banner.modulate.a = 0.0
	tw.tween_property(banner, "modulate:a", 1.0, 0.5)
	tw.tween_interval(2.0)
	tw.tween_property(banner, "modulate:a", 0.0, 0.8)


func show_toast(text: String, hold := 1.2) -> void:
	toast.text = text
	toast.pivot_offset = toast.size * 0.5
	toast.scale = Vector2(0.8, 0.8)
	var tw := toast.create_tween()
	tw.tween_property(toast, "modulate:a", 1.0, 0.15)
	tw.parallel().tween_property(toast, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)
	tw.tween_interval(hold)
	tw.tween_property(toast, "modulate:a", 0.0, 0.4)


func show_hint(text: String, duration := 6.0) -> void:
	hint_label.text = text
	_hint_t = duration
	hint_box.reset_size()
	var sz := hint_box.get_combined_minimum_size()
	_place(hint_box, Control.PRESET_CENTER_BOTTOM, Rect2(-sz.x * 0.5, -_hint_bottom - sz.y, sz.x, sz.y))
	hint_box.create_tween().tween_property(hint_box, "modulate:a", 1.0, 0.25)


func _process(delta: float) -> void:
	if _hint_t > 0.0:
		_hint_t -= delta
		if _hint_t <= 0.0:
			hint_box.create_tween().tween_property(hint_box, "modulate:a", 0.0, 0.4)


func set_touch_mode(on: bool) -> void:
	_hint_bottom = 250.0 if on else 96.0


func _place(c: Control, preset: int, r: Rect2) -> void:
	c.set_anchors_preset(preset)
	c.offset_left = r.position.x
	c.offset_top = r.position.y
	c.offset_right = r.position.x + r.size.x
	c.offset_bottom = r.position.y + r.size.y
