class_name UiKit
extends RefCounted
## Shared game-styled widgets built from the painted UI textures.

const PANEL := preload("res://assets/art/ui/panel.png")
const BTN := preload("res://assets/art/ui/button_normal.png")
const BTN_HOT := preload("res://assets/art/ui/button_hover.png")
const DISPLAY_FONT := "res://assets/template/fonts/display/display_title.tres"
const CREAM := Color("#eaf8ff")
const GOLD := Color("#84efff")
const INK := Color("#080b24")
const DIM := Color("#b8c8e8")

static var _display: Font


static func display_font() -> Font:
	if _display == null:
		_display = load(DISPLAY_FONT) as Font
	return _display


static func panel_style() -> StyleBox:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("#111735e8")
	sb.border_color = Color("#6ce7ff88")
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(22)
	sb.shadow_color = Color("#040616aa")
	sb.shadow_size = 16
	sb.set_content_margin_all(44)
	sb.content_margin_top = 40
	return sb


static func button_style(hot: bool) -> StyleBox:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color("#2b3266f2") if hot else Color("#141b3de8")
	sb.border_color = Color("#b59aff") if hot else Color("#58dff0aa")
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.shadow_color = Color("#0b0d2caa")
	sb.shadow_size = 8 if hot else 4
	sb.content_margin_left = 28
	sb.content_margin_right = 28
	sb.content_margin_top = 8
	sb.content_margin_bottom = 10
	return sb


static func button(text: String, min_width := 320.0, font_size := 26) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_width, 60)
	b.focus_mode = Control.FOCUS_ALL
	var normal := button_style(false)
	var hot := button_style(true)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hot)
	b.add_theme_stylebox_override("focus", hot)
	b.add_theme_stylebox_override("pressed", hot)
	b.add_theme_stylebox_override("disabled", normal)
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", CREAM)
	b.add_theme_color_override("font_hover_color", Color("#fff6e0"))
	b.add_theme_color_override("font_focus_color", Color("#fff6e0"))
	b.add_theme_color_override("font_pressed_color", Color("#ffffff"))
	b.add_theme_color_override("font_disabled_color", Color(0.6, 0.55, 0.5, 0.6))
	b.add_theme_color_override("font_outline_color", Color("#2a140a"))
	b.add_theme_constant_override("outline_size", 6)
	b.mouse_entered.connect(func() -> void:
		if not b.disabled:
			b.grab_focus())
	b.focus_entered.connect(func() -> void:
		b.pivot_offset = b.size * 0.5
		var tw := b.create_tween()
		tw.tween_property(b, "scale", Vector2(1.04, 1.04), 0.08)
		tw.tween_property(b, "scale", Vector2.ONE, 0.1))
	return b


static func title(text: String, size := 64, color := GOLD) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var f := display_font()
	if f:
		l.add_theme_font_override("font", f)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("#2a140a"))
	l.add_theme_constant_override("outline_size", maxi(6, size / 7))
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.5))
	l.add_theme_constant_override("shadow_offset_y", 4)
	return l


static func label(text: String, size := 24, color := CREAM, outline := 5) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("#1a0d10"))
	l.add_theme_constant_override("outline_size", outline)
	return l


static func icon(tex: Texture2D, height := 40.0) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	var ratio := float(tex.get_width()) / float(tex.get_height())
	r.custom_minimum_size = Vector2(height * ratio, height)
	return r


static func panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", panel_style())
	return p


## Full-screen dim + centred panel, returns [root, vbox].
static func modal(parent: Node, width := 560.0) -> Array:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.process_mode = Node.PROCESS_MODE_ALWAYS
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.02, 0.06, 0.62)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var p := panel()
	p.custom_minimum_size = Vector2(width, 0)
	center.add_child(p)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 14)
	p.add_child(box)
	parent.add_child(root)
	p.pivot_offset = Vector2(width * 0.5, 200)
	p.scale = Vector2(0.9, 0.9)
	p.modulate.a = 0.0
	var tw := p.create_tween().set_parallel()
	tw.tween_property(p, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(p, "modulate:a", 1.0, 0.12)
	return [root, box]


static func center_row(parent: Container, children: Array, sep := 16) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", sep)
	for c: Control in children:
		row.add_child(c)
	parent.add_child(row)
	return row


static func wire_focus(buttons: Array) -> void:
	for i in buttons.size():
		var b: Control = buttons[i]
		b.focus_neighbor_top = b.get_path_to(buttons[(i - 1 + buttons.size()) % buttons.size()])
		b.focus_neighbor_bottom = b.get_path_to(buttons[(i + 1) % buttons.size()])
