class_name SettingsMenu
extends RefCounted
## Settings modal. Volumes go through GameAudio buses; cosmetic toggles through
## TuningStore player settings; language through I18n (persisted by it).

signal closed

var root: Control
var _parent: Node
var _first: Control


static func open(parent: Node) -> SettingsMenu:
	var m := SettingsMenu.new()
	m._parent = parent
	m._build()
	return m


func _build(focus_index := 0) -> void:
	var parts := UiKit.modal(_parent, 640)
	root = parts[0]
	root.set_meta("menu", self)
	var box: VBoxContainer = parts[1]
	box.add_child(UiKit.title(I18n.t("settings.title"), 46))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 10)
	box.add_child(grid)
	var controls: Array = []
	for bus: StringName in [&"Master", &"Music", &"SFX"]:
		var s := _slider(GameAudio.get_bus_volume(bus))
		s.value_changed.connect(func(v: float) -> void: GameAudio.set_bus_volume(bus, v))
		_row(grid, I18n.t("settings.volume_" + String(bus).to_lower()), s)
		controls.append(s)
	var quality := _cycler(
		[I18n.t("settings.quality_low"), I18n.t("settings.quality_high")],
		int(TuningStore.get_player_setting("effects_quality")),
		func(i: int) -> void: TuningStore.set_player_setting("effects_quality", float(i)))
	_row(grid, I18n.t("settings.effects"), quality)
	controls.append(quality)
	var motion := _cycler(
		[I18n.t("settings.off"), I18n.t("settings.on")],
		1 - int(TuningStore.get_player_setting("reduced_motion")),
		func(i: int) -> void: TuningStore.set_player_setting("reduced_motion", float(1 - i)))
	_row(grid, I18n.t("settings.shake"), motion)
	controls.append(motion)
	var hints := _cycler([I18n.t("settings.off"), I18n.t("settings.on")], 1 if SaveStore.hints_setting() else 0,
		func(i: int) -> void: SaveStore.set_hints(i == 1))
	_row(grid, I18n.t("settings.hints"), hints)
	controls.append(hints)
	var langs := ["en", "zh-CN"]
	var lang_index := controls.size()
	var lang := _cycler(["English", "中文"], maxi(0, langs.find(I18n.get_locale())),
		func(i: int) -> void:
			I18n.set_locale(langs[i])
			_relabel(lang_index))
	_row(grid, I18n.t("settings.language"), lang)
	controls.append(lang)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	box.add_child(row)
	var licenses := UiKit.button(I18n.t("settings.licenses"), 220, 20)
	licenses.pressed.connect(func() -> void: preload("res://scripts/manus/open_source_licenses.gd").open(root))
	row.add_child(licenses)
	var back := UiKit.button(I18n.t("menu.back"), 220, 24)
	back.set_meta("audio_cue", &"back")
	back.pressed.connect(close)
	row.add_child(back)
	controls.append(licenses)
	controls.append(back)
	for i in controls.size():
		var c: Control = controls[i]
		c.focus_neighbor_top = c.get_path_to(controls[(i - 1 + controls.size()) % controls.size()])
		c.focus_neighbor_bottom = c.get_path_to(controls[(i + 1) % controls.size()])
	licenses.focus_neighbor_right = licenses.get_path_to(back)
	back.focus_neighbor_left = back.get_path_to(licenses)
	back.focus_neighbor_top = back.get_path_to(lang)
	_first = controls[clampi(focus_index, 0, controls.size() - 1)]
	var catcher := _CancelCatcher.new()
	catcher.on_cancel = close
	root.add_child(catcher)
	_first.call_deferred("grab_focus")


func _relabel(focus_index := 0) -> void:
	# Rebuild in the new language, keeping the modal open.
	var p := _parent
	root.queue_free()
	_parent = p
	_build(focus_index)


func close() -> void:
	if is_instance_valid(root):
		root.queue_free()
	closed.emit()


func _row(grid: GridContainer, text: String, control: Control) -> void:
	var l := UiKit.label(text, 24)
	l.custom_minimum_size = Vector2(220, 44)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	grid.add_child(l)
	grid.add_child(control)


func _slider(value: float) -> HSlider:
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(300, 44)
	s.focus_mode = Control.FOCUS_ALL
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.08, 0.05, 0.1, 0.9)
	track.border_color = Color(0.85, 0.62, 0.3, 0.7)
	track.set_border_width_all(2)
	track.set_corner_radius_all(8)
	track.content_margin_top = 6
	track.content_margin_bottom = 6
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color("#ffb44a")
	fill.set_corner_radius_all(8)
	fill.content_margin_top = 6
	fill.content_margin_bottom = 6
	var focus := StyleBoxFlat.new()
	focus.draw_center = false
	focus.border_color = Color(1.0, 0.85, 0.5, 0.9)
	focus.set_border_width_all(2)
	focus.set_corner_radius_all(10)
	focus.expand_margin_left = 6
	focus.expand_margin_right = 6
	s.add_theme_stylebox_override("slider", track)
	s.add_theme_stylebox_override("grabber_area", fill)
	s.add_theme_stylebox_override("grabber_area_highlight", fill)
	s.add_theme_stylebox_override("focus", focus)
	var grab := _grabber()
	s.add_theme_icon_override("grabber", grab)
	s.add_theme_icon_override("grabber_highlight", grab)
	return s


static var _grab_tex: Texture2D


func _grabber() -> Texture2D:
	if _grab_tex == null:
		var img := (preload("res://assets/art/props/ember.png") as Texture2D).get_image()
		img.resize(28, 36, Image.INTERPOLATE_LANCZOS)
		_grab_tex = ImageTexture.create_from_image(img)
	return _grab_tex


func _cycler(options: Array, index: int, on_change: Callable) -> Button:
	var b := UiKit.button("", 300, 22)
	b.custom_minimum_size = Vector2(300, 48)
	var state := {"i": clampi(index, 0, options.size() - 1)}
	var refresh := func() -> void: b.text = "‹  %s  ›" % options[state.i]
	refresh.call()
	var step := func(d: int) -> void:
		state.i = (state.i + d + options.size()) % options.size()
		refresh.call()
		on_change.call(state.i)
	b.pressed.connect(func() -> void: step.call(1))
	b.gui_input.connect(func(e: InputEvent) -> void:
		if e.is_action_pressed("ui_left"):
			step.call(-1)
			b.accept_event()
		elif e.is_action_pressed("ui_right"):
			step.call(1)
			b.accept_event())
	return b


class _CancelCatcher extends Node:
	var on_cancel: Callable

	func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS

	func _unhandled_input(event: InputEvent) -> void:
		if event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause"):
			get_viewport().set_input_as_handled()
			on_cancel.call()
