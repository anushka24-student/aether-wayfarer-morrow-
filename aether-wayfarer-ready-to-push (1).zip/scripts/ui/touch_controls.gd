class_name TouchControls
extends CanvasLayer
## On-screen buttons for phones/tablets (landscape). Multitouch via
## TouchScreenButton, each mapped to the same input actions as keys/pads.

const BUTTONS := [
	# [texture key, action, anchor (0=left,1=right), offset from bottom-corner, scale]
	["left", "move_left", 0, Vector2(40, 200), 0.78],
	["right", "move_right", 0, Vector2(200, 200), 0.78],
	["jump", "jump", 1, Vector2(200, 210), 0.9],
	["dash", "dash", 1, Vector2(370, 170), 0.72],
	["lantern", "lantern", 1, Vector2(236, 380), 0.66],
]

var _buttons: Array = []


func _ready() -> void:
	layer = 11
	for spec: Array in BUTTONS:
		var b := TouchScreenButton.new()
		b.texture_normal = load("res://assets/art/ui/touch_%s.png" % spec[0])
		b.texture_pressed = load("res://assets/art/ui/touch_%s_on.png" % spec[0])
		b.action = spec[1]
		b.passby_press = spec[1].begins_with("move_")
		var shape := CircleShape2D.new()
		shape.radius = 92.0
		b.shape = shape
		b.shape_centered = true
		b.scale = Vector2(spec[4], spec[4])
		b.visibility_mode = TouchScreenButton.VISIBILITY_ALWAYS
		add_child(b)
		_buttons.append([b, spec])
	get_viewport().size_changed.connect(_layout)
	_layout()


func _layout() -> void:
	var size := get_viewport().get_visible_rect().size
	for pair: Array in _buttons:
		var b: TouchScreenButton = pair[0]
		var spec: Array = pair[1]
		var off: Vector2 = spec[3]
		var s: float = spec[4]
		var w := 192.0 * s
		if int(spec[2]) == 0:
			b.position = Vector2(off.x, size.y - off.y + (200.0 - w) * 0.5)
		else:
			b.position = Vector2(size.x - off.x - w * 0.5, size.y - off.y + (200.0 - w) * 0.5)


func release_all() -> void:
	for pair: Array in _buttons:
		Input.action_release(pair[1][1])
