extends Node
## Local persistence: per-level bests, ember collection, campaign best,
## resumable checkpoint progress and first-play tutorial state.
signal changed

const SAVE_PATH := "user://lantern_save.json"
const VERSION := 1

var data: Dictionary = {}
var persistence_enabled := true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load()


func _blank() -> Dictionary:
	return {"version": VERSION, "levels": {}, "campaign_best": 0.0, "tutorial_done": false,
		"hints": true, "resume": {}, "cloud_queue": []}


func _load() -> void:
	data = _blank()
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if parsed is Dictionary and int(parsed.get("version", 0)) == VERSION:
		for key in data:
			if parsed.has(key) and typeof(parsed[key]) == typeof(data[key]):
				data[key] = parsed[key]


func save() -> void:
	changed.emit()
	if not persistence_enabled:
		return
	var file := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if file == null:
		return
	file.store_string(JSON.stringify(data))
	file.close()
	DirAccess.rename_absolute(SAVE_PATH + ".tmp", SAVE_PATH)


func level_record(level_id: String) -> Dictionary:
	var record: Variant = data.levels.get(level_id, {})
	return record if record is Dictionary else {}


func is_unlocked(level_id: String, order: Array) -> bool:
	var index := order.find(level_id)
	if index <= 0:
		return true
	return bool(level_record(order[index - 1]).get("cleared", false))


## Returns {"new_best": bool, "best": float}. ember_mask bits = collected embers.
func record_clear(level_id: String, time: float, ember_mask_bits: int, deaths: int) -> Dictionary:
	var record := level_record(level_id)
	var best := float(record.get("best_time", 0.0))
	var new_best := best <= 0.0 or time < best
	record["cleared"] = true
	record["best_time"] = time if new_best else best
	record["embers"] = int(record.get("embers", 0)) | ember_mask_bits
	record["fewest_deaths"] = mini(int(record.get("fewest_deaths", 9999)), deaths)
	data.levels[level_id] = record
	save()
	return {"new_best": new_best, "best": float(record.best_time)}


func record_campaign(time: float) -> bool:
	var best := float(data.campaign_best)
	var new_best := best <= 0.0 or time < best
	if new_best:
		data.campaign_best = time
	save()
	return new_best


func campaign_best() -> float:
	return float(data.campaign_best)


func ember_mask(level_id: String) -> int:
	return int(level_record(level_id).get("embers", 0))


static func count_bits(mask: int) -> int:
	var total := 0
	for bit in 16:
		if mask & (1 << bit):
			total += 1
	return total


func total_embers() -> int:
	var total := 0
	for id: String in data.levels:
		total += count_bits(ember_mask(id))
	return total


## Resume state: level, checkpoint index, embers in this attempt, time, deaths, campaign.
func set_resume(state: Dictionary) -> void:
	data.resume = state
	save()


func clear_resume() -> void:
	data.resume = {}
	save()


func resume_state() -> Dictionary:
	return data.resume if data.resume is Dictionary else {}


func has_resume() -> bool:
	return not resume_state().is_empty()


func hints_enabled() -> bool:
	return bool(data.get("hints", true)) and not bool(data.get("tutorial_done", false))


func hints_setting() -> bool:
	return bool(data.get("hints", true))


func set_hints(value: bool) -> void:
	data.hints = value
	if value:
		data.tutorial_done = false
	save()


func mark_tutorial_done() -> void:
	data.tutorial_done = true
	save()


func cloud_snapshot() -> Dictionary:
	var snapshot := data.duplicate(true)
	snapshot.erase("cloud_queue")
	return snapshot


func merge_cloud(remote: Dictionary) -> void:
	if remote.is_empty():
		return
	var remote_levels: Dictionary = remote.get("levels", {}) if remote.get("levels", {}) is Dictionary else {}
	for level_id in remote_levels:
		var incoming: Dictionary = remote_levels[level_id] if remote_levels[level_id] is Dictionary else {}
		var local: Dictionary = level_record(str(level_id))
		local["cleared"] = bool(local.get("cleared", false)) or bool(incoming.get("cleared", false))
		var local_best := float(local.get("best_time", 0.0))
		var remote_best := float(incoming.get("best_time", 0.0))
		if remote_best > 0.0 and (local_best <= 0.0 or remote_best < local_best):
			local["best_time"] = remote_best
		local["embers"] = int(local.get("embers", 0)) | int(incoming.get("embers", 0))
		local["fewest_deaths"] = mini(int(local.get("fewest_deaths", 9999)), int(incoming.get("fewest_deaths", 9999)))
		data.levels[str(level_id)] = local
	var local_campaign := float(data.get("campaign_best", 0.0))
	var remote_campaign := float(remote.get("campaign_best", 0.0))
	if remote_campaign > 0.0 and (local_campaign <= 0.0 or remote_campaign < local_campaign):
		data.campaign_best = remote_campaign
	data.tutorial_done = bool(data.get("tutorial_done", false)) or bool(remote.get("tutorial_done", false))
	if not has_resume():
		var remote_resume: Variant = remote.get("resume", {})
		if remote_resume is Dictionary and not remote_resume.is_empty():
			data.resume = remote_resume.duplicate(true)
	save()


func queue_cloud_record(record: Dictionary) -> void:
	var queue: Array = data.get("cloud_queue", []) if data.get("cloud_queue", []) is Array else []
	var id := str(record.get("recordId", ""))
	if id.is_empty():
		return
	for existing in queue:
		if existing is Dictionary and str(existing.get("recordId", "")) == id:
			return
	queue.append(record.duplicate(true))
	data.cloud_queue = queue
	save()


func peek_cloud_record() -> Dictionary:
	var queue: Array = data.get("cloud_queue", []) if data.get("cloud_queue", []) is Array else []
	return queue[0] if not queue.is_empty() and queue[0] is Dictionary else {}


func remove_cloud_record(record_id: String) -> void:
	var queue: Array = data.get("cloud_queue", []) if data.get("cloud_queue", []) is Array else []
	data.cloud_queue = queue.filter(func(item: Variant) -> bool: return not (item is Dictionary and str(item.get("recordId", "")) == record_id))
	save()
