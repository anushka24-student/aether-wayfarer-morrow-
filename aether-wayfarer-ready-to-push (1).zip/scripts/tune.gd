class_name Tune
extends RefCounted
## Read a centrally configured gameplay parameter (config/tuning.json).
## Usage: Tune.v("run_speed")

static var _store: Node


static func v(key: String) -> float:
	if _store == null or not is_instance_valid(_store):
		var tree := Engine.get_main_loop() as SceneTree
		_store = tree.root.get_node_or_null("TuningStore") if tree else null
	return float(_store.get_value(key)) if _store else 0.0


static func quality_high() -> bool:
	return v("effects_quality") >= 0.5


static func motion_ok() -> bool:
	return v("reduced_motion") < 0.5
