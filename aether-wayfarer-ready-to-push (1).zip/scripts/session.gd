extends Node
## Cross-scene session: which level to load, campaign run totals, and the
## most recent input device (for control glyphs in hints and menus).
signal device_changed(device: String)

const GAME_SCENE := "res://scenes/game.tscn"
const TITLE_SCENE := "res://scenes/title_screen.tscn"

var level_id := "forest"
var campaign := false
var campaign_time := 0.0
var campaign_deaths := 0
var campaign_embers := 0
var resume: Dictionary = {}
var device := "keyboard"   # keyboard | gamepad | touch
var touch_seen := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.has_feature("web_android") or OS.has_feature("web_ios") or OS.has_feature("mobile"):
		touch_seen = true
		device = "touch"


func _input(event: InputEvent) -> void:
	var next := device
	if event is InputEventScreenTouch or event is InputEventScreenDrag:
		touch_seen = true
		next = "touch"
	elif event is InputEventKey and event.pressed:
		next = "keyboard"
	elif event is InputEventJoypadButton and event.pressed:
		next = "gamepad"
	elif event is InputEventJoypadMotion and absf(event.axis_value) > 0.5:
		next = "gamepad"
	if next != device:
		device = next
		device_changed.emit(device)


func start_level(id: String, as_campaign: bool, resume_state: Dictionary = {}) -> void:
	level_id = id
	campaign = as_campaign
	resume = resume_state
	if not resume_state.is_empty() and resume_state.has("campaign_time"):
		campaign = bool(resume_state.get("campaign", as_campaign))
		campaign_time = float(resume_state.campaign_time)
		campaign_deaths = int(resume_state.get("campaign_deaths", 0))
		campaign_embers = int(resume_state.get("campaign_embers", 0))
	if as_campaign and resume_state.is_empty() and id == "forest":
		campaign_time = 0.0
		campaign_deaths = 0
		campaign_embers = 0
	get_tree().paused = false
	get_tree().change_scene_to_file(GAME_SCENE)


func to_title() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	get_tree().change_scene_to_file(TITLE_SCENE)


static func format_time(seconds: float) -> String:
	var total := maxf(seconds, 0.0)
	var minutes := int(total / 60.0)
	var rest := total - minutes * 60.0
	return "%d:%05.2f" % [minutes, rest]
