# Aether Wayfarer — Delivery TODO

- [x] **Supplied Lantern Wayfarer source is integrated as the playable baseline.** The complete published-source archive, including game source, assets, and configuration, is integrated into the initialized Godot `game-platformer` project. The existing 2D precision-platformer genre, lantern-light reveal mechanics, three-level campaign, boss encounter, controls, and runtime compatibility remain intact.

- [x] **Ethereal fantasy-tech visual remix is applied without unnecessary complexity.** The preserved scenes and art now use moonlit indigo/cyan/violet theme colors, spectral lantern and beacon illumination, animated astral glyphs in the background, restrained holographic-style UI panels, and a subtle title-screen aura while keeping platforms, hazards, interaction states, and text readable and approachable.

- [x] **English and Simplified Chinese support is preserved and extended.** The existing localization files remain in place, and the Aether Wayfarer title and new tagline are available in both English and Simplified Chinese. Existing exposed gameplay copy remains localized.

- [x] **Game-specific loading and sharing identity are updated.** The authored web loader uses the Aether Wayfarer name and indigo/cyan visual identity with localized progress/retry behavior. Game sharing metadata describes the fantasy-tech remix and its forest, cave, tower, and boss journey.

- [x] **Validation and release checkpoint.** The edited JSON and Godot project parse cleanly; `npm run check`, `npm run test:checks`, and the supplied `test/reach.gd -- forest` harness pass. The managed preview build completed successfully, the browser title screen rendered with no console output, and activating New Journey loaded the first Hushwood level with no console output. The unrelated starter-template smoke/contract/terrain checks remain stale because the supplied archive replaces the original Yarn/Felt API; they were not used as evidence for this Lantern Wayfarer remix.

- [ ] **Managed player login is available from the game.** Enable the managed server and database, install the supported Manus OAuth/session bridge in the authored Godot web shell, preserve `applicationKind: game` and the `true` → `site` build, and expose bilingual Login/Logout/session-state controls without adding a custom auth protocol or leaking tokens.

- [ ] **Account-backed profile and cross-device progress are persisted.** After a confirmed authenticated session, load and save the player profile and versioned campaign progress through protected server procedures owned by `ctx.user`; anonymous/offline play continues through the existing local save path and cloud writes never block platforming.

- [ ] **Game records are stored per account.** Append bounded, validated level/campaign records to the authenticated player account and expose a compact account history view while preserving the existing local record behavior and English/Simplified Chinese localization.

- [ ] **Backend release validation is complete.** Apply the supported migration/configuration, verify backend health and source-level auth/sync checks, build the hybrid preview, and document any online acceptance that cannot be observed in the current Preview environment before saving a new checkpoint.
