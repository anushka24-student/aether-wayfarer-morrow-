CREATE TABLE IF NOT EXISTS `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
CREATE TABLE IF NOT EXISTS `player_profiles` (
  `userId` int NOT NULL,
  `displayName` varchar(120) NOT NULL DEFAULT '',
  `locale` varchar(12) NOT NULL DEFAULT 'en',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `player_profiles_user_id` PRIMARY KEY(`userId`),
  INDEX `player_profiles_locale_idx` (`locale`)
);

CREATE TABLE IF NOT EXISTS `player_progress` (
  `userId` int NOT NULL,
  `schemaVersion` int NOT NULL DEFAULT 1,
  `revision` int NOT NULL DEFAULT 1,
  `payload` JSON NOT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `player_progress_user_id` PRIMARY KEY(`userId`)
);

CREATE TABLE IF NOT EXISTS `game_records` (
  `id` bigint AUTO_INCREMENT NOT NULL,
  `userId` int NOT NULL,
  `recordId` varchar(96) NOT NULL,
  `kind` varchar(32) NOT NULL,
  `levelId` varchar(64) NULL,
  `outcome` varchar(32) NULL,
  `durationMs` int NOT NULL DEFAULT 0,
  `deaths` int NOT NULL DEFAULT 0,
  `embers` int NOT NULL DEFAULT 0,
  `payload` JSON NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `game_records_id` PRIMARY KEY(`id`),
  UNIQUE KEY `game_records_user_record_unique` (`userId`, `recordId`),
  INDEX `game_records_user_created_idx` (`userId`, `createdAt`)
);
