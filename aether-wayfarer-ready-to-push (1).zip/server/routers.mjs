import { z } from 'zod'
import { router, protectedProcedure } from './webdev-adapter.mjs'
import { appendRecord, getProfile, getProgress, listRecords, updateProfile, upsertProgress } from './game-db.mjs'

const profileInput = z.object({
  displayName: z.string().trim().max(120).optional().default(''),
  locale: z.enum(['en', 'zh-CN']).default('en'),
})

const progressInput = z.object({
  schemaVersion: z.number().int().min(1).max(10).default(1),
  data: z.record(z.string(), z.unknown()),
})

const recordInput = z.object({
  recordId: z.string().regex(/^[A-Za-z0-9_-]{1,96}$/),
  kind: z.string().trim().min(1).max(32),
  levelId: z.string().trim().max(64).optional().default(''),
  outcome: z.string().trim().max(32).optional().default(''),
  durationMs: z.number().int().min(0).max(86_400_000).default(0),
  deaths: z.number().int().min(0).max(100_000).default(0),
  embers: z.number().int().min(0).max(1_000_000).default(0),
  payload: z.record(z.string(), z.unknown()).optional().default({}),
})

export const gameRouter = router({
  player: protectedProcedure.query(({ ctx }) => ({ id: ctx.user.id, name: ctx.user.name })),
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => ({
      user: { name: ctx.user.name || '' },
      profile: (await getProfile(ctx)) || { displayName: ctx.user.name || '', locale: 'en', updatedAt: null },
    })),
    update: protectedProcedure.input(profileInput).mutation(({ ctx, input }) => updateProfile(ctx, input)),
  }),
  progress: router({
    get: protectedProcedure.query(({ ctx }) => getProgress(ctx)),
    upsert: protectedProcedure.input(progressInput).mutation(({ ctx, input }) => upsertProgress(ctx, input)),
  }),
  records: router({
    list: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(50).default(20) })).query(({ ctx, input }) => listRecords(ctx, input.limit)),
    append: protectedProcedure.input(recordInput).mutation(({ ctx, input }) => appendRecord(ctx, input)),
  }),
})
