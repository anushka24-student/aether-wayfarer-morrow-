import mysql from 'mysql2/promise'

const pool = mysql.createPool(process.env.DATABASE_URL)

function requireUserId(ctx) {
  const userId = Number(ctx.user?.id)
  if (!Number.isInteger(userId) || userId < 1) throw new Error('authenticated user id is required')
  return userId
}

function parseJson(value, fallback) {
  if (value && typeof value === 'object') return value
  if (typeof value === 'string') {
    try { return JSON.parse(value) } catch { return fallback }
  }
  return fallback
}

function iso(value) {
  return value instanceof Date ? value.toISOString() : value ? String(value) : null
}

export async function getProfile(ctx) {
  const userId = requireUserId(ctx)
  const [rows] = await pool.execute(
    'SELECT displayName, locale, updatedAt FROM player_profiles WHERE userId = ? LIMIT 1',
    [userId],
  )
  if (!rows.length) return null
  return {
    displayName: rows[0].displayName || ctx.user.name || '',
    locale: rows[0].locale || 'en',
    updatedAt: iso(rows[0].updatedAt),
  }
}

export async function updateProfile(ctx, input) {
  const userId = requireUserId(ctx)
  await pool.execute(
    `INSERT INTO player_profiles (userId, displayName, locale)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE displayName = VALUES(displayName), locale = VALUES(locale), updatedAt = CURRENT_TIMESTAMP`,
    [userId, input.displayName || ctx.user.name || '', input.locale],
  )
  return getProfile(ctx)
}

export async function getProgress(ctx) {
  const userId = requireUserId(ctx)
  const [rows] = await pool.execute(
    'SELECT schemaVersion, revision, payload, updatedAt FROM player_progress WHERE userId = ? LIMIT 1',
    [userId],
  )
  if (!rows.length) return { schemaVersion: 1, revision: 0, data: {}, updatedAt: null }
  return {
    schemaVersion: Number(rows[0].schemaVersion || 1),
    revision: Number(rows[0].revision || 0),
    data: parseJson(rows[0].payload, {}),
    updatedAt: iso(rows[0].updatedAt),
  }
}

export async function upsertProgress(ctx, input) {
  const userId = requireUserId(ctx)
  const payload = JSON.stringify(input.data)
  if (Buffer.byteLength(payload, 'utf8') > 64 * 1024) throw new Error('progress payload is too large')
  await pool.execute(
    `INSERT INTO player_progress (userId, schemaVersion, revision, payload)
     VALUES (?, ?, 1, ?)
     ON DUPLICATE KEY UPDATE schemaVersion = VALUES(schemaVersion), revision = revision + 1,
       payload = VALUES(payload), updatedAt = CURRENT_TIMESTAMP`,
    [userId, input.schemaVersion, payload],
  )
  return getProgress(ctx)
}

export async function listRecords(ctx, limit) {
  const userId = requireUserId(ctx)
  const [rows] = await pool.query(
    `SELECT recordId, kind, levelId, outcome, durationMs, deaths, embers, payload, createdAt
       FROM game_records WHERE userId = ? ORDER BY createdAt DESC, id DESC LIMIT ${limit}`,
    [userId],
  )
  return rows.map((row) => ({
    recordId: row.recordId,
    kind: row.kind,
    levelId: row.levelId,
    outcome: row.outcome,
    durationMs: Number(row.durationMs || 0),
    deaths: Number(row.deaths || 0),
    embers: Number(row.embers || 0),
    payload: parseJson(row.payload, {}),
    createdAt: iso(row.createdAt),
  }))
}

export async function appendRecord(ctx, input) {
  const userId = requireUserId(ctx)
  const payload = JSON.stringify(input.payload || {})
  if (Buffer.byteLength(payload, 'utf8') > 8 * 1024) throw new Error('record payload is too large')
  const [result] = await pool.execute(
    `INSERT IGNORE INTO game_records
       (userId, recordId, kind, levelId, outcome, durationMs, deaths, embers, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, input.recordId, input.kind, input.levelId || null, input.outcome || null,
      input.durationMs, input.deaths, input.embers, payload],
  )
  return { accepted: true, duplicate: Number(result.affectedRows || 0) === 0, recordId: input.recordId }
}
